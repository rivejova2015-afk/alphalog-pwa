import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Sparkles, Loader2, Settings, FileText } from 'lucide-react';
import { toast } from 'sonner';
import { useTranslation } from '@/components/utils/translations';
import ReactMarkdown from 'react-markdown';

export default function ReportGenerator({ instrument, onReportGenerated }) {
  const { t } = useTranslation();
  const [generating, setGenerating] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [reportType, setReportType] = useState('DAILY_OUTLOOK');
  const [tone, setTone] = useState('professional');
  const [previewReport, setPreviewReport] = useState(null);
  const [previewOpen, setPreviewOpen] = useState(false);

  const reportTypes = [
    { value: 'ALL_IN', label: 'All-in-One (Complete)' },
    { value: 'PRE_MARKET', label: 'Pre-Market' },
    { value: 'DAILY_OUTLOOK', label: 'Daily Outlook' },
    { value: 'MIDDAY', label: 'Midday Update' },
    { value: 'CLOSE_WRAP', label: 'Close Wrap' },
    { value: 'ASIA_SESSION', label: 'Asia Session' },
    { value: 'LONDON_SESSION', label: 'London Session' },
    { value: 'NY_SESSION', label: 'NY Session' },
    { value: 'TECHNICAL_LIQUIDITY', label: 'Technical Liquidity' }
  ];

  const tones = [
    { value: 'professional', label: 'Professional' },
    { value: 'technical', label: 'Technical' },
    { value: 'casual', label: 'Casual' }
  ];

  const handleGenerateReport = async () => {
    setGenerating(true);
    try {
      const lang = localStorage.getItem('alphalog-language') || 'en';
      const targetLang = lang === 'es' ? 'Spanish' : 'English';

      // Fetch all data sources
      const [news, events, claims, structures, pools, snapshots] = await Promise.all([
        base44.entities.TerminalNews.filter({ instrument_id: instrument }, '-timestamp_utc', 15),
        base44.entities.TerminalEvent.filter({ related_instruments: instrument }, '-timestamp_utc', 10),
        base44.entities.TerminalClaim.filter({ instrument_id: instrument, status: 'VERIFIED' }, '-date_utc', 5),
        base44.entities.StructureH1.filter({ instrument_id: instrument }, '-timestamp_utc', 3),
        base44.entities.LiquidityPool.filter({ instrument_id: instrument }, '-date_utc', 5),
        base44.entities.MarketSnapshot.filter({ instrument_id: instrument }, '-as_of_utc', 1)
      ]);

      const snapshot = snapshots[0] || {};
      const latestStructure = structures[0] || {};
      
      // Build context
      const newsContext = news.map(n => 
        `- ${n.title} (${n.source}, Impact: ${n.impact_label || 'N/A'})`
      ).join('\n');

      const eventsContext = events.map(e => 
        `- ${e.name} (${e.impact}, ${new Date(e.timestamp_utc).toLocaleString()})`
      ).join('\n');

      const claimsContext = claims.map(c => 
        `- ${c.statement} (Confidence: ${c.confidence}%)`
      ).join('\n');

      const structureContext = `
Trend: ${latestStructure.trend || 'N/A'}
State: ${latestStructure.state || 'N/A'}
BOS: ${latestStructure.bos_price || 'N/A'}
ChoCh: ${latestStructure.choch_price || 'N/A'}
      `.trim();

      const poolsContext = pools.map(p => 
        `- ${p.pool_type}: ${p.price_zone_low} - ${p.price_zone_high} (Priority: ${p.priority_rank})`
      ).join('\n');

      const toneInstructions = {
        professional: 'Use professional, formal language suitable for institutional investors.',
        technical: 'Use technical trading terminology, focus on price action and market structure.',
        casual: 'Use conversational, easy-to-understand language for retail traders.'
      };

      const reportTypeInstructions = {
        ALL_IN: 'Complete comprehensive analysis combining pre-market setup, intraday updates, session-specific analysis, technical liquidity deep dive, and close wrap. This is the ultimate all-in-one report covering everything from overnight developments to end-of-day summary and tomorrow\'s preparation.',
        PRE_MARKET: 'Focus on pre-market setup, key levels to watch, and overnight developments.',
        DAILY_OUTLOOK: 'Comprehensive daily analysis covering all aspects.',
        MIDDAY: 'Mid-session update focusing on current price action and intraday changes.',
        CLOSE_WRAP: 'End-of-day summary and tomorrow\'s preparation.',
        ASIA_SESSION: 'Analysis specific to Asian trading session.',
        LONDON_SESSION: 'Analysis specific to London trading session.',
        NY_SESSION: 'Analysis specific to New York trading session.',
        TECHNICAL_LIQUIDITY: 'Deep dive into liquidity pools and market structure.'
      };

      // Generate report with sentiment analysis
      const prompt = `You are a professional market analyst. Generate a ${reportType.replace(/_/g, ' ')} report for ${instrument} in ${targetLang}.

${toneInstructions[tone]}
${reportTypeInstructions[reportType]}

**DATA SOURCES:**

Recent News (last 15):
${newsContext || 'No recent news'}

Economic Events:
${eventsContext || 'No upcoming events'}

Verified Claims:
${claimsContext || 'No verified claims'}

Market Structure (1H):
${structureContext}

Liquidity Pools:
${poolsContext || 'No pools identified'}

Current Snapshot:
Price: ${snapshot.payload_json?.price?.current || 'N/A'}
Confidence: ${snapshot.confidence || 0}%

**REPORT STRUCTURE:**

## Market Overview
Brief 2-3 sentence summary of current state

## News Impact Table
Create a well-formatted markdown table showing HIGH and MEDIUM impact news ONLY:

| 📰 Title & Summary | 📊 Source | ⚠️ Impact |
|-------------------|-----------|-----------|
| Brief title + 1-line summary | Source name | 🔴 HIGH or 🟠 MED |

**IMPORTANT TABLE RULES:**
- Filter: Show ONLY news with HIGH or MED impact (ignore LOW impact)
- Order: Sort by impact level (🔴 HIGH first, then 🟠 MED)
- Format impact column as: "🔴 HIGH" or "🟠 MED" (emoji + text)
- First column: News title with a brief 1-line summary below it
- Use proper markdown table syntax with | dividers for each cell
- Include ALL high and medium impact news available

## Key Drivers
Top 3-5 factors in bullet points (concise)

## Technical Levels
Key support/resistance zones only

## Sentiment Barometer
- Direction: BUY / SELL / NEUTRAL (with % confidence)
- Emotion: FEAR / CONFIDENCE / EUPHORIA / NEUTRAL (with intensity 1-10)

## Outlook
Next steps and what to watch

## Final Summary
A comprehensive concluding paragraph that synthesizes all the above analysis, providing clear actionable insights and painting the complete market picture based on all data sources analyzed.

Keep it simple and actionable. Use markdown formatting with proper table syntax.`;

      const result = await base44.integrations.Core.InvokeLLM({
        prompt,
        add_context_from_internet: true
      });

      // Save report
      const savedReport = await base44.entities.Reports.create({
        instrument_id: instrument,
        created_at_utc: new Date().toISOString(),
        report_type: reportType,
        title: `${instrument} ${reportType.replace(/_/g, ' ')} - ${new Date().toLocaleDateString()}`,
        content_md: result,
        sources_used: [...new Set([
          ...news.map(n => n.source),
          'Economic Calendar',
          'Verified Claims',
          'Market Structure',
          'Liquidity Analysis'
        ])]
      });

      // Show preview immediately
      setPreviewReport(savedReport);
      setPreviewOpen(true);

      toast.success(lang === 'es' ? 'Reporte generado exitosamente' : 'Report generated successfully');
      if (onReportGenerated) onReportGenerated();
    } catch (error) {
      console.error('Failed to generate report:', error);
      const lang = localStorage.getItem('alphalog-language') || 'en';
      toast.error((lang === 'es' ? 'Error al generar reporte: ' : 'Error generating report: ') + error.message);
    } finally {
      setGenerating(false);
    }
  };

  return (
    <>
      <div className="flex items-center gap-2">
        <Button 
          onClick={handleGenerateReport}
          disabled={generating}
          className="bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700"
          size="sm"
        >
          {generating ? (
            <>
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              {t('generating')}
            </>
          ) : (
            <>
              <Sparkles className="w-4 h-4 mr-2" />
              {t('generateReport')}
            </>
          )}
        </Button>
        <Button
          variant="outline"
          size="sm"
          onClick={() => setSettingsOpen(true)}
          className="border-slate-700"
        >
          <Settings className="w-4 h-4" />
        </Button>
        <Badge variant="outline" className="bg-indigo-600 text-white border-indigo-500">
          {t('poweredByAI')}
        </Badge>
      </div>

      <Dialog open={settingsOpen} onOpenChange={setSettingsOpen}>
        <DialogContent className="bg-slate-900 border-slate-800 text-white">
          <DialogHeader>
            <DialogTitle>Report Settings</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div>
              <Label className="text-slate-400 mb-2 block">Report Type</Label>
              <Select value={reportType} onValueChange={setReportType}>
                <SelectTrigger className="bg-slate-800 border-slate-700">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-slate-800 border-slate-700">
                  {reportTypes.map(type => (
                    <SelectItem key={type.value} value={type.value}>
                      {type.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label className="text-slate-400 mb-2 block">Tone</Label>
              <Select value={tone} onValueChange={setTone}>
                <SelectTrigger className="bg-slate-800 border-slate-700">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-slate-800 border-slate-700">
                  {tones.map(t => (
                    <SelectItem key={t.value} value={t.value}>
                      {t.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="pt-4 border-t border-slate-700">
              <p className="text-xs text-slate-500">
                Report will be generated in your current language ({localStorage.getItem('alphalog-language') === 'es' ? 'Spanish' : 'English'})
              </p>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Report Preview Dialog */}
      <Dialog open={previewOpen} onOpenChange={setPreviewOpen}>
        <DialogContent className="bg-slate-950 border-slate-700 text-white max-w-6xl max-h-[90vh] overflow-y-auto">
          <DialogHeader className="border-b border-slate-800 pb-4">
            <DialogTitle className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-indigo-600 rounded-lg flex items-center justify-center">
                <FileText className="w-5 h-5 text-white" />
              </div>
              <div>
                <h2 className="text-xl font-bold">{previewReport?.title}</h2>
                <div className="flex items-center gap-2 mt-1">
                  <Badge className="bg-purple-600">
                    {previewReport?.report_type}
                  </Badge>
                  <span className="text-xs text-slate-500">
                    {previewReport && new Date(previewReport.created_at_utc).toLocaleString()}
                  </span>
                </div>
              </div>
            </DialogTitle>
          </DialogHeader>
          {previewReport && (
            <div className="space-y-6 pt-4">
              {previewReport.sources_used && previewReport.sources_used.length > 0 && (
                <div className="bg-slate-900/50 rounded-lg p-4 border border-slate-800">
                  <p className="text-sm font-semibold text-slate-400 mb-3 flex items-center gap-2">
                    <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                      <path d="M9 2a1 1 0 000 2h2a1 1 0 100-2H9z"/>
                      <path fillRule="evenodd" d="M4 5a2 2 0 012-2 3 3 0 003 3h2a3 3 0 003-3 2 2 0 012 2v11a2 2 0 01-2 2H6a2 2 0 01-2-2V5zm3 4a1 1 0 000 2h.01a1 1 0 100-2H7zm3 0a1 1 0 000 2h3a1 1 0 100-2h-3zm-3 4a1 1 0 100 2h.01a1 1 0 100-2H7zm3 0a1 1 0 100 2h3a1 1 0 100-2h-3z" clipRule="evenodd"/>
                    </svg>
                    {t('sources')}
                  </p>
                  <div className="flex flex-wrap gap-2">
                    {previewReport.sources_used.map((source, idx) => (
                      <Badge key={idx} variant="outline" className="text-xs bg-slate-800 border-slate-700">
                        {source}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}

              <div className="prose prose-invert prose-lg max-w-none report-content">
                <ReactMarkdown
                  components={{
                    h1: ({ children }) => (
                      <h1 className="text-3xl font-bold text-white mb-6 mt-8 pb-3 border-b border-slate-700">
                        {children}
                      </h1>
                    ),
                    h2: ({ children }) => (
                      <h2 className="text-2xl font-bold text-white mb-4 mt-8 flex items-center gap-2">
                        <span className="w-1 h-6 bg-purple-500 rounded-full"></span>
                        {children}
                      </h2>
                    ),
                    h3: ({ children }) => (
                      <h3 className="text-xl font-semibold text-slate-200 mb-3 mt-6">{children}</h3>
                    ),
                    p: ({ children }) => <p className="text-slate-300 mb-4 leading-relaxed text-base">{children}</p>,
                    ul: ({ children }) => <ul className="list-disc list-inside text-slate-300 mb-4 space-y-2">{children}</ul>,
                    ol: ({ children }) => <ol className="list-decimal list-inside text-slate-300 mb-4 space-y-2">{children}</ol>,
                    li: ({ children }) => <li className="mb-2 text-slate-300">{children}</li>,
                    strong: ({ children }) => <strong className="text-white font-bold">{children}</strong>,
                    table: ({ children }) => (
                      <div className="my-6 overflow-x-auto">
                        <table className="w-full border-collapse bg-slate-900 rounded-lg overflow-hidden">
                          {children}
                        </table>
                      </div>
                    ),
                    thead: ({ children }) => (
                      <thead className="bg-slate-800 border-b-2 border-slate-700">
                        {children}
                      </thead>
                    ),
                    tbody: ({ children }) => <tbody className="divide-y divide-slate-800">{children}</tbody>,
                    tr: ({ children }) => <tr className="hover:bg-slate-800/50 transition-colors">{children}</tr>,
                    th: ({ children }) => (
                      <th className="px-6 py-4 text-left text-sm font-bold text-slate-200 uppercase tracking-wider">
                        {children}
                      </th>
                    ),
                    td: ({ children }) => (
                      <td className="px-6 py-4 text-sm text-slate-300 align-top">
                        {children}
                      </td>
                    ),
                    blockquote: ({ children }) => (
                      <blockquote className="border-l-4 border-purple-500 pl-4 py-2 my-4 bg-purple-900/20 rounded-r">
                        {children}
                      </blockquote>
                    ),
                    code: ({ inline, children }) => 
                      inline ? (
                        <code className="px-2 py-1 bg-slate-800 rounded text-purple-300 text-sm font-mono">
                          {children}
                        </code>
                      ) : (
                        <code className="block bg-slate-900 p-4 rounded-lg text-sm font-mono overflow-x-auto">
                          {children}
                        </code>
                      )
                  }}
                >
                  {previewReport.content_md}
                </ReactMarkdown>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}