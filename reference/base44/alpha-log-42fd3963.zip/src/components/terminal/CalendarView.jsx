import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Calendar } from 'lucide-react';
import { useTranslation } from '@/components/utils/translations';

export default function CalendarView({ instrument }) {
  const { t } = useTranslation();
  const { data: events = [] } = useQuery({
    queryKey: ['terminal-events', instrument],
    queryFn: async () => {
      return await base44.entities.TerminalEvent.filter({
        related_instruments: instrument
      }, '-timestamp_utc', 50);
    }
  });

  return (
    <Card className="bg-slate-900 border-slate-800">
      <CardHeader>
        <CardTitle className="text-white flex items-center gap-2">
          <Calendar className="w-5 h-5" />
          {t('economicCalendar')} - {instrument}
        </CardTitle>
      </CardHeader>
      <CardContent>
        {events.length === 0 ? (
          <p className="text-slate-400 text-center py-8">{t('noUpcomingEvents')}</p>
        ) : (
          <div className="space-y-3">
            {events.map(event => (
              <div key={event.id} className="bg-slate-800 rounded p-4">
                <div className="flex items-start justify-between">
                  <div>
                    <h4 className="text-white font-medium">{event.name}</h4>
                    <p className="text-sm text-slate-400 mt-1">
                      {new Date(event.timestamp_utc).toLocaleString()}
                    </p>
                  </div>
                  <span className={`px-2 py-1 rounded text-xs ${
                    event.impact === 'HIGH' ? 'bg-red-600 text-white' :
                    event.impact === 'MED' ? 'bg-yellow-600 text-white' :
                    'bg-green-600 text-white'
                  }`}>
                    {t('impact')}: {event.impact}
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}