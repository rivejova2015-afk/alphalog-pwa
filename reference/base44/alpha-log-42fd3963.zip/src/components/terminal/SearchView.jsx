import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Search } from 'lucide-react';
import { useTranslation } from '@/components/utils/translations';

export default function SearchView() {
  const { t } = useTranslation();
  const [query, setQuery] = useState('');
  const [results, setResults] = useState([]);

  const handleSearch = () => {
    // TODO: Implement search functionality
    console.log('Searching for:', query);
  };

  return (
    <Card className="bg-slate-900 border-slate-800">
      <CardHeader>
        <CardTitle className="text-white flex items-center gap-2">
          <Search className="w-5 h-5" />
          {t('searchTerminalData')}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex gap-2 mb-6">
          <Input
            placeholder={t('searchPlaceholder')}
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
            className="bg-slate-800 border-slate-700 text-white"
          />
          <Button onClick={handleSearch}>
            <Search className="w-4 h-4 mr-2" />
            {t('search')}
          </Button>
        </div>
        
        {results.length === 0 ? (
          <p className="text-slate-400 text-center py-8">
            {t('enterSearchQuery')}
          </p>
        ) : (
          <div className="space-y-2">
            {results.map((result, idx) => (
              <div key={idx} className="bg-slate-800 rounded p-3">
                <p className="text-white text-sm">{result}</p>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}