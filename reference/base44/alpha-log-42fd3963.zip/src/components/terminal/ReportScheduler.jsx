import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Clock, Plus, Trash2, Calendar } from 'lucide-react';
import { toast } from 'sonner';

export default function ReportScheduler({ instrument }) {
  const queryClient = useQueryClient();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [formData, setFormData] = useState({
    instrument_id: instrument,
    report_type: 'DAILY_OUTLOOK',
    scheduled_time: '06:00',
    tone: 'professional',
    send_email: true,
    send_notification: true,
    is_active: true
  });

  const { data: schedules = [] } = useQuery({
    queryKey: ['report-schedules', instrument],
    queryFn: () => base44.entities.ReportSchedule.filter({ instrument_id: instrument })
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.ReportSchedule.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries(['report-schedules']);
      toast.success('Schedule created successfully');
      setDialogOpen(false);
      resetForm();
    }
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.ReportSchedule.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries(['report-schedules']);
      toast.success('Schedule deleted');
    }
  });

  const resetForm = () => {
    setFormData({
      instrument_id: instrument,
      report_type: 'DAILY_OUTLOOK',
      scheduled_time: '06:00',
      tone: 'professional',
      send_email: true,
      send_notification: true,
      is_active: true
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    createMutation.mutate(formData);
  };

  const reportTypes = [
    { value: 'ALL_IN', label: 'All-in-One (Complete Report)' },
    { value: 'PRE_MARKET', label: 'Pre-Market (6:00 AM)' },
    { value: 'DAILY_OUTLOOK', label: 'Daily Outlook (7:00 AM)' },
    { value: 'MIDDAY', label: 'Midday Update (12:00 PM)' },
    { value: 'CLOSE_WRAP', label: 'Close Wrap (4:00 PM)' },
    { value: 'ASIA_SESSION', label: 'Asia Session' },
    { value: 'LONDON_SESSION', label: 'London Session' },
    { value: 'NY_SESSION', label: 'NY Session' },
    { value: 'TECHNICAL_LIQUIDITY', label: 'Technical Liquidity' }
  ];

  return (
    <>
      <Card className="bg-slate-900 border-slate-800">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-white flex items-center gap-2">
              <Calendar className="w-5 h-5 text-blue-400" />
              Scheduled Reports
            </CardTitle>
            <Button 
              onClick={() => setDialogOpen(true)}
              size="sm"
              className="bg-green-600 hover:bg-green-700"
            >
              <Plus className="w-4 h-4 mr-2" />
              Add Schedule
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {schedules.length === 0 ? (
            <p className="text-slate-400 text-center py-8">No scheduled reports yet</p>
          ) : (
            <div className="space-y-2">
              {schedules.map(schedule => (
                <div key={schedule.id} className="bg-slate-800 rounded-lg p-4 flex items-center justify-between">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <Clock className="w-4 h-4 text-blue-400" />
                      <span className="text-white font-medium">
                        {schedule.report_type.replace(/_/g, ' ')}
                      </span>
                    </div>
                    <p className="text-sm text-slate-400">
                      Daily at {schedule.scheduled_time} • {schedule.tone} tone
                    </p>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => deleteMutation.mutate(schedule.id)}
                    className="text-red-400 hover:text-red-300"
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="bg-slate-900 border-slate-800 text-white">
          <DialogHeader>
            <DialogTitle>Schedule New Report</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4 py-4">
            <div>
              <Label className="text-slate-400 mb-2 block">Report Type</Label>
              <Select 
                value={formData.report_type} 
                onValueChange={(value) => setFormData({...formData, report_type: value})}
              >
                <SelectTrigger className="bg-slate-800 border-slate-700">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-slate-800 border-slate-700">
                  {reportTypes.map(type => (
                    <SelectItem key={type.value} value={type.value}>
                      {type.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label className="text-slate-400 mb-2 block">Time (24h format)</Label>
              <Input
                type="time"
                value={formData.scheduled_time}
                onChange={(e) => setFormData({...formData, scheduled_time: e.target.value})}
                className="bg-slate-800 border-slate-700"
              />
            </div>

            <div>
              <Label className="text-slate-400 mb-2 block">Tone</Label>
              <Select 
                value={formData.tone} 
                onValueChange={(value) => setFormData({...formData, tone: value})}
              >
                <SelectTrigger className="bg-slate-800 border-slate-700">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-slate-800 border-slate-700">
                  <SelectItem value="professional">Professional</SelectItem>
                  <SelectItem value="technical">Technical</SelectItem>
                  <SelectItem value="casual">Casual</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-3 pt-4 border-t border-slate-700">
              <div className="flex items-center justify-between">
                <Label className="text-slate-300">Send Email</Label>
                <Switch
                  checked={formData.send_email}
                  onCheckedChange={(checked) => setFormData({...formData, send_email: checked})}
                />
              </div>
              <div className="flex items-center justify-between">
                <Label className="text-slate-300">Send Notification</Label>
                <Switch
                  checked={formData.send_notification}
                  onCheckedChange={(checked) => setFormData({...formData, send_notification: checked})}
                />
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-4">
              <Button type="button" variant="ghost" onClick={() => setDialogOpen(false)}>
                Cancel
              </Button>
              <Button type="submit" className="bg-green-600 hover:bg-green-700">
                Create Schedule
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </>
  );
}