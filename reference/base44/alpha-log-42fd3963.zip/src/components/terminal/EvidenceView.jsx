import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { FileText, Eye, Calendar, Trash2, Languages } from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import { useTranslation } from '@/components/utils/translations';
import { toast } from 'sonner';

export default function EvidenceView({ instrument }) {
  const { t } = useTranslation();
  const [selectedReport, setSelectedReport] = useState(null);
  const [viewDialogOpen, setViewDialogOpen] = useState(false);
  const [translatingId, setTranslatingId] = useState(null);

  const { data: reports = [], refetch } = useQuery({
    queryKey: ['terminal-reports', instrument],
    queryFn: async () => {
      return await base44.entities.Reports.filter({
        instrument_id: instrument
      }, '-created_at_utc', 50);
    }
  });

  const handleViewReport = (report) => {
    setSelectedReport(report);
    setViewDialogOpen(true);
  };

  const handleDeleteReport = async (reportId) => {
    if (!confirm(t('deleteReportConfirm'))) return;
    
    try {
      await base44.entities.Reports.delete(reportId);
      const lang = localStorage.getItem('alphalog-language') || 'en';
      toast.success(lang === 'es' ? 'Reporte eliminado exitosamente' : 'Report deleted successfully');
      refetch();
    } catch (error) {
      const lang = localStorage.getItem('alphalog-language') || 'en';
      toast.error((lang === 'es' ? 'Error al eliminar reporte: ' : 'Error deleting report: ') + error.message);
    }
  };

  const handleTranslateReport = async (report) => {
    setTranslatingId(report.id);
    try {
      const lang = localStorage.getItem('alphalog-language') || 'en';
      const targetLang = lang === 'es' ? 'Spanish' : 'English';
      
      const translatedContent = await base44.integrations.Core.InvokeLLM({
        prompt: `Translate the following market analysis report to ${targetLang}. Keep the markdown formatting intact, including headers, bullet points, and emphasis. Only translate the text content, do not add any commentary or changes:\n\n${report.content_md}`,
      });

      await base44.entities.Reports.update(report.id, {
        content_md: translatedContent,
        title: lang === 'es' 
          ? report.title.replace('Daily Market Report', 'Reporte de Mercado Diario')
          : report.title.replace('Reporte de Mercado Diario', 'Daily Market Report')
      });

      toast.success(lang === 'es' ? 'Reporte traducido exitosamente' : 'Report translated successfully');
      refetch();
    } catch (error) {
      const lang = localStorage.getItem('alphalog-language') || 'en';
      toast.error((lang === 'es' ? 'Error al traducir: ' : 'Error translating: ') + error.message);
    } finally {
      setTranslatingId(null);
    }
  };

  const getReportTypeColor = (type) => {
    switch(type) {
      case 'DAILY_OUTLOOK': return 'bg-blue-600';
      case 'MIDDAY': return 'bg-amber-600';
      case 'CLOSE_WRAP': return 'bg-purple-600';
      default: return 'bg-slate-600';
    }
  };

  return (
    <>
      <Card className="bg-slate-900 border-slate-800">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <FileText className="w-5 h-5 text-blue-400" />
            {t('generatedReports')} - {instrument}
          </CardTitle>
        </CardHeader>
        <CardContent>
          {reports.length === 0 ? (
            <div className="text-center py-12">
              <FileText className="w-12 h-12 text-slate-600 mx-auto mb-4" />
              <p className="text-slate-400">{t('noReportsYet')}</p>
              <p className="text-slate-500 text-sm mt-2">{t('useGenerateReport')}</p>
            </div>
          ) : (
            <div className="space-y-3">
              {reports.map((report) => (
                <div key={report.id} className="bg-slate-800 rounded-lg p-4 border border-slate-700 hover:border-slate-600 transition-colors">
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <Badge className={getReportTypeColor(report.report_type)}>
                          {report.report_type}
                        </Badge>
                        <span className="text-xs text-slate-500 flex items-center gap-1">
                          <Calendar className="w-3 h-3" />
                          {new Date(report.created_at_utc).toLocaleDateString()} - {new Date(report.created_at_utc).toLocaleTimeString()}
                        </span>
                      </div>
                      <h3 className="text-white font-medium mb-1">{report.title}</h3>
                      {report.sources_used && report.sources_used.length > 0 && (
                        <div className="flex flex-wrap gap-1 mt-2">
                          {report.sources_used.slice(0, 3).map((source, idx) => (
                            <Badge key={idx} variant="outline" className="text-xs">
                              {source}
                            </Badge>
                          ))}
                          {report.sources_used.length > 3 && (
                            <Badge variant="outline" className="text-xs">
                              +{report.sources_used.length - 3} more
                            </Badge>
                          )}
                        </div>
                      )}
                    </div>
                    <div className="flex items-center gap-2">
                      <Button
                        size="sm"
                        onClick={() => handleViewReport(report)}
                        className="bg-blue-600 hover:bg-blue-700"
                      >
                        <Eye className="w-4 h-4 mr-1" />
                        {t('view')}
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleTranslateReport(report)}
                        disabled={translatingId === report.id}
                        className="border-purple-600 text-purple-400 hover:bg-purple-950"
                      >
                        <Languages className="w-4 h-4 mr-1" />
                        {translatingId === report.id ? t('translating') : t('translate')}
                      </Button>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => handleDeleteReport(report.id)}
                        className="text-red-400 hover:text-red-300 hover:bg-red-950"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* View Report Dialog */}
      <Dialog open={viewDialogOpen} onOpenChange={setViewDialogOpen}>
        <DialogContent className="bg-slate-950 border-slate-700 text-white max-w-6xl max-h-[90vh] overflow-y-auto">
          <DialogHeader className="border-b border-slate-800 pb-4">
            <DialogTitle className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-lg flex items-center justify-center">
                <FileText className="w-5 h-5 text-white" />
              </div>
              <div>
                <h2 className="text-xl font-bold">{selectedReport?.title}</h2>
                <div className="flex items-center gap-2 mt-1">
                  <Badge className={getReportTypeColor(selectedReport?.report_type)}>
                    {selectedReport?.report_type}
                  </Badge>
                  <span className="text-xs text-slate-500">
                    {new Date(selectedReport?.created_at_utc).toLocaleString()}
                  </span>
                </div>
              </div>
            </DialogTitle>
          </DialogHeader>
          {selectedReport && (
            <div className="space-y-6 pt-4">
              {selectedReport.sources_used && selectedReport.sources_used.length > 0 && (
                <div className="bg-slate-900/50 rounded-lg p-4 border border-slate-800">
                  <p className="text-sm font-semibold text-slate-400 mb-3 flex items-center gap-2">
                    <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                      <path d="M9 2a1 1 0 000 2h2a1 1 0 100-2H9z"/>
                      <path fillRule="evenodd" d="M4 5a2 2 0 012-2 3 3 0 003 3h2a3 3 0 003-3 2 2 0 012 2v11a2 2 0 01-2 2H6a2 2 0 01-2-2V5zm3 4a1 1 0 000 2h.01a1 1 0 100-2H7zm3 0a1 1 0 000 2h3a1 1 0 100-2h-3zm-3 4a1 1 0 100 2h.01a1 1 0 100-2H7zm3 0a1 1 0 100 2h3a1 1 0 100-2h-3z" clipRule="evenodd"/>
                    </svg>
                    {t('sources')}
                  </p>
                  <div className="flex flex-wrap gap-2">
                    {selectedReport.sources_used.map((source, idx) => (
                      <Badge key={idx} variant="outline" className="text-xs bg-slate-800 border-slate-700">
                        {source}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}

              <div className="prose prose-invert prose-lg max-w-none report-content">
                <ReactMarkdown
                  components={{
                    h1: ({ children }) => (
                      <h1 className="text-3xl font-bold text-white mb-6 mt-8 pb-3 border-b border-slate-700">
                        {children}
                      </h1>
                    ),
                    h2: ({ children }) => (
                      <h2 className="text-2xl font-bold text-white mb-4 mt-8 flex items-center gap-2">
                        <span className="w-1 h-6 bg-blue-500 rounded-full"></span>
                        {children}
                      </h2>
                    ),
                    h3: ({ children }) => (
                      <h3 className="text-xl font-semibold text-slate-200 mb-3 mt-6">{children}</h3>
                    ),
                    p: ({ children }) => <p className="text-slate-300 mb-4 leading-relaxed text-base">{children}</p>,
                    ul: ({ children }) => <ul className="list-disc list-inside text-slate-300 mb-4 space-y-2">{children}</ul>,
                    ol: ({ children }) => <ol className="list-decimal list-inside text-slate-300 mb-4 space-y-2">{children}</ol>,
                    li: ({ children }) => <li className="mb-2 text-slate-300">{children}</li>,
                    strong: ({ children }) => <strong className="text-white font-bold">{children}</strong>,
                    table: ({ children }) => (
                      <div className="my-6 overflow-x-auto">
                        <table className="w-full border-collapse bg-slate-900 rounded-lg overflow-hidden">
                          {children}
                        </table>
                      </div>
                    ),
                    thead: ({ children }) => (
                      <thead className="bg-slate-800 border-b-2 border-slate-700">
                        {children}
                      </thead>
                    ),
                    tbody: ({ children }) => <tbody className="divide-y divide-slate-800">{children}</tbody>,
                    tr: ({ children }) => <tr className="hover:bg-slate-800/50 transition-colors">{children}</tr>,
                    th: ({ children }) => (
                      <th className="px-6 py-4 text-left text-sm font-bold text-slate-200 uppercase tracking-wider">
                        {children}
                      </th>
                    ),
                    td: ({ children }) => (
                      <td className="px-6 py-4 text-sm text-slate-300 align-top">
                        {children}
                      </td>
                    ),
                    blockquote: ({ children }) => (
                      <blockquote className="border-l-4 border-blue-500 pl-4 py-2 my-4 bg-blue-900/20 rounded-r">
                        {children}
                      </blockquote>
                    ),
                    code: ({ inline, children }) => 
                      inline ? (
                        <code className="px-2 py-1 bg-slate-800 rounded text-blue-300 text-sm font-mono">
                          {children}
                        </code>
                      ) : (
                        <code className="block bg-slate-900 p-4 rounded-lg text-sm font-mono overflow-x-auto">
                          {children}
                        </code>
                      )
                  }}
                >
                  {selectedReport.content_md}
                </ReactMarkdown>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}