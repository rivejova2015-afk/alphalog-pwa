import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Calendar } from 'lucide-react';
import { useTranslation } from '@/components/utils/translations';

export default function TodayCard({ events = [], instrument }) {
  const { t } = useTranslation();
  return (
    <Card className="bg-slate-900 border-slate-800">
      <CardHeader className="pb-3">
        <CardTitle className="text-white text-sm flex items-center gap-2">
          <Calendar className="w-4 h-4 text-amber-400" />
          {t('today')}
        </CardTitle>
      </CardHeader>
      <CardContent>
        {events.length === 0 ? (
          <p className="text-slate-400 text-sm">{t('noEventsToday')}</p>
        ) : (
          <div className="space-y-2">
            {events.map((event, idx) => (
              <div key={idx} className="text-sm text-slate-300">
                {event.name}
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}