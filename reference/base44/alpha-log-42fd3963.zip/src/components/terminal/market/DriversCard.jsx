import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Compass } from 'lucide-react';
import { useTranslation } from '@/components/utils/translations';

export default function DriversCard({ drivers = [] }) {
  const { t } = useTranslation();
  return (
    <Card className="bg-slate-900 border-slate-800">
      <CardHeader className="pb-3">
        <CardTitle className="text-white text-sm flex items-center gap-2">
          <Compass className="w-4 h-4 text-purple-400" />
          Drivers
        </CardTitle>
      </CardHeader>
      <CardContent>
        {drivers.length === 0 ? (
          <p className="text-slate-400 text-sm">No drivers yet</p>
        ) : (
          <div className="space-y-2">
            {drivers.map((driver, idx) => (
              <div key={idx} className="text-sm text-slate-300">
                {driver}
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}