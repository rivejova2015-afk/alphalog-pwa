import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Shield } from 'lucide-react';
import { useTranslation } from '@/components/utils/translations';

export default function EvidenceCard() {
  const { t } = useTranslation();
  const sources = [
    { name: 'Reuters', status: 'VERIFIED' },
    { name: 'Bloomberg', status: 'VERIFIED' },
    { name: 'Fed', status: 'VERIFIED' }
  ];

  return (
    <Card className="bg-slate-900 border-slate-800">
      <CardHeader className="pb-3">
        <CardTitle className="text-white text-sm flex items-center gap-2">
          <Shield className="w-4 h-4 text-cyan-400" />
          Evidence
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-2">
        {sources.map((source, idx) => (
          <div key={idx} className="flex items-center justify-between bg-slate-800 rounded px-3 py-2">
            <span className="text-sm text-slate-300">{source.name}</span>
            <Badge className="bg-green-600 text-white text-xs">
              {source.status}
            </Badge>
          </div>
        ))}
      </CardContent>
    </Card>
  );
}