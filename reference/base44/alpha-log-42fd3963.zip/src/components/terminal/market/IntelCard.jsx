import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Globe } from 'lucide-react';
import { useTranslation } from '@/components/utils/translations';

export default function IntelCard({ claims = [] }) {
  const { t } = useTranslation();
  return (
    <Card className="bg-slate-900 border-slate-800">
      <CardHeader className="pb-3">
        <CardTitle className="text-white text-sm flex items-center gap-2">
          <Globe className="w-4 h-4 text-blue-400" />
          {t('intel')}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <Badge className="bg-green-600 text-white mb-3">
          {t('claimsVerified')}
        </Badge>
        {claims.length === 0 ? (
          <p className="text-slate-400 text-sm">{t('noVerifiedClaims')}</p>
        ) : (
          <div className="space-y-2">
            {claims.map((claim, idx) => (
              <div key={idx} className="text-sm text-slate-300">
                {claim.statement || claim}
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}