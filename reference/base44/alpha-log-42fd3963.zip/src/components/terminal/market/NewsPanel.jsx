import React from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Newspaper } from 'lucide-react';
import { useTranslation } from '@/components/utils/translations';
import ReportGenerator from '../ReportGenerator';

export default function NewsPanel({ instrument }) {
  const { t } = useTranslation();
  const queryClient = useQueryClient();

  const { data: news = [] } = useQuery({
    queryKey: ['terminal-news', instrument],
    queryFn: async () => {
      return await base44.entities.TerminalNews.filter({
        instrument_id: instrument
      }, '-timestamp_utc', 20);
    }
  });

  const handleReportGenerated = () => {
    queryClient.invalidateQueries(['terminal-reports', instrument]);
  };

  return (
    <Card className="bg-slate-900 border-slate-800">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-white text-sm flex items-center gap-2">
            <Newspaper className="w-4 h-4 text-blue-400" />
            {t('newsIntelligence')}
          </CardTitle>

          <ReportGenerator 
            instrument={instrument}
            onReportGenerated={handleReportGenerated}
          />
        </div>
      </CardHeader>
      
      <CardContent>
        <Tabs defaultValue="news" className="w-full">
          <TabsList className="bg-slate-800 border-slate-700">
            <TabsTrigger value="news">{t('news')}</TabsTrigger>
            <TabsTrigger value="drivers">{t('drivers')}</TabsTrigger>
            <TabsTrigger value="evidence">{t('evidencePacks')}</TabsTrigger>
            <TabsTrigger value="sessions">{t('sessions')}</TabsTrigger>
          </TabsList>

          <TabsContent value="news" className="space-y-2 pt-4">
            {news.map(item => (
              <div key={item.id} className="bg-slate-800 rounded p-3 hover:bg-slate-700 transition-colors">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1">
                    <a 
                      href={item.url} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="text-sm text-white hover:text-blue-400 transition-colors"
                    >
                      {item.title}
                    </a>
                    {item.summary_1line && (
                      <p className="text-xs text-slate-400 mt-1">{item.summary_1line}</p>
                    )}
                  </div>
                  
                  <div className="flex flex-col items-end gap-2">
                    <Badge variant="outline" className="text-xs whitespace-nowrap">
                      {item.source}
                    </Badge>
                    {item.relevancy_score && (
                      <div className="text-xs text-slate-400">
                        Impact: {item.relevancy_score}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ))}

            {news.length === 0 && (
              <p className="text-slate-500 text-center py-8">{t('noNewsAvailable')}</p>
            )}
            </TabsContent>

            <TabsContent value="drivers">
            <p className="text-slate-500 text-center py-8">{t('driversDataComingSoon')}</p>
            </TabsContent>

            <TabsContent value="evidence">
            <p className="text-slate-500 text-center py-8">{t('evidencePacksComingSoon')}</p>
            </TabsContent>

            <TabsContent value="sessions">
            <p className="text-slate-500 text-center py-8">{t('sessionsStatsComingSoon')}</p>
            </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}