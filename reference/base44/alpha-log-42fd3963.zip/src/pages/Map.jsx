import React, { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Map as MapIcon, TrendingUp, Target, Shield, Zap, Award, Lock, CheckCircle2, ChevronLeft, Info, Trophy, Star, Sparkles } from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import confetti from 'canvas-confetti';

export default function Map() {
  const [selectedLevel, setSelectedLevel] = useState(null);
  const [levelUpCelebration, setLevelUpCelebration] = useState(null);
  const queryClient = useQueryClient();

  const { data: progress } = useQuery({
    queryKey: ['map-progress'],
    queryFn: async () => {
      const progs = await base44.entities.MapProgress.list();
      if (progs.length === 0) {
        return await base44.entities.MapProgress.create({
          current_level: 1,
          total_xp: 0,
          level_xp: 0,
          active_route: 'SAFE'
        });
      }
      return progs[0];
    }
  });

  const updateMutation = useMutation({
    mutationFn: ({ field, value }) => {
      if (progress) {
        if (field === 'multiple') {
          return base44.entities.MapProgress.update(progress.id, value);
        }
        return base44.entities.MapProgress.update(progress.id, { [field]: value });
      }
    },
    onSuccess: () => queryClient.invalidateQueries(['map-progress'])
  });

  const getLevelTasks = (level) => {
    const tasks = {
      1: [
        'Completa tu primera semana de trading consistente',
        'Registra al menos 5 trades en tu journal',
        'Configura tu cuenta Darwinex Zero (CORE)'
      ],
      2: [
        'Alcanza un win rate del 40% en 15+ trades',
        'Aprueba tu primera fase de PropFirm',
        'Opera 1 slot PropFirm + cuenta Darwinex'
      ],
      3: [
        'Documenta 3 setups en tu Playbook',
        'Mantén profit factor superior a 1.5',
        'Replica estrategia en 2 cuentas PropFirm'
      ],
      4: [
        'Gestiona 2 slots PropFirm + Darwinex consistentemente',
        'Logra 50+ trades con edge positivo',
        'Win rate sostenido del 45%+ por 3 semanas'
      ],
      5: [
        'Opera 3 cuentas PropFirm en fase funded',
        'Mantén consistency score del 70%+ en Darwinex',
        'Profit factor 1.8+ en las últimas 100 operaciones'
      ],
      6: [
        'Gestiona 4 slots PropFirm + Darwinex Zero',
        'Mantén racha de 5+ semanas con P&L positivo',
        'Sistema de replicación funcionando en paralelo'
      ],
      7: [
        'Opera 6 cuentas PropFirm replicadas desde Darwinex',
        'Win rate del 50%+ sostenido por 2 meses',
        'Genera tu primer AlphaBrief mensual con AI'
      ],
      8: [
        'Gestiona 8 slots PropFirm activos simultáneamente',
        'Demuestra consistencia de 3+ meses rentables',
        'Profit factor 2.0+ en sistema de replicación'
      ],
      9: [
        'Opera las 10 cuentas PropFirm + Darwinex en paralelo',
        '6+ meses consecutivos de rentabilidad comprobada',
        'Sistema de gestión de riesgo multi-cuenta optimizado'
      ],
      10: [
        'Maestría total: 10 PropFirms + Darwinex Zero sincronizados',
        '1+ año de track record consistente y verificable',
        'Profit factor 2.5+ con drawdown máximo del 10%',
        'Sistema escalable listo para capital institucional'
      ]
    };
    return tasks[level] || [];
  };

  const levels = [
    { level: 1, name: 'Paper Hands', xpNeeded: 100, unlocks: 'Basic Journal' },
    { level: 2, name: 'Apprentice', xpNeeded: 250, unlocks: '1 PropFirm Slot' },
    { level: 3, name: 'Student', xpNeeded: 500, unlocks: 'Setup Library' },
    { level: 4, name: 'Practitioner', xpNeeded: 1000, unlocks: '2 PropFirm Slots' },
    { level: 5, name: 'Journeyman', xpNeeded: 2000, unlocks: 'Advanced Analytics' },
    { level: 6, name: 'Expert', xpNeeded: 4000, unlocks: '3 PropFirm Slots' },
    { level: 7, name: 'Master', xpNeeded: 8000, unlocks: 'AI Trade Analysis' },
    { level: 8, name: 'Elite', xpNeeded: 16000, unlocks: '4 PropFirm Slots' },
    { level: 9, name: 'Legend', xpNeeded: 32000, unlocks: 'All Features' },
    { level: 10, name: 'Apex Predator', xpNeeded: 64000, unlocks: 'Unlimited Access' }
  ];

  const currentLevel = progress?.current_level || 1;
  const currentLevelData = levels[currentLevel - 1];
  const nextLevelData = levels[currentLevel];
  const levelProgress = nextLevelData ? ((progress?.level_xp || 0) / nextLevelData.xpNeeded) * 100 : 100;

  const switchRoute = () => {
    const newRoute = progress?.active_route === 'SAFE' ? 'FAST' : 'SAFE';
    updateMutation.mutate({ field: 'active_route', value: newRoute });
  };

  const toggleTask = (levelNum, taskIndex) => {
    if (!progress) return;

    const completedTasks = progress.completed_tasks || {};
    const levelTasks = completedTasks[levelNum] || [];
    const isCompleted = levelTasks.includes(taskIndex);

    let newLevelTasks;
    if (isCompleted) {
      newLevelTasks = levelTasks.filter(t => t !== taskIndex);
    } else {
      newLevelTasks = [...levelTasks, taskIndex];
    }

    const newCompletedTasks = {
      ...completedTasks,
      [levelNum]: newLevelTasks
    };

    const totalTasksInLevel = getLevelTasks(levelNum).length;
    const xpPerTask = levels[levelNum - 1].xpNeeded / totalTasksInLevel;
    const tasksCompleted = newLevelTasks.length;
    const earnedXP = Math.floor(xpPerTask * tasksCompleted);

    // Check if all tasks are completed
    const allTasksCompleted = tasksCompleted === totalTasksInLevel;
    const isCurrentLevel = levelNum === currentLevel;
    const canLevelUp = allTasksCompleted && isCurrentLevel && currentLevel < 10;

    let updateData = {
      completed_tasks: newCompletedTasks,
      level_xp: isCurrentLevel ? earnedXP : progress.level_xp
    };

    // Auto level up if all tasks completed
    if (canLevelUp) {
      const newLevel = currentLevel + 1;
      updateData = {
        ...updateData,
        current_level: newLevel,
        level_xp: 0,
        completed_levels: [...(progress.completed_levels || []), currentLevel],
        total_xp: (progress.total_xp || 0) + levels[levelNum - 1].xpNeeded
      };

      // Trigger celebration after update
      setTimeout(() => {
        triggerLevelUpCelebration(newLevel);
      }, 500);
    }

    updateMutation.mutate({
      field: 'multiple',
      value: updateData
    });
  };

  const triggerLevelUpCelebration = (newLevel) => {
    // Confetti explosion
    const duration = 3000;
    const animationEnd = Date.now() + duration;
    const defaults = { startVelocity: 30, spread: 360, ticks: 60, zIndex: 9999 };

    function randomInRange(min, max) {
      return Math.random() * (max - min) + min;
    }

    const interval = setInterval(function() {
      const timeLeft = animationEnd - Date.now();

      if (timeLeft <= 0) {
        return clearInterval(interval);
      }

      const particleCount = 50 * (timeLeft / duration);
      
      confetti({
        ...defaults,
        particleCount,
        origin: { x: randomInRange(0.1, 0.3), y: Math.random() - 0.2 }
      });
      confetti({
        ...defaults,
        particleCount,
        origin: { x: randomInRange(0.7, 0.9), y: Math.random() - 0.2 }
      });
    }, 250);

    // Show celebration modal
    setLevelUpCelebration(newLevel);
  };

  const goToNextLevel = () => {
    if (!progress || currentLevel >= 10) return;

    const completedTasks = progress.completed_tasks || {};
    const levelTasks = completedTasks[currentLevel] || [];
    const totalTasks = getLevelTasks(currentLevel).length;
    const allTasksCompleted = levelTasks.length === totalTasks;

    if (!allTasksCompleted) return;

    const newLevel = currentLevel + 1;
    updateMutation.mutate({
      field: 'multiple',
      value: {
        current_level: newLevel,
        level_xp: 0,
        completed_levels: [...(progress.completed_levels || []), currentLevel],
        total_xp: (progress.total_xp || 0) + levels[currentLevel - 1].xpNeeded
      }
    });

    setTimeout(() => {
      triggerLevelUpCelebration(newLevel);
    }, 500);
  };

  return (
    <div className="min-h-screen bg-slate-950 p-6">
      <div className="max-w-7xl mx-auto">
        <Link to={createPageUrl('Dashboard')}>
          <Button variant="ghost" size="sm" className="text-slate-400 hover:text-white mb-4">
            <ChevronLeft className="w-4 h-4 mr-1" />
            Atrás
          </Button>
        </Link>
        <div className="flex items-center gap-3 mb-6">
          <MapIcon className="w-8 h-8 text-indigo-400" />
          <h1 className="text-3xl font-bold text-white">Trader's Journey Map</h1>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
          <Card className="bg-slate-900 border-slate-800">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Award className="w-5 h-5 text-amber-400" />
                Current Level
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="flex items-baseline gap-2">
                  <span className="text-4xl font-bold text-white">{currentLevel}</span>
                  <span className="text-lg text-slate-400">/ 10</span>
                </div>
                <p className="text-xl font-bold text-amber-400">{currentLevelData?.name}</p>
                {nextLevelData && (
                  <>
                    <div className="pt-4">
                      <div className="flex justify-between text-sm mb-2">
                        <span className="text-slate-400">Progress to Level {currentLevel + 1}</span>
                        <span className="text-white font-medium">{progress?.level_xp || 0} / {nextLevelData.xpNeeded} XP</span>
                      </div>
                      <Progress value={levelProgress} className="h-2" />
                    </div>
                    <p className="text-xs text-slate-400 pt-2">
                      Next unlock: {nextLevelData.unlocks}
                    </p>
                    {(() => {
                      const completedTasks = progress?.completed_tasks || {};
                      const levelTasks = completedTasks[currentLevel] || [];
                      const totalTasks = getLevelTasks(currentLevel).length;
                      const allTasksCompleted = levelTasks.length === totalTasks;
                      
                      return allTasksCompleted && (
                        <Button
                          onClick={goToNextLevel}
                          className="w-full mt-4 bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 text-white font-bold shadow-lg"
                        >
                          <Zap className="w-4 h-4 mr-2" />
                          Siguiente Nivel
                        </Button>
                      );
                    })()}
                  </>
                )}
              </div>
            </CardContent>
          </Card>

          <Card className="bg-slate-900 border-slate-800">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-green-400" />
                Stats
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-slate-400">Confidence</span>
                <span className="text-white font-bold">{progress?.confidence_meter || 50}%</span>
              </div>
              <Progress value={progress?.confidence_meter || 50} className="h-2" />
              
              <div className="flex justify-between items-center pt-2">
                <span className="text-slate-400">Edge Consistency</span>
                <span className="text-white font-bold">{progress?.edge_consistency_score || 50}%</span>
              </div>
              <Progress value={progress?.edge_consistency_score || 50} className="h-2" />

              <div className="flex justify-between items-center pt-2">
                <span className="text-slate-400">Daily Streak</span>
                <span className="text-white font-bold">{progress?.daily_streak || 0} days</span>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-slate-900 border-slate-800">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Target className="w-5 h-5 text-blue-400" />
                Active Route
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <Badge className={progress?.active_route === 'SAFE' ? 'bg-green-600' : 'bg-orange-600'}>
                      {progress?.active_route || 'SAFE'}
                    </Badge>
                    <p className="text-xs text-slate-400 mt-2">
                      {progress?.active_route === 'SAFE' 
                        ? 'Conservative progression with lower risk'
                        : 'Aggressive progression with higher rewards'}
                    </p>
                  </div>
                </div>
                <Button 
                  onClick={switchRoute}
                  variant="outline"
                  className="w-full"
                >
                  Switch to {progress?.active_route === 'SAFE' ? 'FAST' : 'SAFE'} Route
                </Button>

                <div className="pt-4 border-t border-slate-800">
                  <p className="text-xs text-slate-400 mb-2">PropFirm Slots</p>
                  <p className="text-2xl font-bold text-white">{progress?.unlocked_propfirm_slots || 0}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {(progress?.recovery_mode_active || progress?.fail_safe_active) && (
          <Card className="bg-orange-950 border-orange-800 mb-6">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Shield className="w-5 h-5 text-orange-400" />
                Protection Active
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {progress.recovery_mode_active && (
                  <div className="flex items-center gap-2">
                    <Badge className="bg-orange-600">Recovery Mode</Badge>
                    <p className="text-sm text-orange-200">Reduced position sizes active</p>
                  </div>
                )}
                {progress.fail_safe_active && (
                  <div className="flex items-center gap-2">
                    <Badge className="bg-red-600">Fail-Safe</Badge>
                    <p className="text-sm text-red-200">Trading paused - review required</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Duolingo-Style Level Path */}
        <Card className="bg-slate-900 border-slate-800">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Target className="w-5 h-5 text-yellow-400" />
              Tu Camino de Progresión
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="relative py-4">
              {/* Vertical Path Line */}
              <div className="absolute left-10 top-0 bottom-0 w-1 bg-gradient-to-b from-slate-700 via-slate-600 to-slate-700" />
              
              <div className="space-y-8 relative">
                {levels.map((lvl, index) => {
                  const isCompleted = progress?.completed_levels?.includes(lvl.level);
                  const isCurrent = lvl.level === currentLevel;
                  const isLocked = lvl.level > currentLevel;
                  const isNext = lvl.level === currentLevel + 1;

                  return (
                    <div
                      key={lvl.level}
                      className={`relative flex items-start gap-6 transition-all duration-300 ${
                        isCurrent ? 'scale-105' : ''
                      }`}
                    >
                      {/* Level Circle Icon */}
                      <div className="relative z-10 flex-shrink-0">
                        <div
                          className={`w-20 h-20 rounded-full flex flex-col items-center justify-center font-bold transition-all duration-300 ${
                            isCompleted
                              ? 'bg-gradient-to-br from-green-500 to-emerald-600 shadow-lg shadow-green-500/50'
                              : isCurrent
                              ? 'bg-gradient-to-br from-yellow-400 to-orange-500 shadow-lg shadow-yellow-500/50 animate-pulse'
                              : isNext
                              ? 'bg-gradient-to-br from-blue-500 to-indigo-600 shadow-md shadow-blue-500/30'
                              : isLocked
                              ? 'bg-slate-800 border-2 border-slate-700'
                              : 'bg-gradient-to-br from-slate-600 to-slate-700'
                          }`}
                        >
                          {isCompleted ? (
                            <CheckCircle2 className="w-10 h-10 text-white" />
                          ) : isLocked ? (
                            <Lock className="w-8 h-8 text-slate-500" />
                          ) : (
                            <>
                              <span className="text-2xl text-white">{lvl.level}</span>
                              <Zap className="w-4 h-4 text-white -mt-1" />
                            </>
                          )}
                        </div>
                        
                        {/* Animated Sparkles for Current Level */}
                        {isCurrent && (
                          <>
                            <div className="absolute -top-2 -right-2 w-5 h-5 bg-yellow-300 rounded-full animate-ping" />
                            <div className="absolute -bottom-2 -left-2 w-4 h-4 bg-orange-400 rounded-full animate-ping delay-75" />
                            <div className="absolute top-1/2 -right-3 w-3 h-3 bg-yellow-400 rounded-full animate-bounce" />
                          </>
                        )}
                      </div>

                      {/* Level Content Card */}
                      <div
                        className={`flex-1 rounded-xl transition-all duration-300 ${
                          isCurrent
                            ? 'bg-gradient-to-r from-yellow-500/10 to-orange-500/10 border-2 border-yellow-500/40 shadow-xl p-5'
                            : isCompleted
                            ? 'bg-green-500/5 border-2 border-green-600/30 p-5'
                            : isLocked
                            ? 'bg-slate-800/40 border border-slate-700/50 opacity-60 p-5'
                            : 'bg-slate-800/70 border border-slate-700/50 p-5'
                        }`}
                      >
                        <div className="flex items-start justify-between mb-3">
                          <div className="flex-1">
                            <h3 className={`text-xl font-bold mb-1 ${
                              isCurrent ? 'text-yellow-400' : isCompleted ? 'text-green-400' : 'text-white'
                            }`}>
                              {lvl.name}
                            </h3>
                            <p className="text-sm text-slate-400">
                              {lvl.xpNeeded.toLocaleString()} XP requeridos
                            </p>
                          </div>
                          
                          <div className="flex flex-col items-end gap-2">
                            {isCompleted && (
                              <Badge className="bg-green-600 border-0 text-sm">
                                ✓ Completado
                              </Badge>
                            )}
                            {isCurrent && (
                              <Badge className="bg-gradient-to-r from-yellow-500 to-orange-500 text-slate-900 border-0 text-sm font-bold">
                                ⚡ Nivel Actual
                              </Badge>
                            )}
                            {isNext && !isCurrent && (
                              <Badge className="bg-blue-600 border-0 text-sm">
                                → Siguiente
                              </Badge>
                            )}
                            {isLocked && !isNext && (
                              <Badge variant="outline" className="border-slate-600 text-slate-500 text-sm">
                                🔒 Bloqueado
                              </Badge>
                            )}
                          </div>
                        </div>
                        
                        <div className="flex items-center justify-between gap-3 mb-3">
                          <div className="flex items-center gap-2">
                            <Award className="w-4 h-4 text-amber-400" />
                            <p className="text-sm text-slate-300 font-medium">
                              Desbloquea: {lvl.unlocks}
                            </p>
                          </div>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => setSelectedLevel(lvl)}
                            className="text-xs border-slate-600 hover:border-slate-500"
                          >
                            <Info className="w-3 h-3 mr-1" />
                            Detalles
                          </Button>
                        </div>
                        
                        {/* Progress Bar for Current Level */}
                        {isCurrent && (
                          <div className="mt-4 pt-4 border-t border-slate-700/50">
                            <div className="flex justify-between text-xs font-medium text-slate-400 mb-2">
                              <span>Tu Progreso</span>
                              <span className="text-yellow-400">
                                {progress?.level_xp?.toLocaleString() || 0} / {lvl.xpNeeded.toLocaleString()} XP
                              </span>
                            </div>
                            <div className="h-3 bg-slate-800 rounded-full overflow-hidden shadow-inner">
                              <div
                                className="h-full bg-gradient-to-r from-yellow-400 via-orange-400 to-orange-500 transition-all duration-500 shadow-md"
                                style={{
                                  width: `${Math.min(100, ((progress?.level_xp || 0) / lvl.xpNeeded) * 100)}%`
                                }}
                              />
                            </div>
                            <p className="text-xs text-slate-500 mt-2 text-center">
                              {Math.round(((progress?.level_xp || 0) / lvl.xpNeeded) * 100)}% completado
                            </p>
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Level Up Celebration Modal */}
        {levelUpCelebration && (
          <Dialog open={!!levelUpCelebration} onOpenChange={() => setLevelUpCelebration(null)}>
            <DialogContent className="bg-gradient-to-br from-yellow-500/20 via-orange-500/20 to-red-500/20 border-4 border-yellow-500 text-white max-w-2xl">
              <div className="text-center py-8">
                <div className="relative inline-block mb-6">
                  <Trophy className="w-32 h-32 text-yellow-400 animate-bounce" />
                  <Sparkles className="w-12 h-12 text-yellow-300 absolute -top-4 -right-4 animate-pulse" />
                  <Star className="w-10 h-10 text-orange-400 absolute -bottom-2 -left-2 animate-spin" />
                </div>
                
                <h2 className="text-5xl font-bold mb-4 bg-gradient-to-r from-yellow-400 via-orange-400 to-red-500 bg-clip-text text-transparent">
                  ¡LEVEL UP!
                </h2>
                
                <div className="mb-6">
                  <p className="text-3xl font-bold text-white mb-2">
                    Has alcanzado el Nivel {levelUpCelebration}
                  </p>
                  <p className="text-2xl text-yellow-300 font-semibold">
                    {levels[levelUpCelebration - 1]?.name}
                  </p>
                </div>

                <div className="bg-slate-900/50 rounded-xl p-6 mb-6 border-2 border-yellow-500/30">
                  <div className="flex items-center justify-center gap-3 mb-4">
                    <Award className="w-8 h-8 text-amber-400" />
                    <h3 className="text-xl font-bold text-white">Nuevo Desbloqueo</h3>
                  </div>
                  <p className="text-2xl text-green-400 font-bold">
                    {levels[levelUpCelebration - 1]?.unlocks}
                  </p>
                </div>

                <div className="space-y-2 mb-6">
                  <Badge className="bg-gradient-to-r from-yellow-500 to-orange-500 text-slate-900 text-lg px-6 py-2 mr-2">
                    +{levels[levelUpCelebration - 2]?.xpNeeded.toLocaleString() || 0} XP
                  </Badge>
                  <Badge className="bg-purple-600 text-lg px-6 py-2">
                    Total: {progress?.total_xp?.toLocaleString() || 0} XP
                  </Badge>
                </div>

                <Button
                  onClick={() => setLevelUpCelebration(null)}
                  className="bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-600 hover:to-orange-600 text-slate-900 font-bold text-lg px-8 py-6 shadow-lg"
                >
                  ¡Continuar mi Camino!
                </Button>

                <p className="text-slate-400 text-sm mt-4">
                  Sigue completando objetivos para alcanzar el siguiente nivel
                </p>
              </div>
            </DialogContent>
          </Dialog>
        )}

        {/* Level Details Dialog */}
        {selectedLevel && (
          <Dialog open={!!selectedLevel} onOpenChange={() => setSelectedLevel(null)}>
            <DialogContent className="bg-slate-900 border-slate-800 text-white max-w-2xl">
              <DialogHeader>
                <DialogTitle className="text-2xl flex items-center gap-3">
                  <div className={`w-12 h-12 rounded-full flex items-center justify-center ${
                    progress?.completed_levels?.includes(selectedLevel.level)
                      ? 'bg-gradient-to-br from-green-500 to-emerald-600'
                      : selectedLevel.level === currentLevel
                      ? 'bg-gradient-to-br from-yellow-400 to-orange-500'
                      : selectedLevel.level > currentLevel
                      ? 'bg-slate-800 border-2 border-slate-700'
                      : 'bg-gradient-to-br from-slate-600 to-slate-700'
                  }`}>
                    {progress?.completed_levels?.includes(selectedLevel.level) ? (
                      <CheckCircle2 className="w-6 h-6 text-white" />
                    ) : selectedLevel.level > currentLevel ? (
                      <Lock className="w-6 h-6 text-slate-400" />
                    ) : (
                      <span className="text-xl text-white">{selectedLevel.level}</span>
                    )}
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-white">Nivel {selectedLevel.level}</div>
                    <div className={`text-lg ${
                      selectedLevel.level === currentLevel ? 'text-yellow-400' :
                      progress?.completed_levels?.includes(selectedLevel.level) ? 'text-green-400' :
                      'text-slate-400'
                    }`}>
                      {selectedLevel.name}
                    </div>
                  </div>
                </DialogTitle>
              </DialogHeader>

              <div className="space-y-6 mt-4">
                {/* Requirements */}
                <div className="bg-slate-800/50 rounded-lg p-4 border border-slate-700">
                  <h3 className="text-sm font-semibold text-slate-400 uppercase mb-3 flex items-center gap-2">
                    <Target className="w-4 h-4" />
                    Requerimientos
                  </h3>
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="text-white">XP Total Necesario</span>
                      <Badge variant="outline" className="text-lg">
                        {selectedLevel.xpNeeded.toLocaleString()} XP
                      </Badge>
                    </div>
                    {selectedLevel.level > 1 && (
                      <div className="flex justify-between items-center">
                        <span className="text-slate-300 text-sm">XP desde nivel anterior</span>
                        <span className="text-slate-400 text-sm">
                          +{(selectedLevel.xpNeeded - (levels[selectedLevel.level - 2]?.xpNeeded || 0)).toLocaleString()} XP
                        </span>
                      </div>
                    )}
                  </div>
                </div>

                {/* Unlocks */}
                <div className="bg-slate-800/50 rounded-lg p-4 border border-slate-700">
                  <h3 className="text-sm font-semibold text-slate-400 uppercase mb-3 flex items-center gap-2">
                    <Award className="w-4 h-4" />
                    Desbloqueos
                  </h3>
                  <p className="text-white text-lg">{selectedLevel.unlocks}</p>
                </div>

                {/* Objectives with Checkboxes */}
                <div className="bg-slate-800/50 rounded-lg p-4 border border-slate-700">
                  <h3 className="text-sm font-semibold text-slate-400 uppercase mb-3 flex items-center gap-2">
                    <Zap className="w-4 h-4" />
                    Objetivos - Marca los completados para ganar XP
                  </h3>
                  <div className="space-y-3">
                    {getLevelTasks(selectedLevel.level).map((task, index) => {
                      const completedTasks = progress?.completed_tasks || {};
                      const levelTasks = completedTasks[selectedLevel.level] || [];
                      const isCompleted = levelTasks.includes(index);
                      const xpPerTask = Math.floor(selectedLevel.xpNeeded / getLevelTasks(selectedLevel.level).length);

                      return (
                        <div
                          key={index}
                          className={`flex items-start gap-3 p-3 rounded-lg border transition-all ${
                            isCompleted
                              ? 'bg-green-500/10 border-green-600/30'
                              : 'bg-slate-800/30 border-slate-700/50 hover:border-slate-600'
                          }`}
                        >
                          <input
                            type="checkbox"
                            checked={isCompleted}
                            onChange={() => toggleTask(selectedLevel.level, index)}
                            className="mt-1 w-5 h-5 rounded border-slate-600 text-green-600 focus:ring-green-500 cursor-pointer"
                          />
                          <div className="flex-1">
                            <p className={`text-sm ${isCompleted ? 'text-green-400 line-through' : 'text-slate-300'}`}>
                              {task}
                            </p>
                            <p className="text-xs text-slate-500 mt-1">
                              +{xpPerTask} XP
                            </p>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                  <div className="mt-4 pt-4 border-t border-slate-700">
                    <div className="flex justify-between text-sm">
                      <span className="text-slate-400">Progreso de Objetivos</span>
                      <span className="text-white font-bold">
                        {(progress?.completed_tasks?.[selectedLevel.level] || []).length} / {getLevelTasks(selectedLevel.level).length}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Current Progress (if current level) */}
                {selectedLevel.level === currentLevel && (
                  <div className="bg-gradient-to-r from-yellow-500/10 to-orange-500/10 rounded-lg p-4 border-2 border-yellow-500/30">
                    <h3 className="text-sm font-semibold text-yellow-400 uppercase mb-3">
                      Tu Progreso Actual
                    </h3>
                    <div className="space-y-3">
                      <div className="flex justify-between text-sm">
                        <span className="text-slate-300">XP Acumulado</span>
                        <span className="text-white font-bold">
                          {progress?.level_xp?.toLocaleString() || 0} / {selectedLevel.xpNeeded.toLocaleString()}
                        </span>
                      </div>
                      <Progress 
                        value={Math.min(100, ((progress?.level_xp || 0) / selectedLevel.xpNeeded) * 100)} 
                        className="h-2"
                      />
                      <p className="text-xs text-slate-400 text-center">
                        {Math.round(((progress?.level_xp || 0) / selectedLevel.xpNeeded) * 100)}% completado
                      </p>
                    </div>
                  </div>
                )}

                {/* Status Badge */}
                <div className="flex justify-center">
                  {progress?.completed_levels?.includes(selectedLevel.level) ? (
                    <Badge className="bg-green-600 text-base px-4 py-2">
                      ✓ Nivel Completado
                    </Badge>
                  ) : selectedLevel.level === currentLevel ? (
                    <Badge className="bg-gradient-to-r from-yellow-500 to-orange-500 text-slate-900 text-base px-4 py-2">
                      ⚡ En Progreso
                    </Badge>
                  ) : selectedLevel.level > currentLevel ? (
                    <Badge variant="outline" className="border-slate-600 text-slate-400 text-base px-4 py-2">
                      🔒 Bloqueado
                    </Badge>
                  ) : (
                    <Badge className="bg-blue-600 text-base px-4 py-2">
                      Disponible
                    </Badge>
                  )}
                </div>
              </div>
            </DialogContent>
          </Dialog>
        )}
      </div>
    </div>
  );
}