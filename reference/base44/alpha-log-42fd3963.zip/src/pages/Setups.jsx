import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { BookOpen, Plus, Edit, Trash2, TrendingUp, ChevronLeft } from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

export default function Setups() {
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingSetup, setEditingSetup] = useState(null);
  const [formData, setFormData] = useState({
    name: '',
    short_name: '',
    description: '',
    market_conditions: '',
    entry_model: '',
    invalidations: '',
    timeframes: [],
    tags: [],
    statistics_enabled: false
  });

  const queryClient = useQueryClient();

  const { data: setups = [] } = useQuery({
    queryKey: ['setups'],
    queryFn: () => base44.entities.SetupLibrary.filter({ is_deleted: false })
  });

  const { data: trades = [] } = useQuery({
    queryKey: ['trades'],
    queryFn: () => base44.entities.Trade.filter({ is_deleted: false, status: 'Closed' })
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.SetupLibrary.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries(['setups']);
      setDialogOpen(false);
      resetForm();
    }
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.SetupLibrary.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries(['setups']);
      setDialogOpen(false);
      resetForm();
    }
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.SetupLibrary.update(id, { is_deleted: true, deleted_at: new Date().toISOString() }),
    onSuccess: () => queryClient.invalidateQueries(['setups'])
  });

  const resetForm = () => {
    setFormData({
      name: '',
      short_name: '',
      description: '',
      market_conditions: '',
      entry_model: '',
      invalidations: '',
      timeframes: [],
      tags: [],
      statistics_enabled: false
    });
    setEditingSetup(null);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (editingSetup) {
      updateMutation.mutate({ id: editingSetup.id, data: formData });
    } else {
      createMutation.mutate(formData);
    }
  };

  const handleEdit = (setup) => {
    setEditingSetup(setup);
    setFormData({
      name: setup.name,
      short_name: setup.short_name || '',
      description: setup.description || '',
      market_conditions: setup.market_conditions || '',
      entry_model: setup.entry_model || '',
      invalidations: setup.invalidations || '',
      timeframes: setup.timeframes || [],
      tags: setup.tags || [],
      statistics_enabled: setup.statistics_enabled || false
    });
    setDialogOpen(true);
  };

  const getSetupStats = (setupId) => {
    const setupTrades = trades.filter(t => t.setup_id === setupId);
    if (setupTrades.length === 0) return null;

    const wins = setupTrades.filter(t => t.pnl > 0).length;
    const totalPnL = setupTrades.reduce((sum, t) => sum + t.pnl, 0);
    const winRate = (wins / setupTrades.length) * 100;

    return { trades: setupTrades.length, winRate, totalPnL };
  };

  return (
    <div className="min-h-screen bg-slate-950 p-6">
      <div className="max-w-7xl mx-auto">
        <Link to={createPageUrl('Dashboard')}>
          <Button variant="ghost" size="sm" className="text-slate-400 hover:text-white mb-4">
            <ChevronLeft className="w-4 h-4 mr-1" />
            Atrás
          </Button>
        </Link>
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <BookOpen className="w-8 h-8 text-purple-400" />
            <h1 className="text-3xl font-bold text-white">Setup Library</h1>
          </div>
          <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
            <DialogTrigger asChild>
              <Button onClick={resetForm} className="bg-purple-600 hover:bg-purple-700">
                <Plus className="w-4 h-4 mr-2" />
                New Setup
              </Button>
            </DialogTrigger>
            <DialogContent className="bg-slate-900 border-slate-800 text-white max-w-2xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>{editingSetup ? 'Edit Setup' : 'New Setup'}</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm text-slate-400">Name</label>
                    <Input
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      placeholder="Setup name..."
                      className="bg-slate-800 border-slate-700"
                    />
                  </div>
                  <div>
                    <label className="text-sm text-slate-400">Short Name</label>
                    <Input
                      value={formData.short_name}
                      onChange={(e) => setFormData({ ...formData, short_name: e.target.value })}
                      placeholder="e.g. OB-BOS"
                      className="bg-slate-800 border-slate-700"
                    />
                  </div>
                </div>
                <div>
                  <label className="text-sm text-slate-400">Description</label>
                  <Textarea
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    placeholder="Describe the setup..."
                    className="bg-slate-800 border-slate-700"
                  />
                </div>
                <div>
                  <label className="text-sm text-slate-400">Market Conditions</label>
                  <Textarea
                    value={formData.market_conditions}
                    onChange={(e) => setFormData({ ...formData, market_conditions: e.target.value })}
                    placeholder="When to use this setup..."
                    className="bg-slate-800 border-slate-700"
                  />
                </div>
                <div>
                  <label className="text-sm text-slate-400">Entry Model</label>
                  <Textarea
                    value={formData.entry_model}
                    onChange={(e) => setFormData({ ...formData, entry_model: e.target.value })}
                    placeholder="Entry criteria..."
                    className="bg-slate-800 border-slate-700"
                  />
                </div>
                <div>
                  <label className="text-sm text-slate-400">Invalidations</label>
                  <Textarea
                    value={formData.invalidations}
                    onChange={(e) => setFormData({ ...formData, invalidations: e.target.value })}
                    placeholder="What invalidates this setup..."
                    className="bg-slate-800 border-slate-700"
                  />
                </div>
                <div>
                  <label className="text-sm text-slate-400">Timeframes (comma separated)</label>
                  <Input
                    value={formData.timeframes.join(', ')}
                    onChange={(e) => setFormData({ ...formData, timeframes: e.target.value.split(',').map(t => t.trim()) })}
                    placeholder="e.g. M15, H1, H4"
                    className="bg-slate-800 border-slate-700"
                  />
                </div>
                <div>
                  <label className="text-sm text-slate-400">Tags (comma separated)</label>
                  <Input
                    value={formData.tags.join(', ')}
                    onChange={(e) => setFormData({ ...formData, tags: e.target.value.split(',').map(t => t.trim()) })}
                    placeholder="e.g. ICT, Smart Money, Liquidity"
                    className="bg-slate-800 border-slate-700"
                  />
                </div>
                <div className="flex items-center gap-2">
                  <Switch
                    checked={formData.statistics_enabled}
                    onCheckedChange={(checked) => setFormData({ ...formData, statistics_enabled: checked })}
                  />
                  <label className="text-sm text-slate-400">Enable statistics tracking</label>
                </div>
                <div className="flex justify-end gap-2">
                  <Button type="button" variant="ghost" onClick={() => setDialogOpen(false)}>Cancel</Button>
                  <Button type="submit" className="bg-purple-600 hover:bg-purple-700">
                    {editingSetup ? 'Update' : 'Create'}
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {setups.map((setup) => {
            const stats = getSetupStats(setup.id);
            return (
              <Card key={setup.id} className="bg-slate-900 border-slate-800">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <CardTitle className="text-white">{setup.name}</CardTitle>
                        {setup.short_name && (
                          <Badge variant="outline" className="text-purple-400 border-purple-400">
                            {setup.short_name}
                          </Badge>
                        )}
                      </div>
                      {setup.description && (
                        <p className="text-sm text-slate-400">{setup.description}</p>
                      )}
                      {setup.timeframes && setup.timeframes.length > 0 && (
                        <div className="flex gap-2 mt-2">
                          {setup.timeframes.map((tf, idx) => (
                            <Badge key={idx} className="bg-slate-800 text-slate-300">
                              {tf}
                            </Badge>
                          ))}
                        </div>
                      )}
                    </div>
                    <div className="flex gap-1">
                      <Button size="icon" variant="ghost" onClick={() => handleEdit(setup)} className="text-slate-400 hover:text-white h-8 w-8">
                        <Edit className="w-3 h-3" />
                      </Button>
                      <Button size="icon" variant="ghost" onClick={() => deleteMutation.mutate(setup.id)} className="text-slate-400 hover:text-red-400 h-8 w-8">
                        <Trash2 className="w-3 h-3" />
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  {setup.market_conditions && (
                    <div>
                      <p className="text-xs text-slate-400 mb-1">Market Conditions</p>
                      <p className="text-sm text-slate-300">{setup.market_conditions}</p>
                    </div>
                  )}
                  {setup.entry_model && (
                    <div>
                      <p className="text-xs text-slate-400 mb-1">Entry Model</p>
                      <p className="text-sm text-slate-300">{setup.entry_model}</p>
                    </div>
                  )}
                  {setup.invalidations && (
                    <div>
                      <p className="text-xs text-slate-400 mb-1">Invalidations</p>
                      <p className="text-sm text-slate-300">{setup.invalidations}</p>
                    </div>
                  )}

                  {setup.statistics_enabled && stats && (
                    <div className="pt-4 border-t border-slate-800">
                      <div className="flex items-center gap-2 mb-2">
                        <TrendingUp className="w-4 h-4 text-green-400" />
                        <p className="text-xs text-slate-400">Performance</p>
                      </div>
                      <div className="grid grid-cols-3 gap-4">
                        <div>
                          <p className="text-xs text-slate-400">Trades</p>
                          <p className="text-lg font-bold text-white">{stats.trades}</p>
                        </div>
                        <div>
                          <p className="text-xs text-slate-400">Win Rate</p>
                          <p className="text-lg font-bold text-white">{stats.winRate.toFixed(1)}%</p>
                        </div>
                        <div>
                          <p className="text-xs text-slate-400">P&L</p>
                          <p className={`text-lg font-bold ${stats.totalPnL >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                            ${stats.totalPnL.toLocaleString()}
                          </p>
                        </div>
                      </div>
                    </div>
                  )}

                  {setup.tags && setup.tags.length > 0 && (
                    <div className="flex gap-2 flex-wrap pt-2">
                      {setup.tags.map((tag, idx) => (
                        <Badge key={idx} variant="outline" className="text-xs">
                          {tag}
                        </Badge>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            );
          })}

          {setups.length === 0 && (
            <Card className="bg-slate-900 border-slate-800 col-span-full">
              <CardContent className="py-12">
                <p className="text-center text-slate-400">No setups yet. Create your first one!</p>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}