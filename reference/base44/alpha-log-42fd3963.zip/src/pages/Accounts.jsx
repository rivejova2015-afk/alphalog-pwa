import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Wallet, Plus, Edit, Trash2, TrendingUp, TrendingDown, ChevronLeft } from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

export default function Accounts() {
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingAccount, setEditingAccount] = useState(null);
  const [formData, setFormData] = useState({
    category_id: '',
    name: '',
    account_size: 0,
    current_balance: 0,
    phase_status: '1 fase',
    role: 'SATELLITE',
    operation_state: 'ACTIVE'
  });

  const queryClient = useQueryClient();

  const { data: accounts = [], isLoading: accountsLoading, error: accountsError } = useQuery({
    queryKey: ['accounts'],
    queryFn: async () => {
      const accs = await base44.entities.Account.filter({ is_deleted: false });
      return accs.sort((a, b) => (a.index || 0) - (b.index || 0));
    }
  });

  const { data: categories = [], isLoading: categoriesLoading, error: categoriesError } = useQuery({
    queryKey: ['account-categories'],
    queryFn: () => base44.entities.AccountCategory.list()
  });

  if (accountsLoading || categoriesLoading) {
    return (
      <div className="min-h-screen bg-slate-950 flex items-center justify-center">
        <div className="text-white">Loading...</div>
      </div>
    );
  }

  if (accountsError || categoriesError) {
    return (
      <div className="min-h-screen bg-slate-950 flex items-center justify-center">
        <div className="text-red-400">Error loading data: {accountsError?.message || categoriesError?.message}</div>
      </div>
    );
  }

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.Account.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries(['accounts']);
      setDialogOpen(false);
      resetForm();
    }
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Account.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries(['accounts']);
      setDialogOpen(false);
      resetForm();
    }
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.Account.update(id, { is_deleted: true, deleted_at: new Date().toISOString() }),
    onSuccess: () => queryClient.invalidateQueries(['accounts'])
  });

  const resetForm = () => {
    setFormData({
      category_id: '',
      name: '',
      account_size: 0,
      current_balance: 0,
      phase_status: '1 fase',
      role: 'SATELLITE',
      operation_state: 'ACTIVE'
    });
    setEditingAccount(null);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (editingAccount) {
      updateMutation.mutate({ id: editingAccount.id, data: formData });
    } else {
      createMutation.mutate(formData);
    }
  };

  const handleEdit = (account) => {
    setEditingAccount(account);
    setFormData({
      category_id: account.category_id,
      name: account.name,
      account_size: account.account_size,
      current_balance: account.current_balance,
      phase_status: account.phase_status || '1 fase',
      role: account.role,
      operation_state: account.operation_state
    });
    setDialogOpen(true);
  };

  const getCategoryName = (catId) => {
    const cat = categories.find(c => c.id === catId);
    return cat?.name || 'Unknown';
  };

  const roleColors = {
    CORE: 'bg-blue-600',
    SATELLITE: 'bg-purple-600'
  };

  const stateColors = {
    ACTIVE: 'bg-green-600',
    RESERVE: 'bg-yellow-600',
    PIPELINE: 'bg-orange-600'
  };

  return (
    <div className="min-h-screen bg-slate-950 p-6">
      <div className="max-w-7xl mx-auto">
        <Link to={createPageUrl('Dashboard')}>
          <Button variant="ghost" size="sm" className="text-slate-400 hover:text-white mb-4">
            <ChevronLeft className="w-4 h-4 mr-1" />
            Atrás
          </Button>
        </Link>
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <Wallet className="w-8 h-8 text-green-400" />
            <h1 className="text-3xl font-bold text-white">Trading Accounts</h1>
          </div>
          <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
            <DialogTrigger asChild>
              <Button onClick={resetForm} className="bg-green-600 hover:bg-green-700">
                <Plus className="w-4 h-4 mr-2" />
                New Account
              </Button>
            </DialogTrigger>
            <DialogContent className="bg-slate-900 border-slate-800 text-white">
              <DialogHeader>
                <DialogTitle>{editingAccount ? 'Edit Account' : 'New Account'}</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="text-sm text-slate-400">Category</label>
                  <Select value={formData.category_id} onValueChange={(value) => setFormData({ ...formData, category_id: value })}>
                    <SelectTrigger className="bg-slate-800 border-slate-700">
                      <SelectValue placeholder="Select category" />
                    </SelectTrigger>
                    <SelectContent>
                      {categories.map(cat => (
                        <SelectItem key={cat.id} value={cat.id}>{cat.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <label className="text-sm text-slate-400">Name</label>
                  <Input
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="Account name..."
                    className="bg-slate-800 border-slate-700"
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm text-slate-400">Account Size</label>
                    <Input
                      type="number"
                      value={formData.account_size}
                      onChange={(e) => setFormData({ ...formData, account_size: parseFloat(e.target.value) })}
                      className="bg-slate-800 border-slate-700"
                    />
                  </div>
                  <div>
                    <label className="text-sm text-slate-400">Current Balance</label>
                    <Input
                      type="number"
                      value={formData.current_balance}
                      onChange={(e) => setFormData({ ...formData, current_balance: parseFloat(e.target.value) })}
                      className="bg-slate-800 border-slate-700"
                    />
                  </div>
                </div>
                <div>
                  <label className="text-sm text-slate-400">Phase Status</label>
                  <Select value={formData.phase_status} onValueChange={(value) => setFormData({ ...formData, phase_status: value })}>
                    <SelectTrigger className="bg-slate-800 border-slate-700">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="1 fase">1 fase</SelectItem>
                      <SelectItem value="2 fase">2 fase</SelectItem>
                      <SelectItem value="Instant">Instant</SelectItem>
                      <SelectItem value="Funded">Funded</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm text-slate-400">Role</label>
                    <Select value={formData.role} onValueChange={(value) => setFormData({ ...formData, role: value })}>
                      <SelectTrigger className="bg-slate-800 border-slate-700">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="CORE">CORE</SelectItem>
                        <SelectItem value="SATELLITE">SATELLITE</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <label className="text-sm text-slate-400">State</label>
                    <Select value={formData.operation_state} onValueChange={(value) => setFormData({ ...formData, operation_state: value })}>
                      <SelectTrigger className="bg-slate-800 border-slate-700">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="ACTIVE">ACTIVE</SelectItem>
                        <SelectItem value="RESERVE">RESERVE</SelectItem>
                        <SelectItem value="PIPELINE">PIPELINE</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="flex justify-end gap-2">
                  <Button type="button" variant="ghost" onClick={() => setDialogOpen(false)}>Cancel</Button>
                  <Button type="submit" className="bg-green-600 hover:bg-green-700">
                    {editingAccount ? 'Update' : 'Create'}
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        {categories.length > 0 ? (
          categories.map((category) => {
            const categoryAccounts = accounts.filter(acc => acc.category_id === category.id);
            if (categoryAccounts.length === 0) return null;

            return (
              <div key={category.id} className="mb-8">
                <h3 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
                  {category.name}
                  <Badge variant="outline" className="text-slate-400">
                    {categoryAccounts.length}
                  </Badge>
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {categoryAccounts.map((account) => {
                    const pnl = account.current_balance - account.account_size;
                    const pnlPct = account.account_size > 0 ? (pnl / account.account_size) * 100 : 0;
                    const isProfitable = pnl >= 0;

                    return (
                      <Card key={account.id} className="bg-slate-900 border-slate-800">
                        <CardHeader>
                          <div className="flex items-start justify-between">
                            <div className="flex-1">
                              <CardTitle className="text-white text-lg">{account.name}</CardTitle>
                            </div>
                            <div className="flex gap-1">
                              <Button size="icon" variant="ghost" onClick={() => handleEdit(account)} className="text-slate-400 hover:text-white h-8 w-8">
                                <Edit className="w-3 h-3" />
                              </Button>
                              <Button size="icon" variant="ghost" onClick={() => deleteMutation.mutate(account.id)} className="text-slate-400 hover:text-red-400 h-8 w-8">
                                <Trash2 className="w-3 h-3" />
                              </Button>
                            </div>
                          </div>
                          <div className="flex gap-2 mt-2">
                            <Badge className={roleColors[account.role]}>{account.role}</Badge>
                            <Badge className={stateColors[account.operation_state]}>{account.operation_state}</Badge>
                            {account.phase_status && <Badge variant="outline">{account.phase_status}</Badge>}
                          </div>
                        </CardHeader>
                        <CardContent>
                          <div className="space-y-3">
                            <div>
                              <p className="text-xs text-slate-400">Balance</p>
                              <p className="text-2xl font-bold text-white">${account.current_balance.toLocaleString()}</p>
                            </div>
                            <div className="flex items-center gap-2">
                              {isProfitable ? <TrendingUp className="w-4 h-4 text-green-400" /> : <TrendingDown className="w-4 h-4 text-red-400" />}
                              <span className={`text-sm font-medium ${isProfitable ? 'text-green-400' : 'text-red-400'}`}>
                                {isProfitable ? '+' : ''}{pnl.toLocaleString()} ({pnlPct.toFixed(2)}%)
                              </span>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>
              </div>
            );
          })
        ) : (
          <Card className="bg-slate-900 border-slate-800">
            <CardContent className="py-12">
              <p className="text-center text-slate-400">No accounts yet. Create your first one!</p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}