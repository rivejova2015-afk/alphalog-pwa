import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Calendar as CalendarIcon, TrendingUp, AlertCircle, ChevronLeft } from 'lucide-react';
import { format, startOfWeek, addDays, isSameDay, isToday } from 'date-fns';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

export default function Calendar() {
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [currentWeek, setCurrentWeek] = useState(startOfWeek(new Date(), { weekStartsOn: 1 }));

  const { data: events = [] } = useQuery({
    queryKey: ['terminal-events'],
    queryFn: () => base44.entities.TerminalEvent.list('-timestamp_utc')
  });

  const weekDays = Array.from({ length: 7 }, (_, i) => addDays(currentWeek, i));

  const getEventsForDate = (date) => {
    return events.filter(event => {
      const eventDate = new Date(event.timestamp_utc);
      return isSameDay(eventDate, date);
    });
  };

  const todayEvents = getEventsForDate(new Date());
  const upcomingEvents = events.filter(event => {
    const eventDate = new Date(event.timestamp_utc);
    return eventDate > new Date();
  }).slice(0, 10);

  const impactColors = {
    HIGH: 'bg-red-600',
    MED: 'bg-yellow-600',
    LOW: 'bg-blue-600'
  };

  const nextWeek = () => setCurrentWeek(addDays(currentWeek, 7));
  const prevWeek = () => setCurrentWeek(addDays(currentWeek, -7));

  return (
    <div className="min-h-screen bg-slate-950 p-6">
      <div className="max-w-7xl mx-auto">
        <Link to={createPageUrl('Dashboard')}>
          <Button variant="ghost" size="sm" className="text-slate-400 hover:text-white mb-4">
            <ChevronLeft className="w-4 h-4 mr-1" />
            Atrás
          </Button>
        </Link>
        <div className="flex items-center gap-3 mb-6">
          <CalendarIcon className="w-8 h-8 text-amber-400" />
          <h1 className="text-3xl font-bold text-white">Economic Calendar</h1>
        </div>

        <Tabs defaultValue="week" className="space-y-6">
          <TabsList className="bg-slate-900 border-slate-800">
            <TabsTrigger value="week">Week View</TabsTrigger>
            <TabsTrigger value="today">Today</TabsTrigger>
            <TabsTrigger value="upcoming">Upcoming</TabsTrigger>
          </TabsList>

          <TabsContent value="week" className="space-y-4">
            <Card className="bg-slate-900 border-slate-800">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-white">
                    {format(currentWeek, 'MMMM dd')} - {format(addDays(currentWeek, 6), 'MMMM dd, yyyy')}
                  </CardTitle>
                  <div className="flex gap-2">
                    <button
                      onClick={prevWeek}
                      className="px-3 py-1 bg-slate-800 hover:bg-slate-700 text-white rounded"
                    >
                      Previous
                    </button>
                    <button
                      onClick={nextWeek}
                      className="px-3 py-1 bg-slate-800 hover:bg-slate-700 text-white rounded"
                    >
                      Next
                    </button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-7 gap-2">
                  {weekDays.map((day, idx) => {
                    const dayEvents = getEventsForDate(day);
                    const isCurrentDay = isToday(day);
                    return (
                      <div
                        key={idx}
                        className={`p-3 rounded-lg border ${
                          isCurrentDay
                            ? 'border-amber-500 bg-amber-950'
                            : 'border-slate-800 bg-slate-800'
                        }`}
                      >
                        <p className={`text-sm font-medium mb-2 ${isCurrentDay ? 'text-amber-400' : 'text-white'}`}>
                          {format(day, 'EEE dd')}
                        </p>
                        <div className="space-y-1">
                          {dayEvents.slice(0, 3).map((event, eventIdx) => (
                            <div
                              key={eventIdx}
                              className="text-xs p-1 rounded bg-slate-700 text-slate-300 truncate"
                              title={event.name}
                            >
                              <Badge className={`${impactColors[event.impact]} mr-1 text-xs px-1 py-0`}>
                                {event.impact}
                              </Badge>
                              {event.name}
                            </div>
                          ))}
                          {dayEvents.length > 3 && (
                            <p className="text-xs text-slate-500">+{dayEvents.length - 3} more</p>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="today" className="space-y-4">
            <Card className="bg-slate-900 border-slate-800">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <TrendingUp className="w-5 h-5 text-amber-400" />
                  Today's Events - {format(new Date(), 'MMMM dd, yyyy')}
                </CardTitle>
              </CardHeader>
              <CardContent>
                {todayEvents.length === 0 ? (
                  <p className="text-slate-400 text-center py-8">No events scheduled for today</p>
                ) : (
                  <div className="space-y-3">
                    {todayEvents.map((event) => (
                      <div key={event.id} className="p-4 bg-slate-800 rounded-lg">
                        <div className="flex items-start justify-between mb-2">
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-1">
                              <Badge className={impactColors[event.impact]}>{event.impact}</Badge>
                              <span className="text-xs text-slate-400">
                                {event.country} - {event.currency}
                              </span>
                            </div>
                            <h3 className="text-white font-medium">{event.name}</h3>
                          </div>
                          <span className="text-sm text-slate-400">
                            {format(new Date(event.timestamp_utc), 'HH:mm')}
                          </span>
                        </div>
                        {(event.previous || event.forecast || event.actual) && (
                          <div className="grid grid-cols-3 gap-4 mt-3 pt-3 border-t border-slate-700">
                            <div>
                              <p className="text-xs text-slate-400">Previous</p>
                              <p className="text-sm text-white">{event.previous || '-'}</p>
                            </div>
                            <div>
                              <p className="text-xs text-slate-400">Forecast</p>
                              <p className="text-sm text-white">{event.forecast || '-'}</p>
                            </div>
                            <div>
                              <p className="text-xs text-slate-400">Actual</p>
                              <p className="text-sm text-white">{event.actual || '-'}</p>
                            </div>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="upcoming" className="space-y-4">
            <Card className="bg-slate-900 border-slate-800">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <AlertCircle className="w-5 h-5 text-blue-400" />
                  Upcoming High-Impact Events
                </CardTitle>
              </CardHeader>
              <CardContent>
                {upcomingEvents.length === 0 ? (
                  <p className="text-slate-400 text-center py-8">No upcoming events</p>
                ) : (
                  <div className="space-y-3">
                    {upcomingEvents.map((event) => (
                      <div key={event.id} className="p-4 bg-slate-800 rounded-lg hover:bg-slate-750 transition-colors">
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-1">
                              <Badge className={impactColors[event.impact]}>{event.impact}</Badge>
                              <span className="text-xs text-slate-400">
                                {event.country} - {event.currency}
                              </span>
                            </div>
                            <h3 className="text-white font-medium">{event.name}</h3>
                            <p className="text-sm text-slate-400 mt-1">
                              {format(new Date(event.timestamp_utc), 'MMM dd, yyyy HH:mm')}
                            </p>
                          </div>
                          {event.surprise_score && (
                            <div className="text-right">
                              <p className="text-xs text-slate-400">Surprise</p>
                              <p className="text-lg font-bold text-amber-400">
                                {event.surprise_score.toFixed(1)}
                              </p>
                            </div>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}