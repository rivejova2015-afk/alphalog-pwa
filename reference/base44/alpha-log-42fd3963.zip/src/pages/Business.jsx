import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Progress } from '@/components/ui/progress';
import { 
  ChevronLeft, 
  Briefcase, 
  Activity, 
  DollarSign, 
  Target, 
  TrendingUp,
  TrendingDown,
  Clock,
  Plus,
  Edit,
  Trash2,
  BookOpen,
  Flag,
  FileText,
  Building2,
  Calendar,
  Shield,
  Mail,
  AlertCircle
} from 'lucide-react';

export default function Business() {
  const [selectedMonth, setSelectedMonth] = useState(new Date().toISOString().slice(0, 7));
  const [selectedFilter, setSelectedFilter] = useState('ALL');
  const [costDialogOpen, setCostDialogOpen] = useState(false);
  const [sopDialogOpen, setSopDialogOpen] = useState(false);
  const [milestoneDialogOpen, setMilestoneDialogOpen] = useState(false);
  const [decisionDialogOpen, setDecisionDialogOpen] = useState(false);
  const [editingLLC, setEditingLLC] = useState(false);
  const [refreshing, setRefreshing] = useState(false);

  const [costFormData, setCostFormData] = useState({
    amount: 0,
    category: 'Tools Software',
    description: '',
    date: new Date().toISOString().split('T')[0],
    recurring: false
  });

  const [sopFormData, setSopFormData] = useState({
    title: '',
    type: 'custom',
    content: '',
    checklist_items: []
  });

  const [milestoneFormData, setMilestoneFormData] = useState({
    title: '',
    description: '',
    target_date: '',
    status: 'pending'
  });

  const [decisionFormData, setDecisionFormData] = useState({
    title: '',
    context: '',
    decision: '',
    rationale: '',
    impact: ''
  });

  const [llcFormData, setLlcFormData] = useState({
    llc_name: 'Wyoming LLC',
    formation_date: '',
    annual_report_due_month: 1,
    annual_fee_baseline: 60,
    registered_agent_name: '',
    ein: '',
    notes: ''
  });

  const queryClient = useQueryClient();

  const { data: accounts = [] } = useQuery({
    queryKey: ['business-accounts'],
    queryFn: () => base44.entities.Account.filter({ is_deleted: false })
  });

  const { data: trades = [] } = useQuery({
    queryKey: ['business-trades'],
    queryFn: () => base44.entities.Trade.filter({ is_deleted: false, status: 'Closed' })
  });

  const { data: costs = [] } = useQuery({
    queryKey: ['business-costs'],
    queryFn: () => base44.entities.BusinessCost.filter({ is_deleted: false })
  });

  const { data: sops = [] } = useQuery({
    queryKey: ['sops'],
    queryFn: () => base44.entities.SOP.list()
  });

  const { data: milestones = [] } = useQuery({
    queryKey: ['business-milestones'],
    queryFn: () => base44.entities.BusinessMilestone.filter({ is_deleted: false })
  });

  const { data: decisions = [] } = useQuery({
    queryKey: ['decisions'],
    queryFn: () => base44.entities.DecisionLog.list()
  });

  const { data: llcInfoList = [] } = useQuery({
    queryKey: ['llc-info'],
    queryFn: () => base44.entities.LLCInfo.list()
  });

  const llcInfo = llcInfoList[0] || {};

  const handleRefresh = async () => {
    setRefreshing(true);
    await Promise.all([
      queryClient.invalidateQueries(['business-accounts']),
      queryClient.invalidateQueries(['business-trades']),
      queryClient.invalidateQueries(['business-costs']),
      queryClient.invalidateQueries(['sops']),
      queryClient.invalidateQueries(['business-milestones']),
      queryClient.invalidateQueries(['decisions']),
      queryClient.invalidateQueries(['llc-info'])
    ]);
    setRefreshing(false);
  };

  const createCostMutation = useMutation({
    mutationFn: (data) => base44.entities.BusinessCost.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries(['business-costs']);
      setCostDialogOpen(false);
      setCostFormData({ amount: 0, category: 'Tools Software', description: '', date: new Date().toISOString().split('T')[0], recurring: false });
    }
  });

  const deleteCostMutation = useMutation({
    mutationFn: (id) => base44.entities.BusinessCost.update(id, { is_deleted: true }),
    onSuccess: () => queryClient.invalidateQueries(['business-costs'])
  });

  const createSopMutation = useMutation({
    mutationFn: (data) => base44.entities.SOP.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries(['sops']);
      setSopDialogOpen(false);
      setSopFormData({ title: '', type: 'custom', content: '', checklist_items: [] });
    }
  });

  const createMilestoneMutation = useMutation({
    mutationFn: (data) => base44.entities.BusinessMilestone.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries(['business-milestones']);
      setMilestoneDialogOpen(false);
      setMilestoneFormData({ title: '', description: '', target_date: '', status: 'pending' });
    }
  });

  const updateMilestoneStatusMutation = useMutation({
    mutationFn: ({ id, status }) => base44.entities.BusinessMilestone.update(id, { status }),
    onSuccess: () => queryClient.invalidateQueries(['business-milestones'])
  });

  const createDecisionMutation = useMutation({
    mutationFn: (data) => base44.entities.DecisionLog.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries(['decisions']);
      setDecisionDialogOpen(false);
      setDecisionFormData({ title: '', context: '', decision: '', rationale: '', impact: '' });
    }
  });

  const updateLLCMutation = useMutation({
    mutationFn: (data) => {
      if (llcInfo.id) {
        return base44.entities.LLCInfo.update(llcInfo.id, data);
      } else {
        return base44.entities.LLCInfo.create(data);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['llc-info']);
      setEditingLLC(false);
    }
  });

  // Calculations
  const getTradesInMonth = (month) => {
    return trades.filter(t => t.exit_date.slice(0, 7) === month);
  };

  const getCostsInMonth = (month) => {
    return costs.filter(c => c.date.slice(0, 7) === month);
  };

  const calculateNetIncome = (month) => {
    const monthTrades = getTradesInMonth(month);
    const monthCosts = getCostsInMonth(month);
    const income = monthTrades.reduce((sum, t) => sum + (t.pnl || 0), 0);
    const expenses = monthCosts.reduce((sum, c) => sum + c.amount, 0);
    return income - expenses;
  };

  const calculateMargin = (month) => {
    const monthTrades = getTradesInMonth(month);
    const income = monthTrades.reduce((sum, t) => sum + (t.pnl || 0), 0);
    return income > 0 ? 100 : 0;
  };

  const calculateConsistency = (month) => {
    const monthTrades = getTradesInMonth(month);
    const winningTrades = monthTrades.filter(t => t.pnl > 0).length;
    return monthTrades.length > 0 ? (winningTrades / monthTrades.length) * 100 : 0;
  };

  const getIncomeByAccount = (month) => {
    const monthTrades = getTradesInMonth(month);
    return accounts.map(acc => {
      const accountTrades = monthTrades.filter(t => t.account_id === acc.id);
      const income = accountTrades.reduce((sum, t) => sum + (t.pnl || 0), 0);
      return { name: acc.name, income };
    });
  };

  const getCostsByCategory = (month) => {
    const monthCosts = getCostsInMonth(month);
    const categories = ['Tools Software', 'Data', 'Commissions Fees', 'Infrastructure', 'Education', 'Other'];
    return categories.map(cat => {
      const catCosts = monthCosts.filter(c => c.category === cat);
      const total = catCosts.reduce((sum, c) => sum + c.amount, 0);
      return { category: cat, total };
    });
  };

  const calculateRunway = () => {
    const now = new Date();
    const last3Months = [];
    for (let i = 0; i < 3; i++) {
      const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
      last3Months.push(d.toISOString().slice(0, 7));
    }

    const avgCosts = last3Months.reduce((sum, month) => {
      const monthCosts = getCostsInMonth(month);
      return sum + monthCosts.reduce((s, c) => s + c.amount, 0);
    }, 0) / 3;

    const avgProfit = last3Months.reduce((sum, month) => {
      return sum + calculateNetIncome(month);
    }, 0) / 3;

    const runway = avgCosts > 0 ? avgProfit / avgCosts : 0;
    return { burnRate: avgCosts, netProfit: avgProfit, runway: Math.floor(runway) };
  };

  const calculateKPIs = () => {
    const monthTrades = getTradesInMonth(selectedMonth);
    const monthCosts = getCostsInMonth(selectedMonth);
    const netProfit = calculateNetIncome(selectedMonth);
    const totalCosts = monthCosts.reduce((sum, c) => sum + c.amount, 0);
    const costPerTrade = monthTrades.length > 0 ? totalCosts / monthTrades.length : 0;

    // Get unique trading days
    const uniqueDays = new Set(monthTrades.map(t => t.exit_date.slice(0, 10))).size;
    const daysInMonth = new Date(selectedMonth.slice(0, 4), selectedMonth.slice(5, 7), 0).getDate();
    const consistency = (uniqueDays / daysInMonth) * 100;

    // Profit per hour (estimate 12 hours per trading day)
    const profitPerHour = uniqueDays > 0 ? netProfit / (uniqueDays * 12) : 0;

    return {
      netProfit,
      profitPerHour,
      costPerTrade,
      consistency
    };
  };

  const monthTrades = getTradesInMonth(selectedMonth);
  const monthCosts = getCostsInMonth(selectedMonth);
  const netIncome = calculateNetIncome(selectedMonth);
  const margin = calculateMargin(selectedMonth);
  const consistency = calculateConsistency(selectedMonth);
  const incomeByAccount = getIncomeByAccount(selectedMonth);
  const costsByCategory = getCostsByCategory(selectedMonth);
  const { burnRate, netProfit: avgNetProfit, runway } = calculateRunway();
  const kpis = calculateKPIs();

  const totalIncome = monthTrades.reduce((sum, t) => sum + (t.pnl || 0), 0);
  const totalCosts = monthCosts.reduce((sum, c) => sum + c.amount, 0);

  const filteredAccounts = selectedFilter === 'ALL' ? incomeByAccount : incomeByAccount.filter(a => a.income > 0);

  const pendingMilestones = milestones.filter(m => m.status === 'pending');
  const inProgressMilestones = milestones.filter(m => m.status === 'in_progress');
  const completedMilestones = milestones.filter(m => m.status === 'completed');

  return (
    <div className="min-h-screen bg-slate-950 p-6">
      <div className="max-w-7xl mx-auto">
        <Link to={createPageUrl('Dashboard')}>
          <Button variant="ghost" size="sm" className="text-slate-400 hover:text-white mb-4">
            <ChevronLeft className="w-4 h-4 mr-1" />
            Atrás
          </Button>
        </Link>

        <div className="mb-6">
          <div className="flex items-center gap-3 mb-2">
            <Briefcase className="w-8 h-8 text-indigo-400" />
            <h1 className="text-3xl font-bold text-white">Business</h1>
          </div>
          <p className="text-slate-400">Gestión empresarial del trading: finanzas, KPIs, SOPs y decisiones estratégicas</p>
        </div>

        <Tabs defaultValue="health" className="space-y-6">
          <TabsList className="bg-slate-900 border-slate-800">
            <TabsTrigger value="health">Health</TabsTrigger>
            <TabsTrigger value="pl">P&L</TabsTrigger>
            <TabsTrigger value="runway">Runway</TabsTrigger>
            <TabsTrigger value="kpis">KPIs</TabsTrigger>
            <TabsTrigger value="sops">SOPs</TabsTrigger>
            <TabsTrigger value="roadmap">Roadmap</TabsTrigger>
            <TabsTrigger value="decisions">Decisions</TabsTrigger>
            <TabsTrigger value="llc">LLC</TabsTrigger>
          </TabsList>

          {/* HEALTH TAB */}
          <TabsContent value="health" className="space-y-6">
            <Card className="bg-slate-900 border-slate-800">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Activity className="w-5 h-5 text-green-400" />
                    <CardTitle className="text-white">Panel de Salud del Negocio</CardTitle>
                  </div>
                  <div className="flex items-center gap-3">
                    <Button
                      onClick={handleRefresh}
                      disabled={refreshing}
                      variant="outline"
                      size="sm"
                      className="border-slate-700 text-slate-300"
                    >
                      <Activity className={`w-4 h-4 mr-2 ${refreshing ? 'animate-spin' : ''}`} />
                      Actualizar
                    </Button>
                    <Select value={selectedFilter} onValueChange={setSelectedFilter}>
                      <SelectTrigger className="bg-slate-800 border-slate-700 text-white w-32">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="ALL">Todo</SelectItem>
                        <SelectItem value="POSITIVE">Solo positivos</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <p className="text-sm text-slate-400 mt-1">Vista general de la salud financiera del trading</p>
              </CardHeader>
            </Card>

            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <Card className="bg-slate-900 border-slate-800">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm text-slate-400 flex items-center gap-2">
                    <DollarSign className="w-4 h-4" />
                    Ingreso Neto
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className={`text-2xl font-bold ${netIncome >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                    ${netIncome.toLocaleString()}
                  </p>
                  <p className="text-xs text-slate-400 mt-1">Ingresos - Costos</p>
                </CardContent>
              </Card>

              <Card className="bg-slate-900 border-slate-800">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm text-slate-400 flex items-center gap-2">
                    <Target className="w-4 h-4" />
                    Margen
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-2xl font-bold text-indigo-400">{margin.toFixed(1)}%</p>
                  <p className="text-xs text-slate-400 mt-1">Ingreso / Total</p>
                </CardContent>
              </Card>

              <Card className="bg-slate-900 border-slate-800">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm text-slate-400 flex items-center gap-2">
                    <TrendingUp className="w-4 h-4" />
                    Consistencia
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-2xl font-bold text-green-400">{consistency.toFixed(1)}%</p>
                  <p className="text-xs text-slate-400 mt-1">Win Rate</p>
                </CardContent>
              </Card>

              <Card className="bg-slate-900 border-slate-800">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm text-slate-400 flex items-center gap-2">
                    <Activity className="w-4 h-4" />
                    Trades Totales
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-2xl font-bold text-white">{monthTrades.length}</p>
                  <p className="text-xs text-slate-400 mt-1">{monthTrades.filter(t => t.pnl > 0).length} ganadores</p>
                </CardContent>
              </Card>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="bg-slate-900 border-slate-800">
                <CardHeader>
                  <CardTitle className="text-white">Ingresos por Cuenta</CardTitle>
                </CardHeader>
                <CardContent>
                  {filteredAccounts.length > 0 ? (
                    <div className="space-y-3">
                      {filteredAccounts.map(acc => (
                        <div key={acc.name} className="flex items-center justify-between">
                          <span className="text-slate-300">{acc.name}</span>
                          <span className={`font-bold ${acc.income >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                            ${acc.income.toLocaleString()}
                          </span>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-center text-slate-400 py-8">No hay ingresos registrados</p>
                  )}
                </CardContent>
              </Card>

              <Card className="bg-slate-900 border-slate-800">
                <CardHeader>
                  <CardTitle className="text-white">Costos por Categoría</CardTitle>
                </CardHeader>
                <CardContent>
                  {costsByCategory.some(c => c.total > 0) ? (
                    <div className="space-y-3">
                      {costsByCategory.map(cat => (
                        <div key={cat.category} className="flex items-center justify-between">
                          <span className="text-slate-300">{cat.category}</span>
                          <span className="text-red-400 font-bold">${cat.total.toLocaleString()}</span>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-center text-slate-400 py-8">No hay costos registrados</p>
                  )}
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* P&L TAB */}
          <TabsContent value="pl" className="space-y-6">
            <Card className="bg-slate-900 border-slate-800">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <div className="flex items-center gap-2 mb-2">
                      <FileText className="w-5 h-5 text-blue-400" />
                      <CardTitle className="text-white">P&L Statement (Estado de Resultados)</CardTitle>
                    </div>
                    <p className="text-sm text-slate-400">Income statement mensual del negocio</p>
                  </div>
                  <div className="flex items-center gap-3">
                    <Button
                      onClick={handleRefresh}
                      disabled={refreshing}
                      variant="outline"
                      size="sm"
                      className="border-slate-700 text-slate-300"
                    >
                      <Activity className={`w-4 h-4 mr-2 ${refreshing ? 'animate-spin' : ''}`} />
                      Actualizar
                    </Button>
                    <Input
                      type="month"
                      value={selectedMonth}
                      onChange={(e) => setSelectedMonth(e.target.value)}
                      className="bg-slate-800 border-slate-700 text-white"
                    />
                    <Dialog open={costDialogOpen} onOpenChange={setCostDialogOpen}>
                      <DialogTrigger asChild>
                        <Button className="bg-indigo-600 hover:bg-indigo-700">
                          <Plus className="w-4 h-4 mr-2" />
                          Agregar Costo
                        </Button>
                      </DialogTrigger>
                      <DialogContent className="bg-slate-900 border-slate-800 text-white">
                        <DialogHeader>
                          <DialogTitle>Nuevo Costo</DialogTitle>
                        </DialogHeader>
                        <div className="space-y-4">
                          <div>
                            <label className="text-sm text-slate-400">Monto</label>
                            <Input
                              type="number"
                              value={costFormData.amount}
                              onChange={(e) => setCostFormData({ ...costFormData, amount: parseFloat(e.target.value) })}
                              className="bg-slate-800 border-slate-700 text-white"
                            />
                          </div>
                          <div>
                            <label className="text-sm text-slate-400">Categoría</label>
                            <Select
                              value={costFormData.category}
                              onValueChange={(value) => setCostFormData({ ...costFormData, category: value })}
                            >
                              <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="Tools Software">Tools Software</SelectItem>
                                <SelectItem value="Data">Data</SelectItem>
                                <SelectItem value="Commissions Fees">Commissions Fees</SelectItem>
                                <SelectItem value="Infrastructure">Infrastructure</SelectItem>
                                <SelectItem value="Education">Education</SelectItem>
                                <SelectItem value="Other">Other</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                          <div>
                            <label className="text-sm text-slate-400">Descripción</label>
                            <Input
                              value={costFormData.description}
                              onChange={(e) => setCostFormData({ ...costFormData, description: e.target.value })}
                              className="bg-slate-800 border-slate-700 text-white"
                            />
                          </div>
                          <div>
                            <label className="text-sm text-slate-400">Fecha</label>
                            <Input
                              type="date"
                              value={costFormData.date}
                              onChange={(e) => setCostFormData({ ...costFormData, date: e.target.value })}
                              className="bg-slate-800 border-slate-700 text-white"
                            />
                          </div>
                          <div className="flex justify-end gap-2">
                            <Button variant="ghost" onClick={() => setCostDialogOpen(false)}>Cancelar</Button>
                            <Button onClick={() => createCostMutation.mutate(costFormData)} className="bg-indigo-600">
                              Crear
                            </Button>
                          </div>
                        </div>
                      </DialogContent>
                    </Dialog>
                  </div>
                </div>
              </CardHeader>
            </Card>

            <Card className="bg-slate-900 border-slate-800">
              <CardHeader>
                <CardTitle className="text-white">Resumen {selectedMonth}</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between items-center py-3 border-b border-slate-800">
                  <span className="text-slate-300 font-medium">Ingresos Trading</span>
                  <span className="text-green-400 font-bold text-lg">${totalIncome.toLocaleString()}</span>
                </div>
                <div className="flex justify-between items-center py-3 border-b border-slate-800">
                  <span className="text-slate-300 font-medium">Costos Operativos</span>
                  <span className="text-red-400 font-bold text-lg">-${totalCosts.toLocaleString()}</span>
                </div>
                <div className="flex justify-between items-center py-4 bg-slate-800/50 rounded-lg px-4">
                  <span className="text-white font-bold text-lg">Ganancia Neta</span>
                  <span className={`font-bold text-2xl ${netIncome >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                    ${netIncome.toLocaleString()}
                  </span>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-slate-900 border-slate-800">
              <CardHeader>
                <CardTitle className="text-white">Desglose de Costos</CardTitle>
              </CardHeader>
              <CardContent>
                {monthCosts.length > 0 ? (
                  <div className="space-y-2">
                    {monthCosts.map(cost => (
                      <div key={cost.id} className="flex items-center justify-between p-3 bg-slate-800/50 rounded-lg">
                        <div className="flex-1">
                          <p className="text-white font-medium">{cost.description || cost.category}</p>
                          <p className="text-xs text-slate-400">{cost.date} • {cost.category}</p>
                        </div>
                        <div className="flex items-center gap-3">
                          <span className="text-red-400 font-bold">${cost.amount.toLocaleString()}</span>
                          <Button
                            size="icon"
                            variant="ghost"
                            onClick={() => deleteCostMutation.mutate(cost.id)}
                            className="text-slate-400 hover:text-red-400 h-8 w-8"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-center text-slate-400 py-8">No hay costos registrados</p>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* RUNWAY TAB */}
          <TabsContent value="runway" className="space-y-6">
            <Card className="bg-slate-900 border-slate-800">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <div className="flex items-center gap-2 mb-2">
                      <Clock className="w-5 h-5 text-amber-400" />
                      <CardTitle className="text-white">Runway & Burn Rate</CardTitle>
                    </div>
                    <p className="text-sm text-slate-400">Capacidad de sostenibilidad del negocio basado en costos mensuales</p>
                  </div>
                  <Button
                    onClick={handleRefresh}
                    disabled={refreshing}
                    variant="outline"
                    size="sm"
                    className="border-slate-700 text-slate-300"
                  >
                    <Activity className={`w-4 h-4 mr-2 ${refreshing ? 'animate-spin' : ''}`} />
                    Actualizar
                  </Button>
                </div>
              </CardHeader>
            </Card>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Card className="bg-slate-900 border-slate-800">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm text-slate-400 flex items-center gap-2">
                    <TrendingDown className="w-4 h-4" />
                    Burn Rate Mensual
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-2xl font-bold text-red-400">${burnRate.toLocaleString()}</p>
                  <p className="text-xs text-slate-400 mt-1">Promedio últimos 3 meses</p>
                </CardContent>
              </Card>

              <Card className="bg-slate-900 border-slate-800">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm text-slate-400 flex items-center gap-2">
                    <TrendingUp className="w-4 h-4" />
                    Net Profit Mensual
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-2xl font-bold text-green-400">${avgNetProfit.toLocaleString()}</p>
                  <p className="text-xs text-slate-400 mt-1">Promedio últimos 3 meses</p>
                </CardContent>
              </Card>

              <Card className="bg-slate-900 border-slate-800">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm text-slate-400 flex items-center gap-2">
                    <Calendar className="w-4 h-4" />
                    Runway
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-2xl font-bold text-indigo-400">{runway} meses</p>
                  <p className="text-xs text-slate-400 mt-1">Sostenibilidad actual</p>
                </CardContent>
              </Card>
            </div>

            <Card className="bg-slate-900 border-slate-800">
              <CardHeader>
                <CardTitle className="text-white">Análisis de Sostenibilidad</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="p-4 bg-blue-500/10 border border-blue-500/30 rounded-lg">
                  <p className="text-sm text-blue-300">
                    <span className="font-medium">Interpretación:</span> Con un net profit mensual de ${avgNetProfit.toFixed(2)} y costos operativos de ${burnRate.toFixed(2)}, el negocio puede sostenerse aproximadamente <span className="font-bold">{runway} meses</span> al ritmo actual.
                  </p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* KPIs TAB */}
          <TabsContent value="kpis" className="space-y-6">
            <Card className="bg-slate-900 border-slate-800">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <div className="flex items-center gap-2 mb-2">
                      <Target className="w-5 h-5 text-purple-400" />
                      <CardTitle className="text-white">KPI Operating System</CardTitle>
                    </div>
                    <p className="text-sm text-slate-400">Key Performance Indicators del negocio</p>
                  </div>
                  <div className="flex items-center gap-3">
                    <Button
                      onClick={handleRefresh}
                      disabled={refreshing}
                      variant="outline"
                      size="sm"
                      className="border-slate-700 text-slate-300"
                    >
                      <Activity className={`w-4 h-4 mr-2 ${refreshing ? 'animate-spin' : ''}`} />
                      Actualizar
                    </Button>
                    <Select value={selectedFilter} onValueChange={setSelectedFilter}>
                      <SelectTrigger className="bg-slate-800 border-slate-700 text-white w-32">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="ALL">Todo</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </CardHeader>
            </Card>

            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <Card className="bg-slate-900 border-slate-800">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm text-slate-400 flex items-center gap-2">
                    <DollarSign className="w-4 h-4" />
                    Net Profit
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className={`text-2xl font-bold ${kpis.netProfit >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                    ${kpis.netProfit.toLocaleString()}
                  </p>
                  <p className="text-xs text-slate-400 mt-1">Ingresos - Costos</p>
                </CardContent>
              </Card>

              <Card className="bg-slate-900 border-slate-800">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm text-slate-400 flex items-center gap-2">
                    <Clock className="w-4 h-4" />
                    Profit/Hour
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-2xl font-bold text-indigo-400">${kpis.profitPerHour.toFixed(2)}</p>
                  <p className="text-xs text-slate-400 mt-1">12h estimadas</p>
                </CardContent>
              </Card>

              <Card className="bg-slate-900 border-slate-800">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm text-slate-400 flex items-center gap-2">
                    <DollarSign className="w-4 h-4" />
                    Cost/Trade
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-2xl font-bold text-amber-400">${kpis.costPerTrade.toFixed(2)}</p>
                  <p className="text-xs text-slate-400 mt-1">{monthTrades.length} trades</p>
                </CardContent>
              </Card>

              <Card className="bg-slate-900 border-slate-800">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm text-slate-400 flex items-center gap-2">
                    <TrendingUp className="w-4 h-4" />
                    Consistencia
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-2xl font-bold text-green-400">{kpis.consistency.toFixed(1)}%</p>
                  <p className="text-xs text-slate-400 mt-1">Días activos</p>
                </CardContent>
              </Card>
            </div>

            <Card className="bg-slate-900 border-slate-800">
              <CardHeader>
                <CardTitle className="text-white">KPIs por Cuenta</CardTitle>
              </CardHeader>
              <CardContent>
                {incomeByAccount.length > 0 ? (
                  <div className="space-y-3">
                    {incomeByAccount.map(acc => {
                      const accountTrades = monthTrades.filter(t => t.account_id === accounts.find(a => a.name === acc.name)?.id);
                      return (
                        <div key={acc.name} className="p-3 bg-slate-800/50 rounded-lg">
                          <div className="flex items-center justify-between mb-2">
                            <span className="text-white font-medium">{acc.name}</span>
                            <span className={`font-bold ${acc.income >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                              ${acc.income.toLocaleString()}
                            </span>
                          </div>
                          <p className="text-xs text-slate-400">{accountTrades.length} trades</p>
                        </div>
                      );
                    })}
                  </div>
                ) : (
                  <p className="text-center text-slate-400 py-8">No hay KPIs para mostrar</p>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* SOPs TAB */}
          <TabsContent value="sops" className="space-y-6">
            <Card className="bg-slate-900 border-slate-800">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <div className="flex items-center gap-2 mb-2">
                      <BookOpen className="w-5 h-5 text-cyan-400" />
                      <CardTitle className="text-white">SOP Library</CardTitle>
                    </div>
                    <p className="text-sm text-slate-400">Standard Operating Procedures y checklists</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <Button
                      onClick={handleRefresh}
                      disabled={refreshing}
                      variant="outline"
                      size="sm"
                      className="border-slate-700 text-slate-300"
                    >
                      <Activity className={`w-4 h-4 mr-2 ${refreshing ? 'animate-spin' : ''}`} />
                      Actualizar
                    </Button>
                    <Dialog open={sopDialogOpen} onOpenChange={setSopDialogOpen}>
                    <DialogTrigger asChild>
                      <Button className="bg-cyan-600 hover:bg-cyan-700">
                        <Plus className="w-4 h-4 mr-2" />
                        Crear SOP
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="bg-slate-900 border-slate-800 text-white max-w-2xl">
                      <DialogHeader>
                        <DialogTitle>Nuevo SOP</DialogTitle>
                      </DialogHeader>
                      <div className="space-y-4">
                        <div>
                          <label className="text-sm text-slate-400">Título</label>
                          <Input
                            value={sopFormData.title}
                            onChange={(e) => setSopFormData({ ...sopFormData, title: e.target.value })}
                            className="bg-slate-800 border-slate-700 text-white"
                          />
                        </div>
                        <div>
                          <label className="text-sm text-slate-400">Tipo</label>
                          <Select
                            value={sopFormData.type}
                            onValueChange={(value) => setSopFormData({ ...sopFormData, type: value })}
                          >
                            <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="pre_session">Pre Session</SelectItem>
                              <SelectItem value="post_session">Post Session</SelectItem>
                              <SelectItem value="drawdown_protocol">Drawdown Protocol</SelectItem>
                              <SelectItem value="withdrawal_protocol">Withdrawal Protocol</SelectItem>
                              <SelectItem value="weekly_close">Weekly Close</SelectItem>
                              <SelectItem value="monthly_close">Monthly Close</SelectItem>
                              <SelectItem value="custom">Custom</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <div>
                          <label className="text-sm text-slate-400">Contenido</label>
                          <Textarea
                            value={sopFormData.content}
                            onChange={(e) => setSopFormData({ ...sopFormData, content: e.target.value })}
                            className="bg-slate-800 border-slate-700 text-white h-32"
                          />
                        </div>
                        <div className="flex justify-end gap-2">
                          <Button variant="ghost" onClick={() => setSopDialogOpen(false)}>Cancelar</Button>
                          <Button onClick={() => createSopMutation.mutate(sopFormData)} className="bg-cyan-600">
                            Crear
                          </Button>
                        </div>
                      </div>
                    </DialogContent>
                  </Dialog>
                  </div>
                </div>
              </CardHeader>
            </Card>

            {sops.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {sops.map(sop => (
                  <Card key={sop.id} className="bg-slate-900 border-slate-800">
                    <CardHeader>
                      <div className="flex items-center justify-between">
                        <CardTitle className="text-white">{sop.title}</CardTitle>
                        <Badge variant="outline">{sop.type.replace('_', ' ')}</Badge>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <p className="text-sm text-slate-400 whitespace-pre-wrap">{sop.content}</p>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <Card className="bg-slate-900 border-slate-800">
                <CardContent className="py-12">
                  <div className="text-center">
                    <BookOpen className="w-12 h-12 text-slate-600 mx-auto mb-3" />
                    <p className="text-slate-400">No hay SOPs creados</p>
                  </div>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          {/* ROADMAP TAB */}
          <TabsContent value="roadmap" className="space-y-6">
            <Card className="bg-slate-900 border-slate-800">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <div className="flex items-center gap-2 mb-2">
                      <Flag className="w-5 h-5 text-green-400" />
                      <CardTitle className="text-white">Business Milestones Roadmap</CardTitle>
                    </div>
                    <p className="text-sm text-slate-400">Hitos estratégicos del negocio vinculados a metas</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <Button
                      onClick={handleRefresh}
                      disabled={refreshing}
                      variant="outline"
                      size="sm"
                      className="border-slate-700 text-slate-300"
                    >
                      <Activity className={`w-4 h-4 mr-2 ${refreshing ? 'animate-spin' : ''}`} />
                      Actualizar
                    </Button>
                    <Dialog open={milestoneDialogOpen} onOpenChange={setMilestoneDialogOpen}>
                    <DialogTrigger asChild>
                      <Button className="bg-indigo-600 hover:bg-indigo-700">
                        <Plus className="w-4 h-4 mr-2" />
                        Agregar Milestone
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="bg-slate-900 border-slate-800 text-white">
                      <DialogHeader>
                        <DialogTitle>Nuevo Milestone</DialogTitle>
                      </DialogHeader>
                      <div className="space-y-4">
                        <div>
                          <label className="text-sm text-slate-400">Título</label>
                          <Input
                            value={milestoneFormData.title}
                            onChange={(e) => setMilestoneFormData({ ...milestoneFormData, title: e.target.value })}
                            className="bg-slate-800 border-slate-700 text-white"
                          />
                        </div>
                        <div>
                          <label className="text-sm text-slate-400">Descripción</label>
                          <Textarea
                            value={milestoneFormData.description}
                            onChange={(e) => setMilestoneFormData({ ...milestoneFormData, description: e.target.value })}
                            className="bg-slate-800 border-slate-700 text-white"
                          />
                        </div>
                        <div>
                          <label className="text-sm text-slate-400">Fecha objetivo</label>
                          <Input
                            type="date"
                            value={milestoneFormData.target_date}
                            onChange={(e) => setMilestoneFormData({ ...milestoneFormData, target_date: e.target.value })}
                            className="bg-slate-800 border-slate-700 text-white"
                          />
                        </div>
                        <div className="flex justify-end gap-2">
                          <Button variant="ghost" onClick={() => setMilestoneDialogOpen(false)}>Cancelar</Button>
                          <Button onClick={() => createMilestoneMutation.mutate(milestoneFormData)} className="bg-indigo-600">
                            Crear
                          </Button>
                        </div>
                      </div>
                    </DialogContent>
                  </Dialog>
                  </div>
                </div>
              </CardHeader>
            </Card>

            <div className="space-y-6">
              <div>
                <div className="flex items-center gap-2 mb-3">
                  <Clock className="w-5 h-5 text-slate-400" />
                  <h3 className="text-white font-medium">Pending</h3>
                  <Badge variant="outline">{pendingMilestones.length}</Badge>
                </div>
                {pendingMilestones.length > 0 ? (
                  <div className="space-y-2">
                    {pendingMilestones.map(m => (
                      <Card key={m.id} className="bg-slate-900 border-slate-800">
                        <CardContent className="pt-6">
                          <div className="flex items-center justify-between">
                            <div className="flex-1">
                              <p className="text-white font-medium">{m.title}</p>
                              <p className="text-sm text-slate-400 mt-1">{m.description}</p>
                            </div>
                            <Button
                              size="sm"
                              onClick={() => updateMilestoneStatusMutation.mutate({ id: m.id, status: 'in_progress' })}
                              className="bg-blue-600 hover:bg-blue-700"
                            >
                              Start
                            </Button>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                ) : (
                  <p className="text-center text-slate-400 py-8 bg-slate-900/50 rounded-lg">No hay milestones en Pending</p>
                )}
              </div>

              <div>
                <div className="flex items-center gap-2 mb-3">
                  <Activity className="w-5 h-5 text-blue-400" />
                  <h3 className="text-white font-medium">In Progress</h3>
                  <Badge variant="outline">{inProgressMilestones.length}</Badge>
                </div>
                {inProgressMilestones.length > 0 ? (
                  <div className="space-y-2">
                    {inProgressMilestones.map(m => (
                      <Card key={m.id} className="bg-slate-900 border-slate-800 border-l-4 border-l-blue-500">
                        <CardContent className="pt-6">
                          <div className="flex items-center justify-between">
                            <div className="flex-1">
                              <p className="text-white font-medium">{m.title}</p>
                              <p className="text-sm text-slate-400 mt-1">{m.description}</p>
                            </div>
                            <Button
                              size="sm"
                              onClick={() => updateMilestoneStatusMutation.mutate({ id: m.id, status: 'completed' })}
                              className="bg-green-600 hover:bg-green-700"
                            >
                              Complete
                            </Button>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                ) : (
                  <p className="text-center text-slate-400 py-8 bg-slate-900/50 rounded-lg">No hay milestones en In Progress</p>
                )}
              </div>

              <div>
                <div className="flex items-center gap-2 mb-3">
                  <Target className="w-5 h-5 text-green-400" />
                  <h3 className="text-white font-medium">Completed</h3>
                  <Badge variant="outline">{completedMilestones.length}</Badge>
                </div>
                {completedMilestones.length > 0 ? (
                  <div className="space-y-2">
                    {completedMilestones.map(m => (
                      <Card key={m.id} className="bg-slate-900 border-slate-800 border-l-4 border-l-green-500">
                        <CardContent className="pt-6">
                          <div className="flex items-center justify-between">
                            <div className="flex-1">
                              <p className="text-white font-medium">{m.title}</p>
                              <p className="text-sm text-slate-400 mt-1">{m.description}</p>
                            </div>
                            <Badge className="bg-green-600">✓ Completado</Badge>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                ) : (
                  <p className="text-center text-slate-400 py-8 bg-slate-900/50 rounded-lg">No hay milestones en Completed</p>
                )}
              </div>
            </div>
          </TabsContent>

          {/* DECISIONS TAB */}
          <TabsContent value="decisions" className="space-y-6">
            <Card className="bg-slate-900 border-slate-800">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <div className="flex items-center gap-2 mb-2">
                      <FileText className="w-5 h-5 text-purple-400" />
                      <CardTitle className="text-white">Decision Log (CEO Journal)</CardTitle>
                    </div>
                    <p className="text-sm text-slate-400">Registro de decisiones estratégicas de alto nivel</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <Button
                      onClick={handleRefresh}
                      disabled={refreshing}
                      variant="outline"
                      size="sm"
                      className="border-slate-700 text-slate-300"
                    >
                      <Activity className={`w-4 h-4 mr-2 ${refreshing ? 'animate-spin' : ''}`} />
                      Actualizar
                    </Button>
                    <Dialog open={decisionDialogOpen} onOpenChange={setDecisionDialogOpen}>
                    <DialogTrigger asChild>
                      <Button className="bg-indigo-600 hover:bg-indigo-700">
                        <Plus className="w-4 h-4 mr-2" />
                        Nueva Decisión
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="bg-slate-900 border-slate-800 text-white max-w-2xl">
                      <DialogHeader>
                        <DialogTitle>Nueva Decisión Estratégica</DialogTitle>
                      </DialogHeader>
                      <div className="space-y-4">
                        <div>
                          <label className="text-sm text-slate-400">Título</label>
                          <Input
                            value={decisionFormData.title}
                            onChange={(e) => setDecisionFormData({ ...decisionFormData, title: e.target.value })}
                            className="bg-slate-800 border-slate-700 text-white"
                          />
                        </div>
                        <div>
                          <label className="text-sm text-slate-400">Contexto</label>
                          <Textarea
                            value={decisionFormData.context}
                            onChange={(e) => setDecisionFormData({ ...decisionFormData, context: e.target.value })}
                            className="bg-slate-800 border-slate-700 text-white"
                          />
                        </div>
                        <div>
                          <label className="text-sm text-slate-400">Decisión</label>
                          <Textarea
                            value={decisionFormData.decision}
                            onChange={(e) => setDecisionFormData({ ...decisionFormData, decision: e.target.value })}
                            className="bg-slate-800 border-slate-700 text-white"
                          />
                        </div>
                        <div>
                          <label className="text-sm text-slate-400">Rationale</label>
                          <Textarea
                            value={decisionFormData.rationale}
                            onChange={(e) => setDecisionFormData({ ...decisionFormData, rationale: e.target.value })}
                            className="bg-slate-800 border-slate-700 text-white"
                          />
                        </div>
                        <div className="flex justify-end gap-2">
                          <Button variant="ghost" onClick={() => setDecisionDialogOpen(false)}>Cancelar</Button>
                          <Button onClick={() => createDecisionMutation.mutate(decisionFormData)} className="bg-indigo-600">
                            Registrar
                          </Button>
                        </div>
                      </div>
                    </DialogContent>
                  </Dialog>
                  </div>
                </div>
              </CardHeader>
            </Card>

            {decisions.length > 0 ? (
              <div className="space-y-4">
                {decisions.map(decision => (
                  <Card key={decision.id} className="bg-slate-900 border-slate-800">
                    <CardHeader>
                      <div className="flex items-center justify-between">
                        <CardTitle className="text-white">{decision.title}</CardTitle>
                        <Badge variant="outline">{new Date(decision.created_date).toLocaleDateString()}</Badge>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      {decision.context && (
                        <div>
                          <p className="text-sm font-medium text-slate-400 mb-1">Contexto:</p>
                          <p className="text-slate-300">{decision.context}</p>
                        </div>
                      )}
                      {decision.decision && (
                        <div>
                          <p className="text-sm font-medium text-slate-400 mb-1">Decisión:</p>
                          <p className="text-white">{decision.decision}</p>
                        </div>
                      )}
                      {decision.rationale && (
                        <div>
                          <p className="text-sm font-medium text-slate-400 mb-1">Rationale:</p>
                          <p className="text-slate-300">{decision.rationale}</p>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <Card className="bg-slate-900 border-slate-800">
                <CardContent className="py-12">
                  <div className="text-center">
                    <FileText className="w-12 h-12 text-slate-600 mx-auto mb-3" />
                    <p className="text-slate-400">No hay decisiones registradas</p>
                  </div>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          {/* LLC TAB */}
          <TabsContent value="llc" className="space-y-6">
            <Card className="bg-slate-900 border-slate-800">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <div className="flex items-center gap-2 mb-2">
                      <Building2 className="w-5 h-5 text-blue-400" />
                      <CardTitle className="text-white">Wyoming LLC Basics</CardTitle>
                    </div>
                    <p className="text-sm text-slate-400">Información esencial de tu LLC</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <Button
                      onClick={handleRefresh}
                      disabled={refreshing}
                      variant="outline"
                      size="sm"
                      className="border-slate-700 text-slate-300"
                    >
                      <Activity className={`w-4 h-4 mr-2 ${refreshing ? 'animate-spin' : ''}`} />
                      Actualizar
                    </Button>
                    <Button
                      variant="outline"
                      onClick={() => {
                        setEditingLLC(!editingLLC);
                        if (llcInfo.id) {
                          setLlcFormData({
                            llc_name: llcInfo.llc_name || '',
                            formation_date: llcInfo.formation_date || '',
                            annual_report_due_month: llcInfo.annual_report_due_month || 1,
                            annual_fee_baseline: llcInfo.annual_fee_baseline || 60,
                            registered_agent_name: llcInfo.registered_agent_name || '',
                            ein: llcInfo.ein || '',
                            notes: llcInfo.notes || ''
                          });
                        }
                      }}
                    >
                      {editingLLC ? 'Cancelar' : 'Editar'}
                    </Button>
                  </div>
                </div>
              </CardHeader>
            </Card>

            {editingLLC ? (
              <Card className="bg-slate-900 border-slate-800">
                <CardContent className="pt-6 space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="text-sm text-slate-400">Nombre de la LLC</label>
                      <Input
                        value={llcFormData.llc_name}
                        onChange={(e) => setLlcFormData({ ...llcFormData, llc_name: e.target.value })}
                        className="bg-slate-800 border-slate-700 text-white"
                      />
                    </div>
                    <div>
                      <label className="text-sm text-slate-400">Fecha de Formación</label>
                      <Input
                        type="date"
                        value={llcFormData.formation_date}
                        onChange={(e) => setLlcFormData({ ...llcFormData, formation_date: e.target.value })}
                        className="bg-slate-800 border-slate-700 text-white"
                      />
                    </div>
                    <div>
                      <label className="text-sm text-slate-400">Mes de reporte anual</label>
                      <Select
                        value={llcFormData.annual_report_due_month.toString()}
                        onValueChange={(value) => setLlcFormData({ ...llcFormData, annual_report_due_month: parseInt(value) })}
                      >
                        <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12].map(m => (
                            <SelectItem key={m} value={m.toString()}>{m}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <label className="text-sm text-slate-400">Fee Baseline Anual</label>
                      <Input
                        type="number"
                        value={llcFormData.annual_fee_baseline}
                        onChange={(e) => setLlcFormData({ ...llcFormData, annual_fee_baseline: parseFloat(e.target.value) })}
                        className="bg-slate-800 border-slate-700 text-white"
                      />
                    </div>
                    <div>
                      <label className="text-sm text-slate-400">Registered Agent</label>
                      <Input
                        value={llcFormData.registered_agent_name}
                        onChange={(e) => setLlcFormData({ ...llcFormData, registered_agent_name: e.target.value })}
                        className="bg-slate-800 border-slate-700 text-white"
                      />
                    </div>
                    <div>
                      <label className="text-sm text-slate-400">EIN</label>
                      <Input
                        value={llcFormData.ein}
                        onChange={(e) => setLlcFormData({ ...llcFormData, ein: e.target.value })}
                        className="bg-slate-800 border-slate-700 text-white"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="text-sm text-slate-400">Notas</label>
                    <Textarea
                      value={llcFormData.notes}
                      onChange={(e) => setLlcFormData({ ...llcFormData, notes: e.target.value })}
                      className="bg-slate-800 border-slate-700 text-white"
                    />
                  </div>
                  <div className="flex justify-end">
                    <Button onClick={() => updateLLCMutation.mutate(llcFormData)} className="bg-indigo-600">
                      Guardar
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ) : (
              <>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Card className="bg-slate-900 border-slate-800">
                    <CardHeader className="pb-3">
                      <CardTitle className="text-sm text-slate-400 flex items-center gap-2">
                        <Calendar className="w-4 h-4" />
                        Annual Report Reminder
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-xs text-slate-400 mb-1">Mes de reporte anual</p>
                      <Badge className="bg-amber-600">Día 1 de Enero</Badge>
                    </CardContent>
                  </Card>

                  <Card className="bg-slate-900 border-slate-800">
                    <CardHeader className="pb-3">
                      <CardTitle className="text-sm text-slate-400 flex items-center gap-2">
                        <DollarSign className="w-4 h-4" />
                        Fee Baseline
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-xs text-slate-400 mb-1">Mínimo anual</p>
                      <p className="text-2xl font-bold text-green-400">${llcInfo.annual_fee_baseline || 60}</p>
                    </CardContent>
                  </Card>

                  <Card className="bg-slate-900 border-slate-800">
                    <CardHeader className="pb-3">
                      <CardTitle className="text-sm text-slate-400 flex items-center gap-2">
                        <Shield className="w-4 h-4" />
                        Registered Agent
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-white">{llcInfo.registered_agent_name || 'No registrado'}</p>
                    </CardContent>
                  </Card>

                  <Card className="bg-slate-900 border-slate-800">
                    <CardHeader className="pb-3">
                      <CardTitle className="text-sm text-slate-400 flex items-center gap-2">
                        <FileText className="w-4 h-4" />
                        EIN Vault
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-white font-mono">{llcInfo.ein || '••-•••••••'}</p>
                    </CardContent>
                  </Card>
                </div>

                <Card className="bg-slate-900 border-slate-800">
                  <CardHeader>
                    <div className="flex items-center gap-2">
                      <Mail className="w-5 h-5 text-blue-400" />
                      <CardTitle className="text-white">LLC Inbox</CardTitle>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-slate-400 text-center py-8">No hay mensajes</p>
                  </CardContent>
                </Card>
              </>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}