import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Target, Plus, TrendingUp, Edit, Trash2, Calendar, CheckCircle2, ChevronLeft } from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

export default function Goals() {
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingGoal, setEditingGoal] = useState(null);
  const [selectedGoal, setSelectedGoal] = useState(null);
  const [formData, setFormData] = useState({
    account_id: '',
    title: '',
    year: 2025,
    active_quarter: 'Q1',
    q1_start_date: '',
    q1_end_date: '',
    q1_start_balance: 0,
    q1_target_balance: 0,
    q2_start_date: '',
    q2_end_date: '',
    q2_start_balance: 0,
    q2_target_balance: 0,
    q3_start_date: '',
    q3_end_date: '',
    q3_start_balance: 0,
    q3_target_balance: 0,
    q4_start_date: '',
    q4_end_date: '',
    q4_start_balance: 0,
    q4_target_balance: 0
  });

  const queryClient = useQueryClient();

  const { data: goals = [] } = useQuery({
    queryKey: ['goals'],
    queryFn: () => base44.entities.Goal.filter({ is_deleted: false })
  });

  const { data: accounts = [] } = useQuery({
    queryKey: ['accounts'],
    queryFn: () => base44.entities.Account.filter({ is_deleted: false })
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.Goal.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries(['goals']);
      setDialogOpen(false);
      resetForm();
    }
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Goal.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries(['goals']);
      setDialogOpen(false);
      resetForm();
    }
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.Goal.update(id, { is_deleted: true, deleted_at: new Date().toISOString() }),
    onSuccess: () => {
      queryClient.invalidateQueries(['goals']);
      setSelectedGoal(null);
    }
  });

  const resetForm = () => {
    setFormData({
      account_id: '',
      title: '',
      year: 2025,
      active_quarter: 'Q1',
      q1_start_date: '',
      q1_end_date: '',
      q1_start_balance: 0,
      q1_target_balance: 0,
      q2_start_date: '',
      q2_end_date: '',
      q2_start_balance: 0,
      q2_target_balance: 0,
      q3_start_date: '',
      q3_end_date: '',
      q3_start_balance: 0,
      q3_target_balance: 0,
      q4_start_date: '',
      q4_end_date: '',
      q4_start_balance: 0,
      q4_target_balance: 0
    });
    setEditingGoal(null);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (editingGoal) {
      updateMutation.mutate({ id: editingGoal.id, data: formData });
    } else {
      createMutation.mutate(formData);
    }
  };

  const handleEdit = (goal) => {
    setEditingGoal(goal);
    setFormData({
      account_id: goal.account_id,
      title: goal.title,
      year: goal.year,
      active_quarter: goal.active_quarter || 'Q1',
      q1_start_date: goal.q1_start_date || '',
      q1_end_date: goal.q1_end_date || '',
      q1_start_balance: goal.q1_start_balance || 0,
      q1_target_balance: goal.q1_target_balance || 0,
      q2_start_date: goal.q2_start_date || '',
      q2_end_date: goal.q2_end_date || '',
      q2_start_balance: goal.q2_start_balance || 0,
      q2_target_balance: goal.q2_target_balance || 0,
      q3_start_date: goal.q3_start_date || '',
      q3_end_date: goal.q3_end_date || '',
      q3_start_balance: goal.q3_start_balance || 0,
      q3_target_balance: goal.q3_target_balance || 0,
      q4_start_date: goal.q4_start_date || '',
      q4_end_date: goal.q4_end_date || '',
      q4_start_balance: goal.q4_start_balance || 0,
      q4_target_balance: goal.q4_target_balance || 0
    });
    setDialogOpen(true);
  };

  const getAccountName = (accId) => {
    const acc = accounts.find(a => a.id === accId);
    return acc?.name || 'Unknown';
  };

  const calculateProgress = (goal) => {
    const q = goal.active_quarter || 'Q1';
    const startBalance = goal[`${q.toLowerCase()}_start_balance`] || 0;
    const targetBalance = goal[`${q.toLowerCase()}_target_balance`] || 0;
    const accumulated = goal[`${q.toLowerCase()}_accumulated_profit`] || 0;
    
    const needed = targetBalance - startBalance;
    if (needed <= 0) return 100;
    
    return Math.min(100, (accumulated / needed) * 100);
  };

  return (
    <div className="min-h-screen bg-slate-950 p-6">
      <div className="max-w-7xl mx-auto">
        <Link to={createPageUrl('Dashboard')}>
          <Button variant="ghost" size="sm" className="text-slate-400 hover:text-white mb-4">
            <ChevronLeft className="w-4 h-4 mr-1" />
            Atrás
          </Button>
        </Link>
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <Target className="w-8 h-8 text-cyan-400" />
            <h1 className="text-3xl font-bold text-white">Goals & Plans</h1>
          </div>
          <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
            <DialogTrigger asChild>
              <Button onClick={resetForm} className="bg-cyan-600 hover:bg-cyan-700">
                <Plus className="w-4 h-4 mr-2" />
                New Goal
              </Button>
            </DialogTrigger>
            <DialogContent className="bg-slate-900 border-slate-800 text-white max-w-3xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>{editingGoal ? 'Edit Goal' : 'New Goal'}</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm text-slate-400">Account</label>
                    <Select value={formData.account_id} onValueChange={(value) => setFormData({ ...formData, account_id: value })}>
                      <SelectTrigger className="bg-slate-800 border-slate-700">
                        <SelectValue placeholder="Select account" />
                      </SelectTrigger>
                      <SelectContent>
                        {accounts.map(acc => (
                          <SelectItem key={acc.id} value={acc.id}>{acc.name}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <label className="text-sm text-slate-400">Year</label>
                    <Input
                      type="number"
                      value={formData.year}
                      onChange={(e) => setFormData({ ...formData, year: parseInt(e.target.value) })}
                      className="bg-slate-800 border-slate-700"
                    />
                  </div>
                </div>
                <div>
                  <label className="text-sm text-slate-400">Title</label>
                  <Input
                    value={formData.title}
                    onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                    placeholder="Goal title..."
                    className="bg-slate-800 border-slate-700"
                  />
                </div>
                <div>
                  <label className="text-sm text-slate-400">Active Quarter</label>
                  <Select value={formData.active_quarter} onValueChange={(value) => setFormData({ ...formData, active_quarter: value })}>
                    <SelectTrigger className="bg-slate-800 border-slate-700">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Q1">Q1</SelectItem>
                      <SelectItem value="Q2">Q2</SelectItem>
                      <SelectItem value="Q3">Q3</SelectItem>
                      <SelectItem value="Q4">Q4</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <Tabs defaultValue="q1" className="w-full">
                  <TabsList className="grid w-full grid-cols-4 bg-slate-800">
                    <TabsTrigger value="q1">Q1</TabsTrigger>
                    <TabsTrigger value="q2">Q2</TabsTrigger>
                    <TabsTrigger value="q3">Q3</TabsTrigger>
                    <TabsTrigger value="q4">Q4</TabsTrigger>
                  </TabsList>
                  
                  {['q1', 'q2', 'q3', 'q4'].map(q => (
                    <TabsContent key={q} value={q} className="space-y-4">
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label className="text-sm text-slate-400">Start Date</label>
                          <Input
                            type="date"
                            value={formData[`${q}_start_date`]}
                            onChange={(e) => setFormData({ ...formData, [`${q}_start_date`]: e.target.value })}
                            className="bg-slate-800 border-slate-700"
                          />
                        </div>
                        <div>
                          <label className="text-sm text-slate-400">End Date</label>
                          <Input
                            type="date"
                            value={formData[`${q}_end_date`]}
                            onChange={(e) => setFormData({ ...formData, [`${q}_end_date`]: e.target.value })}
                            className="bg-slate-800 border-slate-700"
                          />
                        </div>
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label className="text-sm text-slate-400">Start Balance</label>
                          <Input
                            type="number"
                            value={formData[`${q}_start_balance`]}
                            onChange={(e) => setFormData({ ...formData, [`${q}_start_balance`]: parseFloat(e.target.value) })}
                            className="bg-slate-800 border-slate-700"
                          />
                        </div>
                        <div>
                          <label className="text-sm text-slate-400">Target Balance</label>
                          <Input
                            type="number"
                            value={formData[`${q}_target_balance`]}
                            onChange={(e) => setFormData({ ...formData, [`${q}_target_balance`]: parseFloat(e.target.value) })}
                            className="bg-slate-800 border-slate-700"
                          />
                        </div>
                      </div>
                    </TabsContent>
                  ))}
                </Tabs>

                <div className="flex justify-end gap-2 pt-4">
                  <Button type="button" variant="ghost" onClick={() => setDialogOpen(false)}>Cancel</Button>
                  <Button type="submit" className="bg-cyan-600 hover:bg-cyan-700">
                    {editingGoal ? 'Update' : 'Create'}
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        {!selectedGoal ? (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {goals.map((goal) => {
              const progress = calculateProgress(goal);
              const q = goal.active_quarter || 'Q1';
              const startBalance = goal[`${q.toLowerCase()}_start_balance`] || 0;
              const targetBalance = goal[`${q.toLowerCase()}_target_balance`] || 0;
              const accumulated = goal[`${q.toLowerCase()}_accumulated_profit`] || 0;
              const needed = targetBalance - startBalance;

              return (
                <Card key={goal.id} className="bg-slate-900 border-slate-800 cursor-pointer hover:border-slate-700 transition-colors">
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div className="flex-1" onClick={() => setSelectedGoal(goal)}>
                        <CardTitle className="text-white">{goal.title}</CardTitle>
                        <p className="text-sm text-slate-400 mt-1">{getAccountName(goal.account_id)} - {goal.year}</p>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="flex items-center gap-2 px-3 py-1 bg-cyan-600 rounded-full">
                          <Target className="w-3 h-3 text-white" />
                          <span className="text-xs font-medium text-white">{q}</span>
                        </div>
                        <Button size="icon" variant="ghost" onClick={() => handleEdit(goal)} className="text-slate-400 hover:text-white h-8 w-8">
                          <Edit className="w-3 h-3" />
                        </Button>
                        <Button size="icon" variant="ghost" onClick={() => deleteMutation.mutate(goal.id)} className="text-slate-400 hover:text-red-400 h-8 w-8">
                          <Trash2 className="w-3 h-3" />
                        </Button>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm text-slate-400">Progress</span>
                        <span className="text-sm font-medium text-white">{progress.toFixed(1)}%</span>
                      </div>
                      <Progress value={progress} className="h-2" />
                    </div>

                    <div className="grid grid-cols-3 gap-4 pt-2">
                      <div>
                        <p className="text-xs text-slate-400">Start</p>
                        <p className="text-lg font-bold text-white">${startBalance.toLocaleString()}</p>
                      </div>
                      <div>
                        <p className="text-xs text-slate-400">Target</p>
                        <p className="text-lg font-bold text-cyan-400">${targetBalance.toLocaleString()}</p>
                      </div>
                      <div>
                        <p className="text-xs text-slate-400">Profit</p>
                        <p className={`text-lg font-bold ${accumulated >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                          ${accumulated.toLocaleString()}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 pt-2 border-t border-slate-800">
                      <TrendingUp className="w-4 h-4 text-slate-400" />
                      <span className="text-sm text-slate-400">
                        {accumulated >= needed ? (
                          <span className="text-green-400 font-medium">Goal achieved! 🎉</span>
                        ) : (
                          <>Need ${(needed - accumulated).toLocaleString()} more</>
                        )}
                      </span>
                    </div>
                  </CardContent>
                </Card>
              );
            })}

            {goals.length === 0 && (
              <Card className="bg-slate-900 border-slate-800 col-span-full">
                <CardContent className="py-12">
                  <p className="text-center text-slate-400">No goals yet. Create your first one!</p>
                </CardContent>
              </Card>
            )}
          </div>
        ) : (
          <div className="space-y-6">
            <Button 
              variant="ghost" 
              onClick={() => setSelectedGoal(null)}
              className="text-slate-400 hover:text-white"
            >
              ← Back to all goals
            </Button>

            <Card className="bg-slate-900 border-slate-800">
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div>
                    <CardTitle className="text-white text-2xl">{selectedGoal.title}</CardTitle>
                    <p className="text-slate-400 mt-1">{getAccountName(selectedGoal.account_id)} - {selectedGoal.year}</p>
                  </div>
                  <Badge className="bg-cyan-600">{selectedGoal.active_quarter}</Badge>
                </div>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue={selectedGoal.active_quarter.toLowerCase()} className="w-full">
                  <TabsList className="grid w-full grid-cols-4 bg-slate-800">
                    {['Q1', 'Q2', 'Q3', 'Q4'].map(q => {
                      const qLower = q.toLowerCase();
                      const isCompleted = selectedGoal.completed_quarters?.includes(q);
                      return (
                        <TabsTrigger 
                          key={q} 
                          value={qLower}
                          className="relative"
                        >
                          {q}
                          {isCompleted && (
                            <CheckCircle2 className="w-3 h-3 text-green-400 absolute top-1 right-1" />
                          )}
                        </TabsTrigger>
                      );
                    })}
                  </TabsList>

                  {['q1', 'q2', 'q3', 'q4'].map(q => {
                    const startDate = selectedGoal[`${q}_start_date`];
                    const endDate = selectedGoal[`${q}_end_date`];
                    const startBalance = selectedGoal[`${q}_start_balance`] || 0;
                    const targetBalance = selectedGoal[`${q}_target_balance`] || 0;
                    const accumulated = selectedGoal[`${q}_accumulated_profit`] || 0;
                    const tradedDays = selectedGoal[`${q}_traded_days`] || 0;
                    const needed = targetBalance - startBalance;
                    const progress = needed > 0 ? Math.min(100, (accumulated / needed) * 100) : 100;

                    return (
                      <TabsContent key={q} value={q} className="space-y-6 pt-6">
                        {startDate && endDate ? (
                          <>
                            <div className="flex items-center gap-2 text-slate-400 text-sm">
                              <Calendar className="w-4 h-4" />
                              <span>{startDate} → {endDate}</span>
                            </div>

                            <div>
                              <div className="flex items-center justify-between mb-2">
                                <span className="text-sm text-slate-400">Progress</span>
                                <span className="text-lg font-bold text-white">{progress.toFixed(1)}%</span>
                              </div>
                              <Progress value={progress} className="h-3" />
                            </div>

                            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                              <Card className="bg-slate-800 border-slate-700">
                                <CardContent className="pt-6">
                                  <p className="text-xs text-slate-400 mb-1">Start Balance</p>
                                  <p className="text-xl font-bold text-white">${startBalance.toLocaleString()}</p>
                                </CardContent>
                              </Card>
                              <Card className="bg-slate-800 border-slate-700">
                                <CardContent className="pt-6">
                                  <p className="text-xs text-slate-400 mb-1">Target Balance</p>
                                  <p className="text-xl font-bold text-cyan-400">${targetBalance.toLocaleString()}</p>
                                </CardContent>
                              </Card>
                              <Card className="bg-slate-800 border-slate-700">
                                <CardContent className="pt-6">
                                  <p className="text-xs text-slate-400 mb-1">Accumulated P&L</p>
                                  <p className={`text-xl font-bold ${accumulated >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                                    ${accumulated.toLocaleString()}
                                  </p>
                                </CardContent>
                              </Card>
                              <Card className="bg-slate-800 border-slate-700">
                                <CardContent className="pt-6">
                                  <p className="text-xs text-slate-400 mb-1">Traded Days</p>
                                  <p className="text-xl font-bold text-white">{tradedDays}</p>
                                </CardContent>
                              </Card>
                            </div>

                            <Card className="bg-slate-800 border-slate-700">
                              <CardContent className="pt-6">
                                <div className="flex items-center justify-between">
                                  <div>
                                    <p className="text-slate-400 text-sm">Status</p>
                                    <p className="text-white text-lg font-medium mt-1">
                                      {accumulated >= needed ? (
                                        <span className="text-green-400 flex items-center gap-2">
                                          <CheckCircle2 className="w-5 h-5" />
                                          Goal Achieved! 🎉
                                        </span>
                                      ) : (
                                        <span>Need ${(needed - accumulated).toLocaleString()} more</span>
                                      )}
                                    </p>
                                  </div>
                                  {needed > 0 && accumulated < needed && (
                                    <div className="text-right">
                                      <p className="text-slate-400 text-sm">Remaining</p>
                                      <p className="text-white text-2xl font-bold">
                                        {((needed - accumulated) / needed * 100).toFixed(1)}%
                                      </p>
                                    </div>
                                  )}
                                </div>
                              </CardContent>
                            </Card>
                          </>
                        ) : (
                          <div className="text-center py-12">
                            <p className="text-slate-400">No data configured for {q.toUpperCase()}</p>
                          </div>
                        )}
                      </TabsContent>
                    );
                  })}
                </Tabs>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}