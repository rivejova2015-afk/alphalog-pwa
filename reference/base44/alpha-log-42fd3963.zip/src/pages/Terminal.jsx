import React, { useState, useEffect } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Switch } from '@/components/ui/switch';
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Label } from '@/components/ui/label';
import { ChevronLeft, RefreshCw, Clock, ClipboardList, Bell, Settings } from 'lucide-react';
import { createPageUrl } from '@/utils';
import { Link } from 'react-router-dom';
import { useTranslation } from '@/components/utils/translations';
import DriversCard from '@/components/terminal/market/DriversCard';
import TodayCard from '@/components/terminal/market/TodayCard';
import IntelCard from '@/components/terminal/market/IntelCard';
import EvidenceCard from '@/components/terminal/market/EvidenceCard';
import NewsPanel from '@/components/terminal/market/NewsPanel.jsx';
import CalendarView from '@/components/terminal/CalendarView';
import EvidenceView from '@/components/terminal/EvidenceView';
import SearchView from '@/components/terminal/SearchView';
import ReportScheduler from '@/components/terminal/ReportScheduler';

export default function Terminal() {
  const { t } = useTranslation();
  const [activeTab, setActiveTab] = useState('dossier');
  const [autoRefresh, setAutoRefresh] = useState(true);
  const [showHistory, setShowHistory] = useState(false);
  const [showTasks, setShowTasks] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const [showSettings, setShowSettings] = useState(false);

  // Get or create AppState
  const { data: appState } = useQuery({
    queryKey: ['app-state'],
    queryFn: async () => {
      const states = await base44.entities.AppState.list();
      if (states.length === 0) {
        return await base44.entities.AppState.create({
          active_instrument: 'XAUUSD',
          auto_refresh_enabled: true,
          auto_refresh_seconds: 60
        });
      }
      return states[0];
    }
  });

  const selectedInstrument = appState?.active_instrument || 'XAUUSD';
  


  const queryClient = useQueryClient();

  const setSelectedInstrument = async (instrument) => {
    if (appState) {
      await base44.entities.AppState.update(appState.id, {
        active_instrument: instrument
      });
      queryClient.invalidateQueries(['app-state']);
      queryClient.invalidateQueries(['market-snapshot']);
    }
  };

  const [refreshing, setRefreshing] = useState(false);

  const { data: snapshot, isLoading } = useQuery({
    queryKey: ['market-snapshot', selectedInstrument],
    queryFn: async () => {
      const snapshots = await base44.entities.MarketSnapshot.filter({
        instrument_id: selectedInstrument
      }, '-as_of_utc', 1);
      return snapshots[0] || null;
    },
    refetchInterval: autoRefresh ? 60000 : false,
    enabled: !!selectedInstrument
  });

  const handleRefresh = async () => {
    setRefreshing(true);
    await Promise.all([
      queryClient.invalidateQueries(['market-snapshot', selectedInstrument]),
      queryClient.invalidateQueries(['terminal-news', selectedInstrument]),
      queryClient.invalidateQueries(['terminal-events', selectedInstrument]),
      queryClient.invalidateQueries(['terminal-claims', selectedInstrument])
    ]);
    setRefreshing(false);
  };

  const payload = snapshot?.payload_json || {};
  const price = payload.price || {};
  const healthFlags = snapshot?.health_flags || [];

  return (
    <div className="min-h-screen bg-slate-950">
      {/* Terminal Header */}
      <div className="bg-slate-900 border-b border-slate-800 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-6 py-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Link to={createPageUrl('Dashboard')}>
                <Button variant="ghost" size="sm" className="text-slate-400 hover:text-white">
                  <ChevronLeft className="w-4 h-4 mr-1" />
                  {t('markets')}
                </Button>
              </Link>
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-lg flex items-center justify-center">
                  <svg className="w-4 h-4 text-white" fill="currentColor" viewBox="0 0 20 20">
                    <path d="M10 2L2 7l8 5 8-5-8-5zM2 17l8 5 8-5M2 12l8 5 8-5"/>
                  </svg>
                </div>
                <h1 className="text-lg font-bold text-white">AlphaLog Terminal</h1>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={handleRefresh}
                disabled={refreshing}
                className="text-slate-400 hover:text-white"
              >
                <RefreshCw className={`w-4 h-4 mr-1 ${refreshing ? 'animate-spin' : ''}`} />
                {refreshing ? t('generating') : t('refresh')}
              </Button>
              <Button 
                size="sm" 
                onClick={() => setAutoRefresh(!autoRefresh)}
                className={autoRefresh ? 'bg-green-600 hover:bg-green-700' : 'bg-slate-700'}
              >
                Auto
              </Button>
              <Button 
                variant="ghost" 
                size="icon" 
                className="text-slate-400 hover:text-white"
                onClick={() => setShowHistory(!showHistory)}
                title="History"
              >
                <Clock className="w-4 h-4" />
              </Button>
              <Button 
                variant="ghost" 
                size="icon" 
                className="text-slate-400 hover:text-white"
                onClick={() => setShowTasks(!showTasks)}
                title="Tasks"
              >
                <ClipboardList className="w-4 h-4" />
              </Button>
              <Button 
                variant="ghost" 
                size="icon" 
                className="text-slate-400 hover:text-white"
                onClick={() => setShowNotifications(!showNotifications)}
                title="Notifications"
              >
                <Bell className="w-4 h-4" />
              </Button>
              <Button 
                variant="ghost" 
                size="icon" 
                className="text-slate-400 hover:text-white"
                onClick={() => setShowSettings(!showSettings)}
                title="Settings"
              >
                <Settings className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-6 py-6">
        {/* Instrument Selector */}
        <div className="mb-6 flex items-center gap-4">
          <span className="text-slate-400 text-sm">{t('analyzing')}</span>
          <div className="flex items-center gap-2">
            <Button
              onClick={() => setSelectedInstrument('XAUUSD')}
              variant={selectedInstrument === 'XAUUSD' ? 'default' : 'outline'}
              className={selectedInstrument === 'XAUUSD' ? 'bg-amber-600 hover:bg-amber-700' : 'border-slate-700 text-slate-300'}
              size="sm"
            >
              XAUUSD
            </Button>
            <Button
              onClick={() => setSelectedInstrument('SP500')}
              variant={selectedInstrument === 'SP500' ? 'default' : 'outline'}
              className={selectedInstrument === 'SP500' ? 'bg-blue-600 hover:bg-blue-700' : 'border-slate-700 text-slate-300'}
              size="sm"
            >
              SP500
            </Button>
          </div>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="bg-transparent border-b border-slate-800 rounded-none p-0 h-auto space-x-1">
            <TabsTrigger 
              value="dossier" 
              className="data-[state=active]:bg-white data-[state=active]:text-slate-900 rounded-t-lg rounded-b-none px-6 py-2"
            >
              {t('dossier')}
            </TabsTrigger>
            <TabsTrigger 
              value="calendar" 
              className="data-[state=active]:bg-white data-[state=active]:text-slate-900 rounded-t-lg rounded-b-none px-6 py-2 text-slate-400"
            >
              {t('calendarEvents')}
            </TabsTrigger>
            <TabsTrigger 
              value="evidence" 
              className="data-[state=active]:bg-white data-[state=active]:text-slate-900 rounded-t-lg rounded-b-none px-6 py-2 text-slate-400"
            >
              {t('evidenceAudit')}
            </TabsTrigger>
            <TabsTrigger 
              value="search" 
              className="data-[state=active]:bg-white data-[state=active]:text-slate-900 rounded-t-lg rounded-b-none px-6 py-2 text-slate-400"
            >
              {t('search')}
            </TabsTrigger>
          </TabsList>

          <TabsContent value="dossier" className="space-y-6 mt-6">
            <div className="grid grid-cols-4 gap-4">
              <DriversCard drivers={payload.yesterday?.drivers_top || []} />
              <TodayCard events={payload.today?.events || []} instrument={selectedInstrument} />
              <TodayCard events={payload.today?.events || []} instrument={selectedInstrument} />
              <div className="space-y-4">
                <IntelCard claims={payload.intel?.drivers_ranked || []} />
                <EvidenceCard />
              </div>
            </div>

            <div className="space-y-6">
              <NewsPanel instrument={selectedInstrument} />
              <ReportScheduler instrument={selectedInstrument} />
            </div>
            </TabsContent>

            <TabsContent value="calendar">
            <CalendarView instrument={selectedInstrument} />
            </TabsContent>

          <TabsContent value="evidence">
            <EvidenceView instrument={selectedInstrument} />
          </TabsContent>

          <TabsContent value="search">
            <SearchView />
          </TabsContent>
        </Tabs>
      </div>

      {/* History Dialog */}
      <Dialog open={showHistory} onOpenChange={setShowHistory}>
        <DialogContent className="bg-slate-900 border-slate-800 text-white">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Clock className="w-5 h-5" />
              {t('snapshotHistory')}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-2 max-h-96 overflow-y-auto">
            {snapshot ? (
              <div className="p-3 bg-slate-800 rounded-lg">
                <p className="text-sm text-slate-300">{t('latest')} {new Date(snapshot.as_of_utc).toLocaleString()}</p>
                <p className="text-xs text-slate-400 mt-1">{t('confidence')} {snapshot.confidence}%</p>
              </div>
            ) : (
              <p className="text-slate-400 text-center py-8">{t('noHistoryAvailable')}</p>
            )}
          </div>
        </DialogContent>
      </Dialog>

      {/* Tasks Dialog */}
      <Dialog open={showTasks} onOpenChange={setShowTasks}>
        <DialogContent className="bg-slate-900 border-slate-800 text-white">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <ClipboardList className="w-5 h-5" />
              {t('tasksChecklist')}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-2">
            <div className="p-3 bg-slate-800 rounded-lg flex items-center justify-between">
              <span className="text-sm">{t('reviewDailyOutlook')}</span>
              <Badge variant="outline">{t('pending')}</Badge>
            </div>
            <div className="p-3 bg-slate-800 rounded-lg flex items-center justify-between">
              <span className="text-sm">{t('checkNewsSentiment')}</span>
              <Badge variant="outline">{t('pending')}</Badge>
            </div>
            <div className="p-3 bg-slate-800 rounded-lg flex items-center justify-between">
              <span className="text-sm">{t('verifyClaims')}</span>
              <Badge variant="outline">{t('pending')}</Badge>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Notifications Dialog */}
      <Dialog open={showNotifications} onOpenChange={setShowNotifications}>
        <DialogContent className="bg-slate-900 border-slate-800 text-white">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Bell className="w-5 h-5" />
              {t('notifications')}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-2">
            {healthFlags.length > 0 ? (
              healthFlags.map((flag, idx) => (
                <div key={idx} className="p-3 bg-amber-900/20 border border-amber-600 rounded-lg">
                  <p className="text-sm text-amber-400">{flag}</p>
                </div>
              ))
            ) : (
              <p className="text-slate-400 text-center py-8">{t('noNotifications')}</p>
            )}
          </div>
        </DialogContent>
      </Dialog>

      {/* Settings Dialog */}
      <Dialog open={showSettings} onOpenChange={setShowSettings}>
        <DialogContent className="bg-slate-900 border-slate-800 text-white">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Settings className="w-5 h-5" />
              {t('terminalSettings')}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="flex items-center justify-between p-3 bg-slate-800 rounded-lg">
              <div>
                <Label className="text-white font-medium">{t('autoRefresh')}</Label>
                <p className="text-xs text-slate-400">{t('autoRefreshDesc')}</p>
              </div>
              <Switch
                checked={autoRefresh}
                onCheckedChange={setAutoRefresh}
              />
            </div>
            <div className="p-3 bg-slate-800 rounded-lg">
              <Label className="text-white font-medium">{t('activeInstrument')}</Label>
              <p className="text-sm text-slate-400 mt-2">{selectedInstrument}</p>
            </div>
            <div className="p-3 bg-slate-800 rounded-lg">
              <Label className="text-white font-medium">{t('healthStatus')}</Label>
              <p className="text-sm text-slate-400 mt-2">
                {healthFlags.length === 0 ? t('allSystemsOperational') : `${healthFlags.length} ${t('issuesDetected')}`}
              </p>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}