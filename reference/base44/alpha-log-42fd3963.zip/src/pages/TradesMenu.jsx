import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { TrendingUp, Wallet, BarChart3, ChevronLeft, ArrowRight } from 'lucide-react';

export default function TradesMenu() {
  const { data: accounts = [] } = useQuery({
    queryKey: ['tradesmenu-accounts'],
    queryFn: () => base44.entities.Account.filter({ is_deleted: false, operation_state: 'ACTIVE' })
  });

  const { data: trades = [] } = useQuery({
    queryKey: ['tradesmenu-trades'],
    queryFn: () => base44.entities.Trade.filter({ is_deleted: false, status: 'Closed' })
  });

  // Calculate account stats
  const getAccountPnL = (accountId) => {
    const accountTrades = trades.filter(t => t.account_id === accountId);
    return accountTrades.reduce((sum, t) => sum + (t.pnl || 0), 0);
  };

  const getAccountPnLPct = (account) => {
    const pnl = getAccountPnL(account.id);
    return account.account_size > 0 ? (pnl / account.account_size) * 100 : 0;
  };

  // Calculate time-based stats
  const today = new Date();
  const startOfDay = new Date(today.setHours(0, 0, 0, 0));
  const startOfWeek = new Date(today.setDate(today.getDate() - today.getDay()));
  const startOfMonth = new Date(today.getFullYear(), today.getMonth(), 1);
  const startOfQuarter = new Date(today.getFullYear(), Math.floor(today.getMonth() / 3) * 3, 1);
  const startOfYear = new Date(today.getFullYear(), 0, 1);

  const getDailyPnL = () => trades.filter(t => new Date(t.exit_date) >= startOfDay).reduce((sum, t) => sum + t.pnl, 0);
  const getWeeklyPnL = () => trades.filter(t => new Date(t.exit_date) >= startOfWeek).reduce((sum, t) => sum + t.pnl, 0);
  const getMonthlyPnL = () => trades.filter(t => new Date(t.exit_date) >= startOfMonth).reduce((sum, t) => sum + t.pnl, 0);
  const getQuarterlyPnL = () => trades.filter(t => new Date(t.exit_date) >= startOfQuarter).reduce((sum, t) => sum + t.pnl, 0);
  const getYearlyPnL = () => trades.filter(t => new Date(t.exit_date) >= startOfYear).reduce((sum, t) => sum + t.pnl, 0);

  const totalAccountSize = accounts.reduce((sum, a) => sum + (a.account_size || 0), 0);
  
  const dailyPnLPct = totalAccountSize > 0 ? (getDailyPnL() / totalAccountSize) * 100 : 0;
  const weeklyPnLPct = totalAccountSize > 0 ? (getWeeklyPnL() / totalAccountSize) * 100 : 0;
  const monthlyPnLPct = totalAccountSize > 0 ? (getMonthlyPnL() / totalAccountSize) * 100 : 0;
  const quarterlyPnLPct = totalAccountSize > 0 ? (getQuarterlyPnL() / totalAccountSize) * 100 : 0;
  const yearlyPnLPct = totalAccountSize > 0 ? (getYearlyPnL() / totalAccountSize) * 100 : 0;

  const sections = [
    {
      title: 'Accounts',
      description: 'Manage trading accounts',
      icon: Wallet,
      color: 'from-green-500 to-emerald-600',
      link: 'Accounts'
    },
    {
      title: 'Analytics',
      description: 'Performance metrics & insights',
      icon: BarChart3,
      color: 'from-orange-500 to-red-600',
      link: 'Analytics'
    }
  ];

  return (
    <div className="min-h-screen bg-slate-950 p-6">
      <div className="max-w-5xl mx-auto">
        <Link to={createPageUrl('Dashboard')}>
          <Button variant="ghost" size="sm" className="text-slate-400 hover:text-white mb-4">
            <ChevronLeft className="w-4 h-4 mr-1" />
            Atrás
          </Button>
        </Link>

        <div className="flex items-center gap-3 mb-8">
          <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-green-500 to-emerald-600 flex items-center justify-center">
            <TrendingUp className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-white">Trades</h1>
            <p className="text-slate-400">Manage your trading operations</p>
          </div>
        </div>

        {/* Trades Stats Card */}
        <Card className="bg-slate-900/50 border-slate-800 mb-8">
          <CardContent className="pt-6">
            {/* All Accounts Grid */}
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4 mb-6">
              {accounts.length > 0 ? (
                accounts.map((account) => {
                  const pnlPct = getAccountPnLPct(account);
                  return (
                    <div key={account.id} className="text-center p-3 bg-slate-800/30 rounded-lg">
                      <p className="text-sm text-slate-400 mb-1">{account.name}</p>
                      <p className={`text-lg font-bold ${pnlPct >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                        {pnlPct >= 0 ? '+' : ''}{pnlPct.toFixed(2)}%
                      </p>
                    </div>
                  );
                })
              ) : (
                <div className="col-span-full text-center py-4">
                  <p className="text-slate-400">No hay cuentas activas</p>
                </div>
              )}
            </div>

            {/* Time-based Stats */}
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
              <div className="p-4 bg-slate-800/50 rounded-lg border border-slate-700">
                <div className="flex items-center justify-between mb-2">
                  <p className="text-sm text-slate-400">% Diario Total:</p>
                  <TrendingUp className="w-4 h-4 text-slate-400" />
                </div>
                <p className={`text-xl font-bold ${dailyPnLPct >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                  {dailyPnLPct >= 0 ? '+' : ''}{dailyPnLPct.toFixed(2)}%
                </p>
              </div>
              <div className="p-4 bg-slate-800/50 rounded-lg border border-slate-700">
                <div className="flex items-center justify-between mb-2">
                  <p className="text-sm text-slate-400">% Semanal:</p>
                  <TrendingUp className="w-4 h-4 text-slate-400" />
                </div>
                <p className={`text-xl font-bold ${weeklyPnLPct >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                  {weeklyPnLPct >= 0 ? '+' : ''}{weeklyPnLPct.toFixed(2)}%
                </p>
              </div>
              <div className="p-4 bg-slate-800/50 rounded-lg border border-slate-700">
                <div className="flex items-center justify-between mb-2">
                  <p className="text-sm text-slate-400">% Mensual:</p>
                  <TrendingUp className="w-4 h-4 text-slate-400" />
                </div>
                <p className={`text-xl font-bold ${monthlyPnLPct >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                  {monthlyPnLPct >= 0 ? '+' : ''}{monthlyPnLPct.toFixed(2)}%
                </p>
              </div>
              <div className="p-4 bg-slate-800/50 rounded-lg border border-slate-700">
                <div className="flex items-center justify-between mb-2">
                  <p className="text-sm text-slate-400">% Trimestral:</p>
                  <TrendingUp className="w-4 h-4 text-slate-400" />
                </div>
                <p className={`text-xl font-bold ${quarterlyPnLPct >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                  {quarterlyPnLPct >= 0 ? '+' : ''}{quarterlyPnLPct.toFixed(2)}%
                </p>
              </div>
              <div className="p-4 bg-slate-800/50 rounded-lg border border-slate-700">
                <div className="flex items-center justify-between mb-2">
                  <p className="text-sm text-slate-400">% Anual:</p>
                  <TrendingUp className="w-4 h-4 text-slate-400" />
                </div>
                <p className={`text-xl font-bold ${yearlyPnLPct >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                  {yearlyPnLPct >= 0 ? '+' : ''}{yearlyPnLPct.toFixed(2)}%
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {sections.map((section) => {
            const Icon = section.icon;
            return (
              <Link key={section.title} to={createPageUrl(section.link)}>
                <Card className="bg-slate-900 border-slate-800 hover:border-slate-700 transition-all duration-300 hover:scale-105 cursor-pointer group">
                  <CardHeader>
                    <div className={`w-12 h-12 rounded-lg bg-gradient-to-br ${section.color} flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
                      <Icon className="w-6 h-6 text-white" />
                    </div>
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-white">{section.title}</CardTitle>
                      <ArrowRight className="w-5 h-5 text-slate-400 group-hover:text-white group-hover:translate-x-1 transition-all" />
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-slate-400 text-sm">{section.description}</p>
                  </CardContent>
                </Card>
              </Link>
            );
          })}
        </div>
      </div>
    </div>
  );
}