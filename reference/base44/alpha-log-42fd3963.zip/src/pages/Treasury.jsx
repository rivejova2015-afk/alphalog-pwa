import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { DollarSign, TrendingUp, Shield, Calendar, PieChart, Target, AlertTriangle, Activity, ChevronLeft } from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

export default function Treasury() {
  const [selectedAccountId, setSelectedAccountId] = useState('ALL');
  const queryClient = useQueryClient();

  const { data: accounts = [] } = useQuery({
    queryKey: ['treasury-accounts'],
    queryFn: () => base44.entities.Account.filter({ is_deleted: false })
  });

  const { data: configs = [] } = useQuery({
    queryKey: ['treasury-configs'],
    queryFn: () => base44.entities.TreasuryConfig.list()
  });

  const { data: trades = [] } = useQuery({
    queryKey: ['treasury-trades'],
    queryFn: () => base44.entities.Trade.filter({ is_deleted: false, status: 'Closed' })
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.TreasuryConfig.update(id, data),
    onSuccess: () => queryClient.invalidateQueries(['treasury-configs'])
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.TreasuryConfig.create(data),
    onSuccess: () => queryClient.invalidateQueries(['treasury-configs'])
  });

  const handleUpdate = (accountId, field, value) => {
    const config = configs.find(c => c.account_id === accountId);
    if (config) {
      updateMutation.mutate({ id: config.id, data: { [field]: value } });
    } else {
      createMutation.mutate({ account_id: accountId, [field]: value });
    }
  };

  const getConfig = (accountId) => {
    return configs.find(c => c.account_id === accountId) || {};
  };

  const getSplitPercentage = (mode) => {
    const splits = { growth: 50, safe: 40, cash: 100 };
    return splits[mode] || 50;
  };

  const calculateRetirable = (account, config) => {
    const profit = account.current_balance - account.account_size;
    if (profit <= 0) return 0;
    const splitMode = config?.split_mode || 'growth';
    const percentage = getSplitPercentage(splitMode);
    return profit * (percentage / 100);
  };

  const calculateDrawdown = (accountId) => {
    const accountTrades = trades.filter(t => t.account_id === accountId);
    const account = accounts.find(a => a.id === accountId);
    if (!account || accountTrades.length === 0) return 0;

    let peak = account.account_size;
    let maxDrawdown = 0;
    let runningBalance = account.account_size;

    accountTrades.sort((a, b) => new Date(a.exit_date) - new Date(b.exit_date)).forEach(trade => {
      runningBalance += trade.pnl;
      if (runningBalance > peak) peak = runningBalance;
      const drawdown = ((peak - runningBalance) / peak) * 100;
      if (drawdown > maxDrawdown) maxDrawdown = drawdown;
    });

    return maxDrawdown;
  };

  const calculateHealthScore = (account, config) => {
    let score = 100;
    
    // Check if in evaluation phase
    if (account.phase_status && account.phase_status.includes('fase')) {
      score -= 50;
    }

    // Check withdrawals enabled
    if (!account.withdrawals_enabled) {
      score = 0;
    }

    // Check drawdown
    const drawdown = calculateDrawdown(account.id);
    const threshold = config?.anti_drawdown_threshold || 20;
    if (drawdown >= threshold) {
      score -= 50;
    }

    // Check balance threshold
    if (config?.balance_threshold && account.current_balance < config.balance_threshold) {
      score -= 30;
    }

    return Math.max(0, score);
  };

  const filteredAccounts = selectedAccountId === 'ALL' ? accounts : accounts.filter(a => a.id === selectedAccountId);

  const totalRetirable = filteredAccounts.reduce((sum, acc) => {
    const config = getConfig(acc.id);
    return sum + calculateRetirable(acc, config);
  }, 0);

  const totalTaxBuffer = configs.reduce((sum, c) => sum + (c.tax_buffer_accumulated || 0), 0);
  const totalBonusVault = configs.reduce((sum, c) => sum + (c.milestone_bonus_vault || 0), 0);

  const daysUntilNextWithdrawal = () => {
    const today = new Date();
    const targetDay = configs[0]?.withdrawal_day || 1;
    const nextDate = new Date(today.getFullYear(), today.getMonth(), targetDay);
    if (nextDate < today) {
      nextDate.setMonth(nextDate.getMonth() + 1);
    }
    const diff = Math.ceil((nextDate - today) / (1000 * 60 * 60 * 24));
    return diff;
  };

  return (
    <div className="min-h-screen bg-slate-950 p-6">
      <div className="max-w-7xl mx-auto">
        <Link to={createPageUrl('TreasuryMenu')}>
          <Button variant="ghost" size="sm" className="text-slate-400 hover:text-white mb-4">
            <ChevronLeft className="w-4 h-4 mr-1" />
            Atrás
          </Button>
        </Link>

        <div className="mb-6">
          <h1 className="text-3xl font-bold text-white mb-2">Tesorería</h1>
          <p className="text-slate-400">Control de retiros, distribución y protecciones por cuenta</p>
        </div>

        <div className="mb-6">
          <Select value={selectedAccountId} onValueChange={setSelectedAccountId}>
            <SelectTrigger className="bg-slate-900 border-slate-800 text-white max-w-md">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="ALL">Todas las cuentas</SelectItem>
              {accounts.map(acc => (
                <SelectItem key={acc.id} value={acc.id}>{acc.name}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="bg-slate-900 border-slate-800">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="milestone">Milestone</TabsTrigger>
            <TabsTrigger value="cashflow">Cashflow</TabsTrigger>
            <TabsTrigger value="calendario">Calendario</TabsTrigger>
            <TabsTrigger value="splits">Splits</TabsTrigger>
            <TabsTrigger value="umbral">Umbral</TabsTrigger>
            <TabsTrigger value="anti-dd">Anti-DD</TabsTrigger>
            <TabsTrigger value="heatmap">Heatmap</TabsTrigger>
          </TabsList>

          {/* OVERVIEW TAB */}
          <TabsContent value="overview" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <Card className="bg-slate-900 border-slate-800">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm text-slate-400 flex items-center gap-2">
                    <DollarSign className="w-4 h-4" />
                    Retirable Total
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-2xl font-bold text-white">${totalRetirable.toLocaleString()}</p>
                  <p className="text-xs text-slate-400 mt-1">{selectedAccountId === 'ALL' ? 'Todas las cuentas' : filteredAccounts[0]?.name}</p>
                </CardContent>
              </Card>

              <Card className="bg-slate-900 border-slate-800">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm text-slate-400 flex items-center gap-2">
                    <Shield className="w-4 h-4" />
                    Tax Buffer
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-2xl font-bold text-white">${totalTaxBuffer.toLocaleString()}</p>
                  <p className="text-xs text-slate-400 mt-1">Acumulado</p>
                </CardContent>
              </Card>

              <Card className="bg-slate-900 border-slate-800">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm text-slate-400 flex items-center gap-2">
                    <Target className="w-4 h-4" />
                    Bonus Vault
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-2xl font-bold text-white">${totalBonusVault.toLocaleString()}</p>
                  <p className="text-xs text-slate-400 mt-1">Axi anual</p>
                </CardContent>
              </Card>

              <Card className="bg-slate-900 border-slate-800">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm text-slate-400 flex items-center gap-2">
                    <Calendar className="w-4 h-4" />
                    Próximo Retiro
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-2xl font-bold text-white">{daysUntilNextWithdrawal()}</p>
                  <p className="text-xs text-slate-400 mt-1">días</p>
                </CardContent>
              </Card>
            </div>

            {/* Tax Buffer Pocket */}
            <Card className="bg-slate-900 border-slate-800">
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Shield className="w-5 h-5 text-blue-400" />
                  <CardTitle className="text-white">Tax Buffer Pocket</CardTitle>
                </div>
                <p className="text-sm text-slate-400 mt-1">Reserva automática para impuestos sobre cada retiro</p>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="p-4 bg-slate-800/50 rounded-lg">
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-sm text-slate-400">Retirable: $0</span>
                    </div>
                    <div className="grid grid-cols-3 gap-4">
                      <div>
                        <label className="text-xs text-slate-400">% Impuesto</label>
                        <Input
                          type="number"
                          placeholder="30"
                          className="bg-slate-800 border-slate-700 text-white mt-1"
                        />
                      </div>
                      <div>
                        <label className="text-xs text-slate-400">Acumulado ($)</label>
                        <Input
                          type="number"
                          placeholder="0"
                          className="bg-slate-800 border-slate-700 text-white mt-1"
                        />
                      </div>
                      <div>
                        <label className="text-xs text-slate-400">Target Anual ($)</label>
                        <Input
                          type="number"
                          placeholder="0"
                          className="bg-slate-800 border-slate-700 text-white mt-1"
                        />
                      </div>
                    </div>
                    <p className="text-xs text-slate-400 mt-2">Reserva: $0</p>
                  </div>

                  {filteredAccounts.map(account => {
                    const config = getConfig(account.id);
                    const retirable = calculateRetirable(account, config);
                    const taxPercentage = config?.tax_buffer_percentage || 30;
                    const reserve = retirable * (taxPercentage / 100);

                    return (
                      <div key={account.id} className="p-4 bg-slate-800/50 rounded-lg">
                        <div className="flex justify-between items-center mb-2">
                          <span className="text-white font-medium">{account.name}</span>
                          <Badge variant={retirable > 0 ? 'default' : 'outline'} className="text-xs">
                            {retirable > 0 ? 'Crítico' : 'OK'}
                          </Badge>
                        </div>
                        <div className="flex justify-between items-center mb-2">
                          <span className="text-sm text-slate-400">Retirable: ${retirable.toLocaleString()}</span>
                        </div>
                        <div className="grid grid-cols-3 gap-4">
                          <div>
                            <label className="text-xs text-slate-400">% Impuesto</label>
                            <Input
                              type="number"
                              value={taxPercentage}
                              onChange={(e) => handleUpdate(account.id, 'tax_buffer_percentage', parseFloat(e.target.value))}
                              className="bg-slate-800 border-slate-700 text-white mt-1"
                            />
                          </div>
                          <div>
                            <label className="text-xs text-slate-400">Acumulado ($)</label>
                            <Input
                              type="number"
                              value={config?.tax_buffer_accumulated || 0}
                              onChange={(e) => handleUpdate(account.id, 'tax_buffer_accumulated', parseFloat(e.target.value))}
                              className="bg-slate-800 border-slate-700 text-white mt-1"
                            />
                          </div>
                          <div>
                            <label className="text-xs text-slate-400">Target Anual ($)</label>
                            <Input
                              type="number"
                              value={config?.tax_buffer_target || 0}
                              onChange={(e) => handleUpdate(account.id, 'tax_buffer_target', parseFloat(e.target.value))}
                              className="bg-slate-800 border-slate-700 text-white mt-1"
                            />
                          </div>
                        </div>
                        <p className="text-xs text-slate-400 mt-2">Reserva: ${reserve.toFixed(2)}</p>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* MILESTONE TAB */}
          <TabsContent value="milestone" className="space-y-6">
            <Card className="bg-slate-900 border-slate-800">
              <CardHeader>
                <div className="flex items-center gap-2 mb-2">
                  <Target className="w-5 h-5 text-amber-400" />
                  <CardTitle className="text-white">Milestone Bonus (Solo Axi &gt;50k)</CardTitle>
                </div>
                <p className="text-sm text-slate-400">
                  Cuando alcanzas $50k+: 50% retiro → FDGA, 50% → Bonus Vault (pago anual)
                </p>
              </CardHeader>
            </Card>

            <div className="space-y-4">
              {filteredAccounts.map(account => {
                const config = getConfig(account.id);
                const targetMilestone = config?.milestone_target || 50000;
                const progress = (account.current_balance / targetMilestone) * 100;
                const remaining = Math.max(0, targetMilestone - account.current_balance);
                const isBlocked = account.phase_status && !account.phase_status.toLowerCase().includes('funded');

                return (
                  <Card key={account.id} className="bg-slate-900 border-slate-800">
                    <CardHeader>
                      <div className="flex items-center justify-between">
                        <CardTitle className="text-white">{account.name}</CardTitle>
                        <Badge variant={isBlocked ? 'outline' : 'default'}>
                          {isBlocked ? 'Bloqueado' : 'Activo'}
                        </Badge>
                      </div>
                      <p className="text-sm text-slate-400">Balance: ${account.current_balance.toLocaleString()}</p>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        <div>
                          <div className="flex justify-between text-sm mb-2">
                            <span className="text-slate-400">Progreso a $50k</span>
                            <span className="text-white font-medium">{progress.toFixed(1)}%</span>
                          </div>
                          <Progress value={Math.min(100, progress)} className="h-2" />
                          <p className="text-xs text-slate-400 mt-2">Faltan: ${remaining.toLocaleString()}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </TabsContent>

          {/* CASHFLOW TAB */}
          <TabsContent value="cashflow" className="space-y-6">
            <Card className="bg-slate-900 border-slate-800">
              <CardHeader>
                <div className="flex items-center gap-2">
                  <TrendingUp className="w-5 h-5 text-green-400" />
                  <CardTitle className="text-white">Cashflow Map - Distribución de Retiros</CardTitle>
                </div>
                <p className="text-sm text-slate-400 mt-1">Configura cómo se distribuye el monto retirable de cada cuenta</p>
              </CardHeader>
            </Card>

            <div className="space-y-4">
              {filteredAccounts.map(account => {
                const config = getConfig(account.id);
                const retirable = calculateRetirable(account, config);

                return (
                  <Card key={account.id} className="bg-slate-900 border-slate-800">
                    <CardHeader>
                      <div className="flex items-center justify-between">
                        <div>
                          <CardTitle className="text-white">{account.name}</CardTitle>
                          <p className="text-sm text-slate-400 mt-1">
                            {account.phase_status || 'Funded'}
                          </p>
                        </div>
                        <Badge variant={account.withdrawals_enabled ? 'default' : 'destructive'}>
                          {account.withdrawals_enabled ? 'Retiros ON' : 'NO RETIRAR'}
                        </Badge>
                      </div>
                      <p className="text-sm text-slate-400">
                        {account.phase_status && account.phase_status.includes('fase') 
                          ? `Fase evaluación - $0 retirable`
                          : `Retirable: $${retirable.toFixed(0)}`}
                      </p>
                    </CardHeader>
                  </Card>
                );
              })}
            </div>
          </TabsContent>

          {/* CALENDARIO TAB */}
          <TabsContent value="calendario" className="space-y-6">
            <Card className="bg-slate-900 border-slate-800">
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Calendar className="w-5 h-5 text-blue-400" />
                  <CardTitle className="text-white">Calendario de Retiros</CardTitle>
                </div>
                <p className="text-sm text-slate-400 mt-1">Configura el día de retiro para cada cuenta y límite de cuentas por día</p>
              </CardHeader>
              <CardContent>
                <div className="mb-4">
                  <label className="text-sm text-slate-400 mb-2 block">Máximo de cuentas por día</label>
                  <Input
                    type="number"
                    defaultValue={3}
                    className="bg-slate-800 border-slate-700 text-white max-w-xs"
                  />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-slate-900 border-slate-800">
              <CardContent className="pt-6">
                <div className="flex items-center gap-2 p-3 bg-amber-500/10 border border-amber-500/30 rounded-lg mb-4">
                  <AlertTriangle className="w-4 h-4 text-amber-400" />
                  <div>
                    <p className="text-sm font-medium text-amber-400">Día saturado (21 cuentas)</p>
                  </div>
                  <div className="ml-auto">
                    <span className="text-white font-medium">Día de retiro: 1</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <div className="space-y-3">
              {filteredAccounts.map(account => {
                const config = getConfig(account.id);
                const withdrawalDay = config?.withdrawal_day || 1;

                return (
                  <Card key={account.id} className="bg-slate-900 border-slate-800">
                    <CardContent className="pt-6">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-white font-medium">{account.name}</p>
                          <div className="flex items-center gap-2 mt-1">
                            <AlertTriangle className="w-3 h-3 text-amber-400" />
                            <p className="text-xs text-amber-400">Día saturado (21 cuentas)</p>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="text-sm text-slate-400">Día de retiro:</p>
                          <Input
                            type="number"
                            min="1"
                            max="31"
                            value={withdrawalDay}
                            onChange={(e) => handleUpdate(account.id, 'withdrawal_day', parseInt(e.target.value))}
                            className="bg-slate-800 border-slate-700 text-white w-20 mt-1"
                          />
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </TabsContent>

          {/* SPLITS TAB */}
          <TabsContent value="splits" className="space-y-6">
            <Card className="bg-slate-900 border-slate-800">
              <CardHeader>
                <div className="flex items-center gap-2">
                  <PieChart className="w-5 h-5 text-purple-400" />
                  <CardTitle className="text-white">Perfiles de Split - % Retirable</CardTitle>
                </div>
                <p className="text-sm text-slate-400 mt-1">Define el porcentaje de ganancia que se puede retirar de cada cuenta</p>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                  <div className="p-4 bg-blue-500/10 border-2 border-blue-500 rounded-lg">
                    <p className="text-lg font-bold text-white">Growth Mode</p>
                    <p className="text-3xl font-bold text-blue-400 my-2">50%</p>
                    <p className="text-xs text-slate-400">Balance crecimiento/retiro</p>
                  </div>
                  <div className="p-4 bg-green-500/10 border-2 border-green-500 rounded-lg">
                    <p className="text-lg font-bold text-white">Safe Mode</p>
                    <p className="text-3xl font-bold text-green-400 my-2">40%</p>
                    <p className="text-xs text-slate-400">Conservador, más compounding</p>
                  </div>
                  <div className="p-4 bg-amber-500/10 border-2 border-amber-500 rounded-lg">
                    <p className="text-lg font-bold text-white">Cash Mode</p>
                    <p className="text-3xl font-bold text-amber-400 my-2">100%</p>
                    <p className="text-xs text-slate-400">Retiro total de ganancias</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Select value={selectedAccountId === 'ALL' ? 'ALL' : selectedAccountId} onValueChange={setSelectedAccountId}>
              <SelectTrigger className="bg-slate-900 border-slate-800 text-white">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="ALL">Todas las cuentas</SelectItem>
                {accounts.map(acc => (
                  <SelectItem key={acc.id} value={acc.id}>{acc.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>

            <div className="space-y-3">
              {filteredAccounts.map(account => {
                const config = getConfig(account.id);
                const splitMode = config?.split_mode || 'growth';
                const retirable = calculateRetirable(account, config);

                return (
                  <Card key={account.id} className="bg-slate-900 border-slate-800">
                    <CardContent className="pt-6">
                      <div className="flex items-center justify-between mb-4">
                        <div>
                          <p className="text-white font-medium">{account.name}</p>
                          <Badge className={`mt-1 ${
                            splitMode === 'growth' ? 'bg-blue-600' :
                            splitMode === 'safe' ? 'bg-green-600' :
                            'bg-amber-600'
                          }`}>
                            {splitMode === 'growth' ? 'Growth Mode' :
                             splitMode === 'safe' ? 'Safe Mode' :
                             'Cash Mode'}
                          </Badge>
                          <p className="text-sm text-slate-400 mt-2">
                            {getSplitPercentage(splitMode)}% retirable
                          </p>
                        </div>
                        <div className="text-right">
                          <p className="text-sm text-slate-400">Preset</p>
                          <Select
                            value={splitMode}
                            onValueChange={(value) => handleUpdate(account.id, 'split_mode', value)}
                          >
                            <SelectTrigger className="bg-slate-800 border-slate-700 text-white w-40 mt-1">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="growth">Growth (50%)</SelectItem>
                              <SelectItem value="safe">Safe (40%)</SelectItem>
                              <SelectItem value="cash">Cash (100%)</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </TabsContent>

          {/* UMBRAL TAB */}
          <TabsContent value="umbral" className="space-y-6">
            <Card className="bg-slate-900 border-slate-800">
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Shield className="w-5 h-5 text-cyan-400" />
                  <CardTitle className="text-white">Umbral de Balance</CardTitle>
                </div>
                <p className="text-sm text-slate-400 mt-1">Define el balance mínimo para permitir retiros personales</p>
              </CardHeader>
            </Card>

            <div className="space-y-4">
              {filteredAccounts.map(account => {
                const config = getConfig(account.id);
                const threshold = config?.balance_threshold || 0;
                const canWithdraw = account.current_balance >= threshold && account.withdrawals_enabled;
                const isEvaluationPhase = account.phase_status && account.phase_status.includes('fase');

                return (
                  <Card key={account.id} className={`border-2 ${
                    isEvaluationPhase ? 'bg-red-900/20 border-red-500/30' :
                    canWithdraw ? 'bg-green-900/20 border-green-500/30' :
                    'bg-slate-900 border-slate-800'
                  }`}>
                    <CardContent className="pt-6">
                      <div className="flex items-center justify-between mb-4">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            <p className="text-white font-medium">{account.name}</p>
                            {account.phase_status && (
                              <Badge variant="outline">{account.phase_status}</Badge>
                            )}
                          </div>
                          <p className="text-sm text-slate-400">Balance actual: ${account.current_balance.toLocaleString()}</p>
                          {isEvaluationPhase ? (
                            <div className="flex items-center gap-2 mt-2 p-2 bg-red-500/10 border border-red-500/30 rounded">
                              <AlertTriangle className="w-4 h-4 text-red-400" />
                              <p className="text-xs text-red-400">Evaluation phase (no withdrawals)</p>
                            </div>
                          ) : canWithdraw ? (
                            <Badge className="bg-green-600 mt-2">Retiros ON</Badge>
                          ) : (
                            <Badge variant="outline" className="mt-2 text-slate-400">Fase evaluación</Badge>
                          )}
                        </div>
                        <div className="text-right">
                          <label className="text-sm text-slate-400 block mb-2">Umbral mínimo ($)</label>
                          <Input
                            type="number"
                            value={threshold}
                            onChange={(e) => handleUpdate(account.id, 'balance_threshold', parseFloat(e.target.value))}
                            className="bg-slate-800 border-slate-700 text-white w-32"
                          />
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </TabsContent>

          {/* ANTI-DD TAB */}
          <TabsContent value="anti-dd" className="space-y-6">
            <Card className="bg-slate-900 border-slate-800">
              <CardHeader>
                <div className="flex items-center gap-2">
                  <AlertTriangle className="w-5 h-5 text-amber-400" />
                  <CardTitle className="text-white">Regla Anti-Drawdown</CardTitle>
                </div>
                <p className="text-sm text-slate-400 mt-1">
                  Protección automática que reduce retiros personales cuando el trimestre entra en riesgo
                </p>
              </CardHeader>
            </Card>

            <Card className="bg-slate-900 border-slate-800">
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-white font-medium">Drawdown actual: 0.0%</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-slate-400 text-sm">Activa</span>
                    <Switch defaultChecked={false} />
                  </div>
                </div>
                <div className="mt-4">
                  <label className="text-sm text-slate-400 mb-2 block">Umbral de activación (%)</label>
                  <Input
                    type="number"
                    defaultValue={20}
                    className="bg-slate-800 border-slate-700 text-white"
                  />
                </div>
              </CardContent>
            </Card>

            <div className="space-y-3">
              {filteredAccounts.map(account => {
                const config = getConfig(account.id);
                const drawdown = calculateDrawdown(account.id);
                const threshold = config?.anti_drawdown_threshold || 20;
                const isActive = config?.anti_drawdown_active || false;

                return (
                  <Card key={account.id} className="bg-slate-900 border-slate-800">
                    <CardContent className="pt-6">
                      <div className="flex items-center justify-between mb-3">
                        <div>
                          <p className="text-white font-medium">{account.name}</p>
                          <p className="text-sm text-slate-400">Drawdown actual: {drawdown.toFixed(1)}%</p>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="text-slate-400 text-sm">Activa</span>
                          <Switch
                            checked={isActive}
                            onCheckedChange={(checked) => handleUpdate(account.id, 'anti_drawdown_active', checked)}
                          />
                        </div>
                      </div>
                      <div>
                        <label className="text-sm text-slate-400 mb-2 block">Umbral de activación (%)</label>
                        <Input
                          type="number"
                          value={threshold}
                          onChange={(e) => handleUpdate(account.id, 'anti_drawdown_threshold', parseFloat(e.target.value))}
                          className="bg-slate-800 border-slate-700 text-white"
                        />
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </TabsContent>

          {/* HEATMAP TAB */}
          <TabsContent value="heatmap" className="space-y-6">
            <Card className="bg-slate-900 border-slate-800">
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Activity className="w-5 h-5 text-green-400" />
                  <CardTitle className="text-white">Account Heatmap de Retiro</CardTitle>
                </div>
                <p className="text-sm text-slate-400 mt-1">Score de seguridad (0-100) para retirar de cada cuenta hoy</p>
              </CardHeader>
            </Card>

            <div className="space-y-4">
              {filteredAccounts.map((account, index) => {
                const config = getConfig(account.id);
                const healthScore = calculateHealthScore(account, config);
                const isEligible = healthScore === 100;

                return (
                  <Card key={account.id} className="bg-slate-900 border-slate-800">
                    <CardContent className="pt-6">
                      <div className="flex items-center gap-4">
                        <div className="flex items-center justify-center w-12 h-12 rounded-full bg-slate-800 text-slate-400">
                          #{index + 1}
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            <p className="text-white font-medium">{account.name}</p>
                            {account.phase_status && (
                              <Badge variant="outline">{account.phase_status}</Badge>
                            )}
                          </div>
                          <p className="text-sm text-slate-400">
                            {healthScore === 100 ? 'Excelente - Sin restricciones' :
                             healthScore >= 50 ? 'Bueno - Algunas restricciones' :
                             'Crítico - No retirar'}
                          </p>
                        </div>
                        <div className="text-right">
                          <p className="text-3xl font-bold text-white">
                            {healthScore}
                            <span className="text-lg text-slate-400">/ 100</span>
                          </p>
                        </div>
                      </div>
                      <div className="mt-4">
                        <Progress value={healthScore} className="h-2" />
                      </div>
                      {isEligible && (
                        <Badge className="bg-green-600 mt-3">Elegible hoy</Badge>
                      )}
                      {account.phase_status && account.phase_status.includes('fase') && (
                        <div className="mt-3 p-3 bg-blue-500/10 border border-blue-500/30 rounded-lg">
                          <p className="text-xs text-blue-300">
                            <span className="font-medium">Impacto en Meta:</span>
                            <br />
                            Si retiras hoy, tu progreso de AXI V1 podría verse afectado
                          </p>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}