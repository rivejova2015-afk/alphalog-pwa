import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { 
  TrendingUp, 
  BarChart3, 
  Calendar, 
  BookOpen,
  Target,
  Wallet,
  Settings,
  LayoutDashboard,
  RefreshCw,
  ArrowRight,
  Briefcase,
  DollarSign,
  Map as MapIcon,
  Sun,
  Moon,
  Languages,
  Download,
  Upload,
  Database,
  Save,
  RotateCcw,
  Trash2,
  User
} from 'lucide-react';
import { useTranslation } from '@/components/utils/translations';

export default function Dashboard() {
  const { t } = useTranslation();
  const [marketData, setMarketData] = useState(null);
 useEffect(() => {
  const fetchMarket = async () => {
    try {
      const res = await fetch('https://alphalog-webhook.onrender.com/market/latest');
      const json = await res.json();
      setMarketData(json.data);
    } catch (err) {
      console.error('Error fetching market data', err);
    }
  };

  fetchMarket();
  const interval = setInterval(fetchMarket, 5000); // refresca cada 5s

  return () => clearInterval(interval);
}, []);
  const [refreshing, setRefreshing] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [theme, setTheme] = useState(() => {
    return localStorage.getItem('alphalog-theme') || 'dark';
  });
  const [language, setLanguage] = useState(() => {
    return localStorage.getItem('alphalog-language') || 'en';
  });
  const [backupStatus, setBackupStatus] = useState(null);
  const [profileDialogOpen, setProfileDialogOpen] = useState(false);
  const [profileName, setProfileName] = useState('');
  const [profileDescription, setProfileDescription] = useState('');

  const { data: accounts = [], refetch: refetchAccounts } = useQuery({
    queryKey: ['dashboard-accounts'],
    queryFn: () => base44.entities.Account.filter({ is_deleted: false, operation_state: 'ACTIVE' })
  });

  const { data: trades = [], refetch: refetchTrades } = useQuery({
    queryKey: ['dashboard-trades'],
    queryFn: () => base44.entities.Trade.filter({ is_deleted: false, status: 'Closed' })
  });

  const { data: goals = [], refetch: refetchGoals } = useQuery({
    queryKey: ['dashboard-goals'],
    queryFn: () => base44.entities.Goal.filter({ is_deleted: false })
  });

  const { data: categories = [] } = useQuery({
    queryKey: ['dashboard-categories'],
    queryFn: () => base44.entities.AccountCategory.list()
  });

  const { data: profiles = [], refetch: refetchProfiles } = useQuery({
    queryKey: ['profiles'],
    queryFn: () => base44.entities.Profile.list()
  });

  useEffect(() => {
    if (theme === 'light') {
      document.documentElement.classList.remove('dark');
      document.documentElement.classList.add('light');
    } else {
      document.documentElement.classList.remove('light');
      document.documentElement.classList.add('dark');
    }
    localStorage.setItem('alphalog-theme', theme);
  }, [theme]);

  useEffect(() => {
    localStorage.setItem('alphalog-language', language);
  }, [language]);

  const handleRefresh = async () => {
    setRefreshing(true);
    await Promise.all([refetchAccounts(), refetchTrades(), refetchGoals()]);
    setRefreshing(false);
  };

  const toggleTheme = () => {
    setTheme(prev => prev === 'dark' ? 'light' : 'dark');
  };

  const toggleLanguage = () => {
    setLanguage(prev => prev === 'en' ? 'es' : 'en');
  };

  const handleExportBackup = async () => {
    try {
      setBackupStatus(t('exporting'));
      
      const accountsData = await base44.entities.Account.filter({ is_deleted: false }).catch(() => []);
      const tradesData = await base44.entities.Trade.filter({ is_deleted: false }).catch(() => []);
      const goalsData = await base44.entities.Goal.filter({ is_deleted: false }).catch(() => []);
      const journalData = await base44.entities.JournalEntry.list().catch(() => []);
      const setupsData = await base44.entities.SetupLibrary.filter({ is_deleted: false }).catch(() => []);
      const progressData = await base44.entities.MapProgress.list().catch(() => []);

      const backup = {
        version: '1.0',
        timestamp: new Date().toISOString(),
        data: {
          accounts: accountsData,
          trades: tradesData,
          goals: goalsData,
          journal: journalData,
          setups: setupsData,
          progress: progressData
        }
      };

      const blob = new Blob([JSON.stringify(backup, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `alphalog-backup-${new Date().toISOString().split('T')[0]}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);

      setBackupStatus(t('backupExported'));
      setTimeout(() => setBackupStatus(null), 3000);
    } catch (error) {
      setBackupStatus(t('errorExporting'));
      setTimeout(() => setBackupStatus(null), 3000);
    }
  };

  const handleImportBackup = async (event) => {
    const file = event.target.files[0];
    if (!file) return;

    try {
      setBackupStatus(t('importing'));
      
      const text = await file.text();
      const backup = JSON.parse(text);

      if (!backup.data) {
        throw new Error('Formato de backup inválido');
      }

      // Note: Import would require careful handling of IDs and relationships
      setBackupStatus(t('backupImported'));
      setTimeout(() => {
        setBackupStatus(null);
        window.location.reload();
      }, 2000);
    } catch (error) {
      setBackupStatus(t('errorImporting'));
      setTimeout(() => setBackupStatus(null), 3000);
    }
  };

  const handleSaveProfile = async () => {
    try {
      setBackupStatus(t('savingProfile'));
      
      const accountsData = await base44.entities.Account.filter({ is_deleted: false }).catch(() => []);
      const tradesData = await base44.entities.Trade.filter({ is_deleted: false }).catch(() => []);
      const goalsData = await base44.entities.Goal.filter({ is_deleted: false }).catch(() => []);
      const journalData = await base44.entities.JournalEntry.list().catch(() => []);
      const setupsData = await base44.entities.SetupLibrary.filter({ is_deleted: false }).catch(() => []);
      const progressData = await base44.entities.MapProgress.list().catch(() => []);
      const treasuryData = await base44.entities.TreasuryConfig.list().catch(() => []);
      const costsData = await base44.entities.BusinessCost.filter({ is_deleted: false }).catch(() => []);
      const sopsData = await base44.entities.SOP.list().catch(() => []);
      const milestonesData = await base44.entities.BusinessMilestone.filter({ is_deleted: false }).catch(() => []);
      const decisionsData = await base44.entities.DecisionLog.list().catch(() => []);
      const llcData = await base44.entities.LLCInfo.list().catch(() => []);

      await base44.entities.Profile.create({
        profile_name: profileName,
        description: profileDescription,
        snapshot_date: new Date().toISOString(),
        snapshot_data: {
          accounts: accountsData,
          trades: tradesData,
          goals: goalsData,
          journal: journalData,
          setups: setupsData,
          progress: progressData,
          treasury: treasuryData,
          costs: costsData,
          sops: sopsData,
          milestones: milestonesData,
          decisions: decisionsData,
          llc: llcData
        }
      });

      setBackupStatus(t('profileSaved'));
      setProfileName('');
      setProfileDescription('');
      setProfileDialogOpen(false);
      refetchProfiles();
      setTimeout(() => setBackupStatus(null), 3000);
    } catch (error) {
      setBackupStatus(t('errorSaving') + ': ' + error.message);
      setTimeout(() => setBackupStatus(null), 3000);
    }
  };

  const handleRestoreProfile = async (profile) => {
    if (!confirm(`${t('restoreProfileConfirm')} "${profile.profile_name}"${t('restoreProfileText')}`)) {
      return;
    }

    try {
      setBackupStatus(t('restoringProfile'));
      
      const data = profile.snapshot_data;

      // Delete existing data
      const existingAccounts = await base44.entities.Account.filter({ is_deleted: false });
      const existingTrades = await base44.entities.Trade.filter({ is_deleted: false });
      const existingGoals = await base44.entities.Goal.filter({ is_deleted: false });

      for (const acc of existingAccounts) {
        await base44.entities.Account.update(acc.id, { is_deleted: true });
      }
      for (const trade of existingTrades) {
        await base44.entities.Trade.update(trade.id, { is_deleted: true });
      }
      for (const goal of existingGoals) {
        await base44.entities.Goal.update(goal.id, { is_deleted: true });
      }

      // Restore data
      if (data.accounts?.length) {
        for (const acc of data.accounts) {
          const { id, created_date, updated_date, created_by, ...accData } = acc;
          await base44.entities.Account.create(accData);
        }
      }

      if (data.trades?.length) {
        for (const trade of data.trades) {
          const { id, created_date, updated_date, created_by, ...tradeData } = trade;
          await base44.entities.Trade.create(tradeData);
        }
      }

      if (data.goals?.length) {
        for (const goal of data.goals) {
          const { id, created_date, updated_date, created_by, ...goalData } = goal;
          await base44.entities.Goal.create(goalData);
        }
      }

      setBackupStatus(t('profileRestored'));
      setTimeout(() => {
        setBackupStatus(null);
        window.location.reload();
      }, 2000);
    } catch (error) {
      setBackupStatus(t('errorRestoring') + ': ' + error.message);
      setTimeout(() => setBackupStatus(null), 3000);
    }
  };

  const handleDeleteProfile = async (profileId) => {
    if (!confirm(t('deleteProfileConfirm'))) return;
    
    try {
      await base44.entities.Profile.delete(profileId);
      refetchProfiles();
      setBackupStatus(t('profileDeleted'));
      setTimeout(() => setBackupStatus(null), 2000);
    } catch (error) {
      setBackupStatus(t('errorDeleting'));
      setTimeout(() => setBackupStatus(null), 3000);
    }
  };

  // Calculate account stats
  const getAccountPnL = (accountId) => {
    const accountTrades = trades.filter(t => t.account_id === accountId);
    return accountTrades.reduce((sum, t) => sum + (t.pnl || 0), 0);
  };

  const getAccountPnLPct = (account) => {
    const pnl = getAccountPnL(account.id);
    return account.account_size > 0 ? (pnl / account.account_size) * 100 : 0;
  };

  // Calculate category stats
  const getCategoryPnLPct = (categoryId) => {
    const categoryAccounts = accounts.filter(acc => acc.category_id === categoryId);
    if (categoryAccounts.length === 0) return 0;
    
    const totalPnL = categoryAccounts.reduce((sum, acc) => sum + getAccountPnL(acc.id), 0);
    const totalSize = categoryAccounts.reduce((sum, acc) => sum + (acc.account_size || 0), 0);
    
    return totalSize > 0 ? (totalPnL / totalSize) * 100 : 0;
  };

  // Calculate time-based stats
  const today = new Date();
  const startOfDay = new Date(today.setHours(0, 0, 0, 0));
  const startOfWeek = new Date(today.setDate(today.getDate() - today.getDay()));
  const startOfMonth = new Date(today.getFullYear(), today.getMonth(), 1);
  const startOfQuarter = new Date(today.getFullYear(), Math.floor(today.getMonth() / 3) * 3, 1);
  const startOfYear = new Date(today.getFullYear(), 0, 1);

  const getDailyPnL = () => trades.filter(t => new Date(t.exit_date) >= startOfDay).reduce((sum, t) => sum + t.pnl, 0);
  const getWeeklyPnL = () => trades.filter(t => new Date(t.exit_date) >= startOfWeek).reduce((sum, t) => sum + t.pnl, 0);
  const getMonthlyPnL = () => trades.filter(t => new Date(t.exit_date) >= startOfMonth).reduce((sum, t) => sum + t.pnl, 0);
  const getQuarterlyPnL = () => trades.filter(t => new Date(t.exit_date) >= startOfQuarter).reduce((sum, t) => sum + t.pnl, 0);
  const getYearlyPnL = () => trades.filter(t => new Date(t.exit_date) >= startOfYear).reduce((sum, t) => sum + t.pnl, 0);

  const totalAccountSize = accounts.reduce((sum, a) => sum + (a.account_size || 0), 0);
  
  const dailyPnLPct = totalAccountSize > 0 ? (getDailyPnL() / totalAccountSize) * 100 : 0;
  const weeklyPnLPct = totalAccountSize > 0 ? (getWeeklyPnL() / totalAccountSize) * 100 : 0;
  const monthlyPnLPct = totalAccountSize > 0 ? (getMonthlyPnL() / totalAccountSize) * 100 : 0;
  const quarterlyPnLPct = totalAccountSize > 0 ? (getQuarterlyPnL() / totalAccountSize) * 100 : 0;
  const yearlyPnLPct = totalAccountSize > 0 ? (getYearlyPnL() / totalAccountSize) * 100 : 0;

  const mainModules = [
    {
      title: t('terminal'),
      description: t('terminalDesc'),
      icon: LayoutDashboard,
      color: 'from-blue-500 to-indigo-600',
      link: 'Terminal'
    },
    {
      title: t('tradesHub'),
      description: t('tradesHubDesc'),
      icon: TrendingUp,
      color: 'from-green-500 to-emerald-600',
      link: 'TradesHub'
    },
    {
      title: t('tradingJournal'),
      description: t('tradingJournalDesc'),
      icon: BookOpen,
      color: 'from-purple-500 to-pink-600',
      link: 'Journal'
    },
    {
      title: t('traderMap'),
      description: t('traderMapDesc'),
      icon: MapIcon,
      color: 'from-pink-500 to-rose-600',
      link: 'TraderMapMenu'
    },
    {
      title: t('treasury'),
      description: t('treasuryDesc'),
      icon: DollarSign,
      color: 'from-emerald-500 to-green-600',
      link: 'TreasuryMenu'
    },
    {
      title: t('business'),
      description: t('businessDesc'),
      icon: Briefcase,
      color: 'from-indigo-500 to-blue-600',
      link: 'Business'
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950">
      {/* Header */}
      <div className="border-b border-slate-800 bg-slate-900/50 backdrop-blur">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-lg flex items-center justify-center">
                <TrendingUp className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-white">AlphaLog</h1>
                <p className="text-xs text-slate-400">Trading Intelligence Platform</p>
              </div>
            </div>
            <Button 
              variant="ghost" 
              size="icon" 
              className="text-slate-400 hover:text-white"
              onClick={() => setSettingsOpen(true)}
            >
              <Settings className="w-5 h-5" />
            </Button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-6 py-12">
      {/* Market Data Card */}
{marketData && (
  <Card className="mb-8 bg-slate-900/70 border-slate-800">
    <CardHeader>
      <CardTitle className="text-white">
        {t('marketLiveData')}
      </CardTitle>
    </CardHeader>
    <CardContent className="text-slate-300 space-y-2">
      <p><strong>{t('symbol')}:</strong> {marketData.symbol}</p>
      <p><strong>{t('bid')}:</strong> {marketData.bid}</p>
      <p><strong>{t('ask')}:</strong> {marketData.ask}</p>
      <p><strong>{t('last')}:</strong> {marketData.last}</p>
      <p className="text-xs text-slate-500">
        {t('updated')}: {new Date(marketData.receivedAt).toLocaleString()}
      </p>
    </CardContent>
  </Card>
)}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h2 className="text-3xl font-bold text-white mb-2">{t('welcomeBack')}</h2>
            <p className="text-slate-400">{t('neuralNetwork')}</p>
          </div>
          <Button 
            onClick={handleRefresh}
            variant="outline"
            className="border-slate-700 text-slate-300 hover:text-white"
            disabled={refreshing}
          >
            <RefreshCw className={`w-4 h-4 mr-2 ${refreshing ? 'animate-spin' : ''}`} />
            {t('refresh')}
          </Button>
        </div>

        {/* Trades Stats Card */}
        <Card className="bg-slate-900/50 border-slate-800 mb-8">
          <CardHeader>
            <div className="flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-green-400" />
              <CardTitle className="text-white">{t('trades')}</CardTitle>
            </div>
          </CardHeader>
          <CardContent>
            {/* Categories Grid */}
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4 mb-6">
              {categories.length > 0 ? (
                categories.map((category) => {
                  const categoryAccounts = accounts.filter(acc => acc.category_id === category.id);
                  if (categoryAccounts.length === 0) return null;
                  
                  const pnlPct = getCategoryPnLPct(category.id);
                  return (
                    <div key={category.id} className="text-center p-3 bg-slate-800/30 rounded-lg">
                      <p className="text-sm text-slate-400 mb-1">{category.name}</p>
                      <p className={`text-lg font-bold ${pnlPct >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                        {pnlPct >= 0 ? '+' : ''}{pnlPct.toFixed(2)}%
                      </p>
                    </div>
                  );
                })
              ) : (
                <div className="col-span-full text-center py-4">
                  <p className="text-slate-400">{t('noCuentasActivas')}</p>
                </div>
              )}
            </div>

            {/* Time-based Stats */}
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
              <div className="p-4 bg-slate-800/50 rounded-lg border border-slate-700">
                <div className="flex items-center justify-between mb-2">
                  <p className="text-sm text-slate-400">{t('dailyTotal')}</p>
                  <TrendingUp className="w-4 h-4 text-slate-400" />
                </div>
                <p className={`text-xl font-bold ${dailyPnLPct >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                  {dailyPnLPct >= 0 ? '+' : ''}{dailyPnLPct.toFixed(2)}%
                </p>
              </div>
              <div className="p-4 bg-slate-800/50 rounded-lg border border-slate-700">
                <div className="flex items-center justify-between mb-2">
                  <p className="text-sm text-slate-400">{t('weekly')}</p>
                  <TrendingUp className="w-4 h-4 text-slate-400" />
                </div>
                <p className={`text-xl font-bold ${weeklyPnLPct >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                  {weeklyPnLPct >= 0 ? '+' : ''}{weeklyPnLPct.toFixed(2)}%
                </p>
              </div>
              <div className="p-4 bg-slate-800/50 rounded-lg border border-slate-700">
                <div className="flex items-center justify-between mb-2">
                  <p className="text-sm text-slate-400">{t('monthly')}</p>
                  <TrendingUp className="w-4 h-4 text-slate-400" />
                </div>
                <p className={`text-xl font-bold ${monthlyPnLPct >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                  {monthlyPnLPct >= 0 ? '+' : ''}{monthlyPnLPct.toFixed(2)}%
                </p>
              </div>
              <div className="p-4 bg-slate-800/50 rounded-lg border border-slate-700">
                <div className="flex items-center justify-between mb-2">
                  <p className="text-sm text-slate-400">{t('quarterly')}</p>
                  <TrendingUp className="w-4 h-4 text-slate-400" />
                </div>
                <p className={`text-xl font-bold ${quarterlyPnLPct >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                  {quarterlyPnLPct >= 0 ? '+' : ''}{quarterlyPnLPct.toFixed(2)}%
                </p>
              </div>
              <div className="p-4 bg-slate-800/50 rounded-lg border border-slate-700">
                <div className="flex items-center justify-between mb-2">
                  <p className="text-sm text-slate-400">{t('yearly')}</p>
                  <TrendingUp className="w-4 h-4 text-slate-400" />
                </div>
                <p className={`text-xl font-bold ${yearlyPnLPct >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                  {yearlyPnLPct >= 0 ? '+' : ''}{yearlyPnLPct.toFixed(2)}%
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Module Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {mainModules.map((module) => {
            const Icon = module.icon;
            return (
              <Link key={module.title} to={createPageUrl(module.link)}>
                <Card className="bg-slate-900/50 border-slate-800 hover:border-slate-700 transition-all duration-300 hover:scale-105 cursor-pointer group">
                  <CardHeader>
                    <div className={`w-12 h-12 rounded-lg bg-gradient-to-br ${module.color} flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
                      <Icon className="w-6 h-6 text-white" />
                    </div>
                    <CardTitle className="text-white">{module.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-slate-400 text-sm">{module.description}</p>
                  </CardContent>
                </Card>
              </Link>
            );
          })}
        </div>
      </div>

      {/* Settings Dialog */}
      <Dialog open={settingsOpen} onOpenChange={setSettingsOpen}>
        <DialogContent className="bg-slate-900 border-slate-800 text-white max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-xl">
              <Settings className="w-5 h-5" />
              {t('settings')}
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-6 py-4">
            {/* Theme Toggle */}
            <div className="space-y-4">
              <h3 className="text-sm font-semibold text-slate-400 uppercase">{t('appearance')}</h3>
              <div className="flex items-center justify-between p-4 bg-slate-800/50 rounded-lg border border-slate-700">
                <div className="flex items-center gap-3">
                  {theme === 'dark' ? (
                    <Moon className="w-5 h-5 text-indigo-400" />
                  ) : (
                    <Sun className="w-5 h-5 text-yellow-400" />
                  )}
                  <div>
                    <Label className="text-white font-medium">{t('theme')}</Label>
                    <p className="text-xs text-slate-400">
                      {theme === 'dark' ? t('darkMode') : t('lightMode')}
                    </p>
                  </div>
                </div>
                <Switch
                  checked={theme === 'light'}
                  onCheckedChange={toggleTheme}
                  className="data-[state=checked]:bg-yellow-500"
                />
              </div>

              <div className="flex items-center justify-between p-4 bg-slate-800/50 rounded-lg border border-slate-700">
                <div className="flex items-center gap-3">
                  <Languages className="w-5 h-5 text-blue-400" />
                  <div>
                    <Label className="text-white font-medium">{t('language')}</Label>
                    <p className="text-xs text-slate-400">
                      {language === 'es' ? t('spanish') : t('english')}
                    </p>
                  </div>
                </div>
                <Switch
                  checked={language === 'es'}
                  onCheckedChange={toggleLanguage}
                  className="data-[state=checked]:bg-blue-500"
                />
              </div>
            </div>

            {/* Backup Section */}
            <div className="space-y-4">
              <h3 className="text-sm font-semibold text-slate-400 uppercase">{t('dataBackup')}</h3>
              
              <div className="space-y-3">
                <Button
                  onClick={handleExportBackup}
                  variant="outline"
                  className="w-full justify-start border-slate-700 hover:bg-slate-800"
                >
                  <Download className="w-4 h-4 mr-2" />
                  {t('exportBackup')}
                </Button>

                <div>
                  <input
                    type="file"
                    accept=".json"
                    onChange={handleImportBackup}
                    className="hidden"
                    id="backup-import"
                  />
                  <Label htmlFor="backup-import">
                    <Button
                      variant="outline"
                      className="w-full justify-start border-slate-700 hover:bg-slate-800"
                      asChild
                    >
                      <span>
                        <Upload className="w-4 h-4 mr-2" />
                        {t('importBackup')}
                      </span>
                    </Button>
                  </Label>
                </div>

                {backupStatus && (
                  <div className="p-3 bg-slate-800 rounded-lg border border-slate-700 text-center">
                    <p className="text-sm text-slate-300">{backupStatus}</p>
                  </div>
                )}

                <div className="p-4 bg-blue-500/10 border border-blue-500/30 rounded-lg">
                  <div className="flex items-start gap-3">
                    <Database className="w-5 h-5 text-blue-400 flex-shrink-0 mt-0.5" />
                    <div className="text-xs text-blue-300">
                      <p className="font-medium mb-1">{t('backupInfo')}</p>
                      <p className="text-blue-400">
                        {t('backupInfoText')}
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Profiles Section */}
              <div className="space-y-4">
                <h3 className="text-sm font-semibold text-slate-400 uppercase">{t('profiles')}</h3>
                
                <div className="space-y-3">
                  <Button
                    onClick={() => setProfileDialogOpen(true)}
                    variant="outline"
                    className="w-full justify-start border-slate-700 hover:bg-slate-800"
                  >
                    <Save className="w-4 h-4 mr-2" />
                    {t('saveCurrentProfile')}
                  </Button>

                  {profiles.length > 0 && (
                    <div className="space-y-2">
                      <p className="text-xs text-slate-500">{t('savedProfiles')}</p>
                      {profiles.map(profile => (
                        <div key={profile.id} className="p-3 bg-slate-800/50 rounded-lg border border-slate-700">
                          <div className="flex items-center justify-between mb-2">
                            <div className="flex items-center gap-2">
                              <User className="w-4 h-4 text-blue-400" />
                              <p className="text-white font-medium">{profile.profile_name}</p>
                            </div>
                            <div className="flex items-center gap-1">
                              <Button
                                size="sm"
                                variant="ghost"
                                onClick={() => handleRestoreProfile(profile)}
                                className="h-7 text-xs text-green-400 hover:text-green-300"
                              >
                                <RotateCcw className="w-3 h-3 mr-1" />
                                {t('restore')}
                              </Button>
                              <Button
                                size="sm"
                                variant="ghost"
                                onClick={() => handleDeleteProfile(profile.id)}
                                className="h-7 text-xs text-red-400 hover:text-red-300"
                              >
                                <Trash2 className="w-3 h-3" />
                              </Button>
                            </div>
                          </div>
                          <p className="text-xs text-slate-400">
                            {new Date(profile.snapshot_date).toLocaleDateString()} - {profile.description || t('noDescription')}
                          </p>
                        </div>
                      ))}
                    </div>
                  )}

                  <div className="p-4 bg-green-500/10 border border-green-500/30 rounded-lg">
                    <div className="flex items-start gap-3">
                      <Database className="w-5 h-5 text-green-400 flex-shrink-0 mt-0.5" />
                      <div className="text-xs text-green-300">
                        <p className="font-medium mb-1">{t('dataRecovery')}</p>
                        <p className="text-green-400">
                          {t('dataRecoveryText')}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Save Profile Dialog */}
      <Dialog open={profileDialogOpen} onOpenChange={setProfileDialogOpen}>
        <DialogContent className="bg-slate-900 border-slate-800 text-white max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Save className="w-5 h-5" />
              {t('saveProfile')}
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-4 py-4">
            <div>
              <Label className="text-slate-400 text-sm">{t('profileName')}</Label>
              <Input
                value={profileName}
                onChange={(e) => setProfileName(e.target.value)}
                placeholder={t('profileNamePlaceholder')}
                className="bg-slate-800 border-slate-700 text-white mt-2"
              />
            </div>

            <div>
              <Label className="text-slate-400 text-sm">{t('description')}</Label>
              <Textarea
                value={profileDescription}
                onChange={(e) => setProfileDescription(e.target.value)}
                placeholder={t('descriptionPlaceholder')}
                className="bg-slate-800 border-slate-700 text-white mt-2 h-20"
              />
            </div>

            <div className="p-3 bg-blue-500/10 border border-blue-500/30 rounded-lg">
              <p className="text-xs text-blue-300">
                {t('profileSnapshotText')}
              </p>
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <Button variant="ghost" onClick={() => setProfileDialogOpen(false)}>
                {t('cancel')}
              </Button>
              <Button 
                onClick={handleSaveProfile}
                disabled={!profileName.trim()}
                className="bg-green-600 hover:bg-green-700"
              >
                <Save className="w-4 h-4 mr-2" />
                {t('save')}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}