import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Switch } from '@/components/ui/switch';
import { 
  ChevronLeft, 
  FolderOpen, 
  PlusCircle, 
  Shield, 
  BookOpen, 
  FileText,
  Plus,
  Edit,
  Trash2,
  TrendingUp,
  TrendingDown,
  Info,
  DollarSign,
  Target,
  Activity,
  RefreshCw
} from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line } from 'recharts';

export default function TradesHub() {
  const [activeTab, setActiveTab] = useState('cuentas');
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingAccount, setEditingAccount] = useState(null);
  const [selectedAccountDetails, setSelectedAccountDetails] = useState(null);
  const [formData, setFormData] = useState({
    category_id: '',
    name: '',
    account_size: 0,
    current_balance: 0,
    phase_status: '1 fase',
    role: 'SATELLITE',
    operation_state: 'ACTIVE',
    withdrawals_enabled: true
  });

  const queryClient = useQueryClient();

  const { data: accounts = [] } = useQuery({
    queryKey: ['accounts'],
    queryFn: async () => {
      const accs = await base44.entities.Account.filter({ is_deleted: false });
      return accs.sort((a, b) => (a.index || 0) - (b.index || 0));
    }
  });

  const { data: categories = [] } = useQuery({
    queryKey: ['account-categories'],
    queryFn: () => base44.entities.AccountCategory.list()
  });

  const { data: trades = [] } = useQuery({
    queryKey: ['trades'],
    queryFn: () => base44.entities.Trade.filter({ is_deleted: false, status: 'Closed' }, '-exit_date')
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.Account.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries(['accounts']);
      setDialogOpen(false);
      resetForm();
    }
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Account.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries(['accounts']);
      setDialogOpen(false);
      resetForm();
    }
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.Account.update(id, { is_deleted: true, deleted_at: new Date().toISOString() }),
    onSuccess: () => queryClient.invalidateQueries(['accounts'])
  });

  const toggleWithdrawalsMutation = useMutation({
    mutationFn: ({ id, enabled }) => base44.entities.Account.update(id, { withdrawals_enabled: enabled }),
    onSuccess: () => queryClient.invalidateQueries(['accounts'])
  });

  const resetForm = () => {
    setFormData({
      category_id: '',
      name: '',
      account_size: 0,
      current_balance: 0,
      phase_status: '1 fase',
      role: 'SATELLITE',
      operation_state: 'ACTIVE',
      withdrawals_enabled: true
    });
    setEditingAccount(null);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (editingAccount) {
      updateMutation.mutate({ id: editingAccount.id, data: formData });
    } else {
      createMutation.mutate(formData);
    }
  };

  const handleEdit = (account) => {
    setEditingAccount(account);
    setFormData({
      category_id: account.category_id,
      name: account.name,
      account_size: account.account_size,
      current_balance: account.current_balance,
      phase_status: account.phase_status || '1 fase',
      role: account.role,
      operation_state: account.operation_state,
      withdrawals_enabled: account.withdrawals_enabled !== false
    });
    setDialogOpen(true);
  };

  const getCategoryName = (catId) => {
    const cat = categories.find(c => c.id === catId);
    return cat?.name || 'Unknown';
  };

  const getAccountTrades = (accountId) => {
    return trades.filter(t => t.account_id === accountId);
  };

  const calculateAccountStats = (accountId) => {
    const accountTrades = getAccountTrades(accountId);
    const totalPnL = accountTrades.reduce((sum, t) => sum + (t.pnl || 0), 0);
    const winningTrades = accountTrades.filter(t => t.pnl > 0);
    const losingTrades = accountTrades.filter(t => t.pnl < 0);
    const winRate = accountTrades.length > 0 ? (winningTrades.length / accountTrades.length) * 100 : 0;
    const avgWin = winningTrades.length > 0 ? winningTrades.reduce((sum, t) => sum + t.pnl, 0) / winningTrades.length : 0;
    const avgLoss = losingTrades.length > 0 ? Math.abs(losingTrades.reduce((sum, t) => sum + t.pnl, 0) / losingTrades.length) : 0;
    const profitFactor = avgLoss > 0 ? (avgWin * winningTrades.length) / (avgLoss * losingTrades.length) : 0;

    const monthlyData = accountTrades.reduce((acc, trade) => {
      const month = new Date(trade.exit_date).toISOString().slice(0, 7);
      if (!acc[month]) acc[month] = { month, pnl: 0, trades: 0 };
      acc[month].pnl += trade.pnl;
      acc[month].trades += 1;
      return acc;
    }, {});

    const chartData = Object.values(monthlyData).sort((a, b) => a.month.localeCompare(b.month));

    const cumulativePnL = [];
    let runningTotal = 0;
    accountTrades.sort((a, b) => new Date(a.exit_date) - new Date(b.exit_date)).forEach((trade, idx) => {
      runningTotal += trade.pnl;
      cumulativePnL.push({ trade: idx + 1, cumulative: runningTotal });
    });

    return {
      totalPnL,
      winRate,
      profitFactor,
      avgWin,
      avgLoss,
      winningTrades: winningTrades.length,
      losingTrades: losingTrades.length,
      chartData,
      cumulativePnL,
      recentTrades: accountTrades.slice(0, 10)
    };
  };

  const roleColors = {
    CORE: 'bg-blue-600',
    SATELLITE: 'bg-purple-600'
  };

  const stateColors = {
    ACTIVE: 'bg-green-600',
    RESERVE: 'bg-yellow-600',
    PIPELINE: 'bg-orange-600'
  };

  return (
    <div className="min-h-screen bg-slate-950 p-6">
      <div className="max-w-7xl mx-auto">
        <Link to={createPageUrl('Dashboard')}>
          <Button variant="ghost" size="sm" className="text-slate-400 hover:text-white mb-4">
            <ChevronLeft className="w-4 h-4 mr-1" />
            Atrás
          </Button>
        </Link>

        <div className="mb-8">
          <h1 className="text-3xl font-bold text-white mb-2">Trades Hub</h1>
          <p className="text-slate-400">Central command for execution and analysis.</p>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="bg-slate-900 border-slate-800 inline-flex w-auto">
            <TabsTrigger value="cuentas" className="flex items-center gap-2">
              <FolderOpen className="w-4 h-4" />
              Cuentas
            </TabsTrigger>
            <TabsTrigger value="new_trades_log" className="flex items-center gap-2">
              <PlusCircle className="w-4 h-4" />
              New Trades Log
            </TabsTrigger>
            <TabsTrigger value="evidence_vault" className="flex items-center gap-2">
              <Shield className="w-4 h-4" />
              Evidence Vault
            </TabsTrigger>
            <TabsTrigger value="playbook" className="flex items-center gap-2">
              <BookOpen className="w-4 h-4" />
              Playbook
              <span className="ml-1 px-1.5 py-0.5 text-xs bg-purple-600 text-white rounded">2</span>
            </TabsTrigger>
            <TabsTrigger value="reports" className="flex items-center gap-2">
              <FileText className="w-4 h-4" />
              Reports
            </TabsTrigger>
          </TabsList>

          <TabsContent value="cuentas" className="space-y-6">
            <div className="mb-6">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h2 className="text-2xl font-bold text-white">Gestión de Cuentas</h2>
                  <p className="text-slate-400 text-sm">Crea, edita y administra tus cuentas de trading.</p>
                </div>
                <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
                  <DialogTrigger asChild>
                    <Button onClick={resetForm} className="bg-indigo-600 hover:bg-indigo-700">
                      <Plus className="w-4 h-4 mr-2" />
                      Crear cuenta
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="bg-slate-900 border-slate-800 text-white">
                    <DialogHeader>
                      <DialogTitle>{editingAccount ? 'Editar Cuenta' : 'Nueva Cuenta'}</DialogTitle>
                    </DialogHeader>
                    <form onSubmit={handleSubmit} className="space-y-4">
                      <div>
                        <label className="text-sm text-slate-400">Categoría</label>
                        <Select value={formData.category_id} onValueChange={(value) => setFormData({ ...formData, category_id: value })}>
                          <SelectTrigger className="bg-slate-800 border-slate-700">
                            <SelectValue placeholder="Selecciona categoría" />
                          </SelectTrigger>
                          <SelectContent>
                            {categories.map(cat => (
                              <SelectItem key={cat.id} value={cat.id}>{cat.name}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <label className="text-sm text-slate-400">Nombre</label>
                        <Input
                          value={formData.name}
                          onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                          placeholder="Nombre de la cuenta..."
                          className="bg-slate-800 border-slate-700"
                        />
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label className="text-sm text-slate-400">Tamaño Base</label>
                          <Input
                            type="number"
                            value={formData.account_size}
                            onChange={(e) => setFormData({ ...formData, account_size: parseFloat(e.target.value) })}
                            className="bg-slate-800 border-slate-700"
                          />
                        </div>
                        <div>
                          <label className="text-sm text-slate-400">Balance Actual</label>
                          <Input
                            type="number"
                            value={formData.current_balance}
                            onChange={(e) => setFormData({ ...formData, current_balance: parseFloat(e.target.value) })}
                            className="bg-slate-800 border-slate-700"
                          />
                        </div>
                      </div>
                      <div>
                        <label className="text-sm text-slate-400">Estado de Fase</label>
                        <Select value={formData.phase_status} onValueChange={(value) => setFormData({ ...formData, phase_status: value })}>
                          <SelectTrigger className="bg-slate-800 border-slate-700">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="1 fase">1 fase</SelectItem>
                            <SelectItem value="2 fase">2 fase</SelectItem>
                            <SelectItem value="Instant">Instant</SelectItem>
                            <SelectItem value="Funded">Funded</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label className="text-sm text-slate-400">Rol</label>
                          <Select value={formData.role} onValueChange={(value) => setFormData({ ...formData, role: value })}>
                            <SelectTrigger className="bg-slate-800 border-slate-700">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="CORE">CORE</SelectItem>
                              <SelectItem value="SATELLITE">SATELLITE</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <div>
                          <label className="text-sm text-slate-400">Estado</label>
                          <Select value={formData.operation_state} onValueChange={(value) => setFormData({ ...formData, operation_state: value })}>
                            <SelectTrigger className="bg-slate-800 border-slate-700">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="ACTIVE">ACTIVE</SelectItem>
                              <SelectItem value="RESERVE">RESERVE</SelectItem>
                              <SelectItem value="PIPELINE">PIPELINE</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                      <div className="flex items-center justify-between">
                        <label className="text-sm text-slate-400">Retiros Habilitados</label>
                        <Switch
                          checked={formData.withdrawals_enabled}
                          onCheckedChange={(checked) => setFormData({ ...formData, withdrawals_enabled: checked })}
                        />
                      </div>
                      <div className="flex justify-end gap-2 pt-4">
                        <Button type="button" variant="ghost" onClick={() => setDialogOpen(false)}>Cancelar</Button>
                        <Button type="submit" className="bg-indigo-600 hover:bg-indigo-700">
                          {editingAccount ? 'Actualizar' : 'Crear'}
                        </Button>
                      </div>
                    </form>
                  </DialogContent>
                </Dialog>
              </div>
            </div>

            {categories.length > 0 ? (
              categories.map((category) => {
                const categoryAccounts = accounts.filter(acc => acc.category_id === category.id);
                if (categoryAccounts.length === 0) return null;

                return (
                  <div key={category.id} className="mb-8">
                    <h3 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
                      <FolderOpen className="w-5 h-5 text-slate-400" />
                      {category.name}
                      <Badge variant="outline" className="text-slate-400">
                        {categoryAccounts.length}
                      </Badge>
                    </h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                      {categoryAccounts.map((account) => {
                        const pnl = account.current_balance - account.account_size;
                        const pnlPct = account.account_size > 0 ? (pnl / account.account_size) * 100 : 0;
                        const isProfitable = pnl >= 0;

                        return (
                          <Card key={account.id} className="bg-slate-900 border-slate-800">
                            <CardHeader>
                              <div className="flex items-start justify-between">
                                <div className="flex-1">
                                  <CardTitle className="text-white text-lg">{account.name}</CardTitle>
                                  <p className="text-xs text-slate-400 mt-1">Base: ${account.account_size.toLocaleString()}</p>
                                </div>
                                <div className="flex gap-1">
                                  <Button size="icon" variant="ghost" onClick={() => handleEdit(account)} className="text-slate-400 hover:text-white h-8 w-8">
                                    <Edit className="w-3 h-3" />
                                  </Button>
                                  <Button size="icon" variant="ghost" onClick={() => deleteMutation.mutate(account.id)} className="text-slate-400 hover:text-red-400 h-8 w-8">
                                    <Trash2 className="w-3 h-3" />
                                  </Button>
                                </div>
                              </div>
                              <div className="flex flex-wrap gap-2 mt-2">
                                <Badge className={roleColors[account.role]}>{account.role}</Badge>
                                <Badge className={stateColors[account.operation_state]}>{account.operation_state}</Badge>
                                {account.phase_status && <Badge variant="outline">{account.phase_status}</Badge>}
                                <Badge className={account.withdrawals_enabled ? 'bg-green-600' : 'bg-red-600'}>
                                  Retiros: {account.withdrawals_enabled ? 'ON' : 'OFF'}
                                </Badge>
                              </div>
                            </CardHeader>
                            <CardContent>
                              <div className="space-y-3">
                                <div>
                                  <p className="text-xs text-slate-400">Balance</p>
                                  <p className="text-2xl font-bold text-white">${account.current_balance.toLocaleString()}</p>
                                </div>
                                <div className="flex items-center gap-2">
                                  {isProfitable ? <TrendingUp className="w-4 h-4 text-green-400" /> : <TrendingDown className="w-4 h-4 text-red-400" />}
                                  <span className={`text-sm font-medium ${isProfitable ? 'text-green-400' : 'text-red-400'}`}>
                                    {isProfitable ? '+' : ''}{pnl.toLocaleString()} ({pnlPct.toFixed(2)}%)
                                  </span>
                                </div>
                                <div className="flex gap-2 pt-2">
                                  <Button
                                    size="sm"
                                    variant="outline"
                                    className="flex-1 text-xs"
                                    onClick={() => setSelectedAccountDetails(account)}
                                  >
                                    <Info className="w-3 h-3 mr-1" />
                                    Ver detalles
                                  </Button>
                                  <Button
                                    size="sm"
                                    variant="outline"
                                    className="flex-1 text-xs"
                                    onClick={() => toggleWithdrawalsMutation.mutate({ 
                                      id: account.id, 
                                      enabled: !account.withdrawals_enabled 
                                    })}
                                  >
                                    <RefreshCw className="w-3 h-3 mr-1" />
                                    Actualizar Meta
                                  </Button>
                                </div>
                              </div>
                            </CardContent>
                          </Card>
                        );
                      })}
                    </div>
                  </div>
                );
              })
            ) : (
              <Card className="bg-slate-900 border-slate-800">
                <CardContent className="py-12">
                  <p className="text-center text-slate-400">No hay cuentas. ¡Crea tu primera cuenta!</p>
                </CardContent>
              </Card>
            )}

            {selectedAccountDetails && (
              <Dialog open={!!selectedAccountDetails} onOpenChange={() => setSelectedAccountDetails(null)}>
                <DialogContent className="bg-slate-900 border-slate-800 text-white max-w-5xl max-h-[90vh] overflow-y-auto">
                  <DialogHeader>
                    <DialogTitle className="text-xl">Estadísticas: {selectedAccountDetails.name}</DialogTitle>
                  </DialogHeader>
                  
                  {(() => {
                    const stats = calculateAccountStats(selectedAccountDetails.id);
                    return (
                      <div className="space-y-6">
                        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                          <Card className="bg-slate-800 border-slate-700">
                            <CardContent className="pt-6">
                              <p className="text-xs text-slate-400 flex items-center gap-2">
                                <DollarSign className="w-4 h-4" />
                                Total P&L
                              </p>
                              <p className={`text-2xl font-bold ${stats.totalPnL >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                                ${stats.totalPnL.toLocaleString()}
                              </p>
                            </CardContent>
                          </Card>

                          <Card className="bg-slate-800 border-slate-700">
                            <CardContent className="pt-6">
                              <p className="text-xs text-slate-400 flex items-center gap-2">
                                <Target className="w-4 h-4" />
                                Win Rate
                              </p>
                              <p className="text-2xl font-bold text-white">{stats.winRate.toFixed(1)}%</p>
                              <p className="text-xs text-slate-400">{stats.winningTrades}W / {stats.losingTrades}L</p>
                            </CardContent>
                          </Card>

                          <Card className="bg-slate-800 border-slate-700">
                            <CardContent className="pt-6">
                              <p className="text-xs text-slate-400 flex items-center gap-2">
                                <Activity className="w-4 h-4" />
                                Profit Factor
                              </p>
                              <p className="text-2xl font-bold text-white">{stats.profitFactor.toFixed(2)}</p>
                              <p className="text-xs text-slate-400">Avg W: ${stats.avgWin.toFixed(0)} / L: ${stats.avgLoss.toFixed(0)}</p>
                            </CardContent>
                          </Card>

                          <Card className="bg-slate-800 border-slate-700">
                            <CardContent className="pt-6">
                              <p className="text-xs text-slate-400 flex items-center gap-2">
                                <TrendingUp className="w-4 h-4" />
                                Balance
                              </p>
                              <p className="text-2xl font-bold text-white">${selectedAccountDetails.current_balance.toLocaleString()}</p>
                              <p className="text-xs text-slate-400">Inicial: ${selectedAccountDetails.account_size.toLocaleString()}</p>
                            </CardContent>
                          </Card>
                        </div>

                        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                          <Card className="bg-slate-800 border-slate-700">
                            <CardHeader>
                              <CardTitle className="text-white text-base">P&L Mensual</CardTitle>
                            </CardHeader>
                            <CardContent>
                              <ResponsiveContainer width="100%" height={250}>
                                <BarChart data={stats.chartData}>
                                  <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                                  <XAxis dataKey="month" stroke="#94a3b8" />
                                  <YAxis stroke="#94a3b8" />
                                  <Tooltip
                                    contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155' }}
                                    labelStyle={{ color: '#f1f5f9' }}
                                  />
                                  <Bar dataKey="pnl" fill="#3b82f6" />
                                </BarChart>
                              </ResponsiveContainer>
                            </CardContent>
                          </Card>

                          <Card className="bg-slate-800 border-slate-700">
                            <CardHeader>
                              <CardTitle className="text-white text-base">P&L Acumulado</CardTitle>
                            </CardHeader>
                            <CardContent>
                              <ResponsiveContainer width="100%" height={250}>
                                <LineChart data={stats.cumulativePnL}>
                                  <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                                  <XAxis dataKey="trade" stroke="#94a3b8" />
                                  <YAxis stroke="#94a3b8" />
                                  <Tooltip
                                    contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155' }}
                                    labelStyle={{ color: '#f1f5f9' }}
                                  />
                                  <Line type="monotone" dataKey="cumulative" stroke="#10b981" strokeWidth={2} />
                                </LineChart>
                              </ResponsiveContainer>
                            </CardContent>
                          </Card>
                        </div>

                        <Card className="bg-slate-800 border-slate-700">
                          <CardHeader>
                            <CardTitle className="text-white text-base">Operaciones Recientes</CardTitle>
                          </CardHeader>
                          <CardContent>
                            <div className="space-y-2">
                              {stats.recentTrades.map((trade) => (
                                <div key={trade.id} className="flex items-center justify-between p-3 bg-slate-700 rounded">
                                  <div className="flex items-center gap-3">
                                    <div className={`w-2 h-2 rounded-full ${trade.pnl >= 0 ? 'bg-green-500' : 'bg-red-500'}`} />
                                    <div>
                                      <p className="text-white font-medium">{trade.symbol}</p>
                                      <p className="text-xs text-slate-400">{new Date(trade.exit_date).toLocaleDateString()}</p>
                                    </div>
                                  </div>
                                  <div className="text-right">
                                    <p className={`font-bold ${trade.pnl >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                                      ${trade.pnl.toLocaleString()}
                                    </p>
                                    {trade.return_pct && (
                                      <p className="text-xs text-slate-400">{trade.return_pct.toFixed(2)}%</p>
                                    )}
                                  </div>
                                </div>
                              ))}

                              {stats.recentTrades.length === 0 && (
                                <p className="text-center text-slate-400 py-8">No hay operaciones aún</p>
                              )}
                            </div>
                          </CardContent>
                        </Card>
                      </div>
                    );
                  })()}
                </DialogContent>
              </Dialog>
            )}
          </TabsContent>

          <TabsContent value="new_trades_log" className="space-y-6">
            {(() => {
              const [tradeDialogOpen, setTradeDialogOpen] = useState(false);
              const [selectedAccountForTrade, setSelectedAccountForTrade] = useState(null);
              const [tempAccountSelection, setTempAccountSelection] = useState('');
              const [tradeFormData, setTradeFormData] = useState({
                account_id: '',
                symbol: '',
                direction: 'Long',
                status: 'Closed',
                entry_date: new Date().toISOString().split('T')[0],
                exit_date: new Date().toISOString().split('T')[0],
                entry_price: 0,
                exit_price: 0,
                quantity: 0,
                fees: 0,
                pnl: 0,
                notes: '',
                setup_id: '',
                screenshot_url: '',
                is_featured_in_report: false
              });

              const { data: setups = [] } = useQuery({
                queryKey: ['setups-for-trade'],
                queryFn: () => base44.entities.SetupLibrary.filter({ is_deleted: false })
              });

              const createTradeMutation = useMutation({
                mutationFn: (data) => base44.entities.Trade.create(data),
                onSuccess: () => {
                  queryClient.invalidateQueries(['trades']);
                  setTradeDialogOpen(false);
                  setSelectedAccountForTrade(null);
                  setTempAccountSelection('');
                  setTradeFormData({
                    account_id: '',
                    symbol: '',
                    direction: 'Long',
                    status: 'Closed',
                    entry_date: new Date().toISOString().split('T')[0],
                    exit_date: new Date().toISOString().split('T')[0],
                    entry_price: 0,
                    exit_price: 0,
                    quantity: 0,
                    fees: 0,
                    pnl: 0,
                    notes: '',
                    setup_id: '',
                    screenshot_url: '',
                    is_featured_in_report: false
                  });
                }
              });

              const handleTradeSubmit = (e) => {
                e.preventDefault();
                createTradeMutation.mutate({
                  ...tradeFormData,
                  account_id: selectedAccountForTrade
                });
              };

              const handleApplyAccountSelection = () => {
                if (tempAccountSelection) {
                  setSelectedAccountForTrade(tempAccountSelection);
                }
              };

              const handleFileUpload = async (e) => {
                const file = e.target.files[0];
                if (file) {
                  try {
                    const { file_url } = await base44.integrations.Core.UploadFile({ file });
                    setTradeFormData({ ...tradeFormData, screenshot_url: file_url });
                  } catch (error) {
                    console.error('Error uploading file:', error);
                  }
                }
              };

              return (
                <>
                  <div className="mb-6">
                    <div className="flex items-center justify-between mb-4">
                      <div>
                        <h2 className="text-2xl font-bold text-white">Registro de Operaciones</h2>
                        <p className="text-slate-400 text-sm">Registra tus trades y analiza tu desempeño.</p>
                      </div>
                      <Dialog open={tradeDialogOpen} onOpenChange={setTradeDialogOpen}>
                        <DialogTrigger asChild>
                          <Button className="bg-green-600 hover:bg-green-700">
                            <PlusCircle className="w-4 h-4 mr-2" />
                            Agregar Operación
                          </Button>
                        </DialogTrigger>
                        <DialogContent className="bg-slate-900 border-slate-800 text-white max-w-2xl max-h-[90vh] overflow-y-auto">
                          <DialogHeader>
                            <DialogTitle>Nueva Operación</DialogTitle>
                          </DialogHeader>

                          {!selectedAccountForTrade ? (
                            <div className="space-y-4 py-6">
                              <div className="text-center mb-6">
                                <FolderOpen className="w-12 h-12 text-slate-500 mx-auto mb-3" />
                                <p className="text-slate-300 font-medium">Selecciona una cuenta para continuar</p>
                              </div>
                              <div>
                                <label className="text-sm text-slate-400 mb-2 block">Cuenta</label>
                                <Select value={tempAccountSelection} onValueChange={setTempAccountSelection}>
                                  <SelectTrigger className="bg-slate-800 border-slate-700">
                                    <SelectValue placeholder="Selecciona cuenta" />
                                  </SelectTrigger>
                                  <SelectContent>
                                    {accounts.filter(a => a.operation_state === 'ACTIVE').map(acc => (
                                      <SelectItem key={acc.id} value={acc.id}>{acc.name}</SelectItem>
                                    ))}
                                  </SelectContent>
                                </Select>
                              </div>
                              <div className="flex justify-end gap-2 pt-4">
                                <Button type="button" variant="ghost" onClick={() => setTradeDialogOpen(false)}>
                                  Cancelar
                                </Button>
                                <Button 
                                  type="button" 
                                  onClick={handleApplyAccountSelection}
                                  disabled={!tempAccountSelection}
                                  className="bg-green-600 hover:bg-green-700"
                                >
                                  Aplicar
                                </Button>
                              </div>
                            </div>
                          ) : (
                            <form onSubmit={handleTradeSubmit} className="space-y-4">
                              <div className="flex items-center justify-between p-3 bg-slate-800 rounded-lg mb-4">
                                <div>
                                  <p className="text-xs text-slate-400">Cuenta seleccionada</p>
                                  <p className="text-white font-medium">
                                    {accounts.find(a => a.id === selectedAccountForTrade)?.name}
                                  </p>
                                </div>
                                <Button
                                  type="button"
                                  variant="ghost"
                                  size="sm"
                                  onClick={() => {
                                    setSelectedAccountForTrade(null);
                                    setTempAccountSelection('');
                                  }}
                                  className="text-slate-400 hover:text-white"
                                >
                                  Cambiar
                                </Button>
                              </div>

                            <div className="grid grid-cols-2 gap-4">
                              <div>
                                <label className="text-sm text-slate-400">Símbolo</label>
                                <Input
                                  value={tradeFormData.symbol}
                                  onChange={(e) => setTradeFormData({ ...tradeFormData, symbol: e.target.value })}
                                  placeholder="XAUUSD, US500..."
                                  className="bg-slate-800 border-slate-700"
                                />
                              </div>
                              <div>
                                <label className="text-sm text-slate-400">Dirección</label>
                                <Select value={tradeFormData.direction} onValueChange={(value) => setTradeFormData({ ...tradeFormData, direction: value })}>
                                  <SelectTrigger className="bg-slate-800 border-slate-700">
                                    <SelectValue />
                                  </SelectTrigger>
                                  <SelectContent>
                                    <SelectItem value="Long">Long</SelectItem>
                                    <SelectItem value="Short">Short</SelectItem>
                                  </SelectContent>
                                </Select>
                              </div>
                            </div>

                            <div className="grid grid-cols-2 gap-4">
                              <div>
                                <label className="text-sm text-slate-400">Fecha Entrada</label>
                                <Input
                                  type="date"
                                  value={tradeFormData.entry_date}
                                  onChange={(e) => setTradeFormData({ ...tradeFormData, entry_date: e.target.value })}
                                  className="bg-slate-800 border-slate-700"
                                />
                              </div>
                              <div>
                                <label className="text-sm text-slate-400">Fecha Salida</label>
                                <Input
                                  type="date"
                                  value={tradeFormData.exit_date}
                                  onChange={(e) => setTradeFormData({ ...tradeFormData, exit_date: e.target.value })}
                                  className="bg-slate-800 border-slate-700"
                                />
                              </div>
                            </div>

                            <div className="grid grid-cols-3 gap-4">
                              <div>
                                <label className="text-sm text-slate-400">Precio Entrada</label>
                                <Input
                                  type="number"
                                  step="any"
                                  value={tradeFormData.entry_price}
                                  onChange={(e) => setTradeFormData({ ...tradeFormData, entry_price: parseFloat(e.target.value) })}
                                  className="bg-slate-800 border-slate-700"
                                />
                              </div>
                              <div>
                                <label className="text-sm text-slate-400">Precio Salida</label>
                                <Input
                                  type="number"
                                  step="any"
                                  value={tradeFormData.exit_price}
                                  onChange={(e) => setTradeFormData({ ...tradeFormData, exit_price: parseFloat(e.target.value) })}
                                  className="bg-slate-800 border-slate-700"
                                />
                              </div>
                              <div>
                                <label className="text-sm text-slate-400">Cantidad</label>
                                <Input
                                  type="number"
                                  step="any"
                                  value={tradeFormData.quantity}
                                  onChange={(e) => setTradeFormData({ ...tradeFormData, quantity: parseFloat(e.target.value) })}
                                  className="bg-slate-800 border-slate-700"
                                />
                              </div>
                            </div>

                            <div className="grid grid-cols-2 gap-4">
                              <div>
                                <label className="text-sm text-slate-400">P&L ($)</label>
                                <Input
                                  type="number"
                                  step="any"
                                  value={tradeFormData.pnl}
                                  onChange={(e) => setTradeFormData({ ...tradeFormData, pnl: parseFloat(e.target.value) })}
                                  className="bg-slate-800 border-slate-700"
                                />
                              </div>
                              <div>
                                <label className="text-sm text-slate-400">Comisiones</label>
                                <Input
                                  type="number"
                                  step="any"
                                  value={tradeFormData.fees}
                                  onChange={(e) => setTradeFormData({ ...tradeFormData, fees: parseFloat(e.target.value) })}
                                  className="bg-slate-800 border-slate-700"
                                />
                              </div>
                            </div>

                              <div>
                                <label className="text-sm text-slate-400">Setup del Playbook (opcional)</label>
                                <Select value={tradeFormData.setup_id} onValueChange={(value) => setTradeFormData({ ...tradeFormData, setup_id: value })}>
                                  <SelectTrigger className="bg-slate-800 border-slate-700">
                                    <SelectValue placeholder="Selecciona un setup" />
                                  </SelectTrigger>
                                  <SelectContent>
                                    <SelectItem value={null}>Ninguno</SelectItem>
                                    {setups.map(setup => (
                                      <SelectItem key={setup.id} value={setup.id}>
                                        {setup.name}
                                      </SelectItem>
                                    ))}
                                  </SelectContent>
                                </Select>
                              </div>

                              <div>
                                <label className="text-sm text-slate-400 mb-2 block">Screenshot Evidence (opcional)</label>
                                <Input
                                  type="file"
                                  accept="image/*"
                                  onChange={handleFileUpload}
                                  className="bg-slate-800 border-slate-700"
                                />
                                {tradeFormData.screenshot_url && (
                                  <p className="text-xs text-green-400 mt-2">✓ Screenshot cargado</p>
                                )}
                              </div>

                              <div>
                                <label className="text-sm text-slate-400">Notas</label>
                                <Input
                                  value={tradeFormData.notes}
                                  onChange={(e) => setTradeFormData({ ...tradeFormData, notes: e.target.value })}
                                  placeholder="Observaciones sobre el trade..."
                                  className="bg-slate-800 border-slate-700"
                                />
                              </div>

                              <div className="grid grid-cols-2 gap-4">
                                <div>
                                  <label className="text-sm text-slate-400">Estado</label>
                                  <Select value={tradeFormData.status} onValueChange={(value) => setTradeFormData({ ...tradeFormData, status: value })}>
                                    <SelectTrigger className="bg-slate-800 border-slate-700">
                                      <SelectValue />
                                    </SelectTrigger>
                                    <SelectContent>
                                      <SelectItem value="Open">Abierta</SelectItem>
                                      <SelectItem value="Closed">Cerrada</SelectItem>
                                    </SelectContent>
                                  </Select>
                                </div>
                                <div className="flex items-end">
                                  <div className="flex items-center space-x-2 pb-2">
                                    <Switch
                                      checked={tradeFormData.is_featured_in_report}
                                      onCheckedChange={(checked) => setTradeFormData({ ...tradeFormData, is_featured_in_report: checked })}
                                    />
                                    <label className="text-sm text-slate-400">Destacar en Reports</label>
                                  </div>
                                </div>
                              </div>

                              <div className="flex justify-end gap-2 pt-4">
                                <Button type="button" variant="ghost" onClick={() => {
                                  setTradeDialogOpen(false);
                                  setSelectedAccountForTrade(null);
                                  setTempAccountSelection('');
                                }}>
                                  Cancelar
                                </Button>
                                <Button type="submit" className="bg-green-600 hover:bg-green-700">
                                  Registrar Trade
                                </Button>
                              </div>
                            </form>
                          )}
                        </DialogContent>
                      </Dialog>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                    <Card className="bg-slate-900 border-slate-800 lg:col-span-2">
                      <CardHeader>
                        <CardTitle className="text-white flex items-center gap-2">
                          Operaciones Recientes
                          <Badge variant="outline">{trades.length}</Badge>
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        {trades.length > 0 ? (
                          <div className="space-y-2 max-h-[600px] overflow-y-auto pr-2">
                            {trades.slice(0, 30).map((trade) => {
                              const account = accounts.find(a => a.id === trade.account_id);
                              const setup = setups.find(s => s.id === trade.setup_id);
                              return (
                                <div 
                                  key={trade.id} 
                                  className="flex items-center justify-between p-3 bg-slate-800/50 rounded-lg hover:bg-slate-800 transition-all border border-slate-700/50 hover:border-slate-600"
                                >
                                  <div className="flex items-center gap-3 flex-1">
                                    <div className={`w-2 h-2 rounded-full ${trade.pnl >= 0 ? 'bg-green-400' : 'bg-red-400'}`} />
                                    <div className="flex-1 min-w-0">
                                      <div className="flex items-center gap-2 mb-1">
                                        <p className="text-white font-semibold">{trade.symbol}</p>
                                        <Badge 
                                          variant="outline" 
                                          className={`text-xs ${trade.direction === 'Long' ? 'border-green-600 text-green-400' : 'border-red-600 text-red-400'}`}
                                        >
                                          {trade.direction}
                                        </Badge>
                                        {setup && (
                                          <Badge className="bg-purple-600 text-xs">{setup.short_name || setup.name}</Badge>
                                        )}
                                      </div>
                                      <div className="flex items-center gap-2 text-xs text-slate-400">
                                        <span>{account?.name || 'Unknown'}</span>
                                        <span>•</span>
                                        <span>{new Date(trade.exit_date).toLocaleDateString()}</span>
                                      </div>
                                    </div>
                                  </div>
                                  <div className="text-right ml-4">
                                    <p className={`text-lg font-bold ${trade.pnl >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                                      {trade.pnl >= 0 ? '+' : ''}${Math.abs(trade.pnl).toLocaleString()}
                                    </p>
                                  </div>
                                </div>
                              );
                            })}
                          </div>
                        ) : (
                          <div className="text-center py-12">
                            <PlusCircle className="w-12 h-12 text-slate-600 mx-auto mb-3" />
                            <p className="text-slate-400">No hay operaciones registradas</p>
                            <p className="text-slate-500 text-sm mt-1">Comienza agregando tu primera operación</p>
                          </div>
                        )}
                      </CardContent>
                    </Card>

                    <div className="space-y-4">
                      <Card className="bg-slate-900 border-slate-800">
                        <CardHeader>
                          <CardTitle className="text-white text-base">Resumen Rápido</CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-3">
                          {(() => {
                            const totalPnL = trades.reduce((sum, t) => sum + (t.pnl || 0), 0);
                            const winningTrades = trades.filter(t => t.pnl > 0).length;
                            const losingTrades = trades.filter(t => t.pnl < 0).length;
                            const winRate = trades.length > 0 ? (winningTrades / trades.length) * 100 : 0;
                            
                            return (
                              <>
                                <div className="flex justify-between items-center">
                                  <span className="text-sm text-slate-400">Total P&L</span>
                                  <span className={`text-lg font-bold ${totalPnL >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                                    ${totalPnL.toLocaleString()}
                                  </span>
                                </div>
                                <div className="flex justify-between items-center">
                                  <span className="text-sm text-slate-400">Win Rate</span>
                                  <span className="text-lg font-bold text-white">{winRate.toFixed(1)}%</span>
                                </div>
                                <div className="flex justify-between items-center">
                                  <span className="text-sm text-slate-400">Trades</span>
                                  <span className="text-lg font-bold text-white">{trades.length}</span>
                                </div>
                                <div className="pt-2 border-t border-slate-800">
                                  <div className="flex justify-between text-xs text-slate-400">
                                    <span>Ganadoras: {winningTrades}</span>
                                    <span>Perdedoras: {losingTrades}</span>
                                  </div>
                                </div>
                              </>
                            );
                          })()}
                        </CardContent>
                      </Card>

                      <Card className="bg-slate-900 border-slate-800">
                        <CardHeader>
                          <CardTitle className="text-white text-base">Top Setups</CardTitle>
                        </CardHeader>
                        <CardContent>
                          {(() => {
                            const setupStats = setups.map(setup => {
                              const setupTrades = trades.filter(t => t.setup_id === setup.id);
                              const pnl = setupTrades.reduce((sum, t) => sum + (t.pnl || 0), 0);
                              return { setup, trades: setupTrades.length, pnl };
                            }).filter(s => s.trades > 0).sort((a, b) => b.pnl - a.pnl).slice(0, 3);

                            return setupStats.length > 0 ? (
                              <div className="space-y-2">
                                {setupStats.map(({ setup, trades, pnl }) => (
                                  <div key={setup.id} className="flex justify-between items-center text-sm">
                                    <span className="text-slate-300">{setup.short_name || setup.name}</span>
                                    <div className="flex items-center gap-2">
                                      <Badge variant="outline" className="text-xs">{trades}</Badge>
                                      <span className={`font-bold ${pnl >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                                        ${pnl.toFixed(0)}
                                      </span>
                                    </div>
                                  </div>
                                ))}
                              </div>
                            ) : (
                              <p className="text-slate-500 text-sm text-center py-4">Sin datos</p>
                            );
                          })()}
                        </CardContent>
                      </Card>
                    </div>
                  </div>
                </>
              );
            })()}
          </TabsContent>

          <TabsContent value="evidence_vault" className="space-y-6">
            {(() => {
              const [evidenceDialogOpen, setEvidenceDialogOpen] = useState(false);
              const [uploadingFile, setUploadingFile] = useState(false);
              const [selectedFile, setSelectedFile] = useState(null);
              const [evidenceNotes, setEvidenceNotes] = useState('');
              const [selectedTradeId, setSelectedTradeId] = useState('');
              const [selectedAccountId, setSelectedAccountId] = useState('');

              const { data: evidences = [] } = useQuery({
                queryKey: ['tv-evidence'],
                queryFn: () => base44.entities.TVAnalysisEvidence.filter({ is_deleted: false }, '-captured_at')
              });

              const uploadEvidenceMutation = useMutation({
                mutationFn: async (data) => {
                  setUploadingFile(true);
                  const { file_url } = await base44.integrations.Core.UploadFile({ file: data.file });
                  await base44.entities.TVAnalysisEvidence.create({
                    image_file: file_url,
                    captured_at: new Date().toISOString(),
                    user_notes: data.notes,
                    trade_id: data.trade_id || null,
                    account_id: data.account_id || null,
                    validation_status: 'needs_review'
                  });
                  setUploadingFile(false);
                },
                onSuccess: () => {
                  queryClient.invalidateQueries(['tv-evidence']);
                  setEvidenceDialogOpen(false);
                  setSelectedFile(null);
                  setEvidenceNotes('');
                  setSelectedTradeId('');
                  setSelectedAccountId('');
                }
              });

              const deleteEvidenceMutation = useMutation({
                mutationFn: (id) => base44.entities.TVAnalysisEvidence.update(id, { is_deleted: true, deleted_at: new Date().toISOString() }),
                onSuccess: () => queryClient.invalidateQueries(['tv-evidence'])
              });

              const handleFileSelect = (e) => {
                const file = e.target.files[0];
                if (file) {
                  setSelectedFile(file);
                }
              };

              const handleUpload = () => {
                if (!selectedFile) return;
                uploadEvidenceMutation.mutate({
                  file: selectedFile,
                  notes: evidenceNotes,
                  trade_id: selectedTradeId,
                  account_id: selectedAccountId
                });
              };

              const validationColors = {
                valid: 'bg-green-600',
                needs_review: 'bg-yellow-600',
                invalid: 'bg-red-600'
              };

              return (
                <>
                  <div className="mb-6">
                    <div className="flex items-center justify-between mb-4">
                      <div>
                        <h2 className="text-2xl font-bold text-white">Evidence Vault</h2>
                        <p className="text-slate-400 text-sm">Screenshots de análisis de TradingView y evidencia visual.</p>
                      </div>
                      <Dialog open={evidenceDialogOpen} onOpenChange={setEvidenceDialogOpen}>
                        <DialogTrigger asChild>
                          <Button className="bg-purple-600 hover:bg-purple-700">
                            <Shield className="w-4 h-4 mr-2" />
                            Subir Evidencia
                          </Button>
                        </DialogTrigger>
                        <DialogContent className="bg-slate-900 border-slate-800 text-white">
                          <DialogHeader>
                            <DialogTitle>Nueva Evidencia</DialogTitle>
                          </DialogHeader>
                          <div className="space-y-4">
                            <div>
                              <label className="text-sm text-slate-400 mb-2 block">Screenshot</label>
                              <Input
                                type="file"
                                accept="image/*"
                                onChange={handleFileSelect}
                                className="bg-slate-800 border-slate-700"
                              />
                              {selectedFile && (
                                <p className="text-xs text-green-400 mt-2">✓ {selectedFile.name}</p>
                              )}
                            </div>

                            <div>
                              <label className="text-sm text-slate-400 mb-2 block">Cuenta (opcional)</label>
                              <Select value={selectedAccountId} onValueChange={setSelectedAccountId}>
                                <SelectTrigger className="bg-slate-800 border-slate-700">
                                  <SelectValue placeholder="Selecciona cuenta" />
                                </SelectTrigger>
                                <SelectContent>
                                  <SelectItem value={null}>Ninguna</SelectItem>
                                  {accounts.map(acc => (
                                    <SelectItem key={acc.id} value={acc.id}>{acc.name}</SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                            </div>

                            <div>
                              <label className="text-sm text-slate-400 mb-2 block">Trade relacionado (opcional)</label>
                              <Select value={selectedTradeId} onValueChange={setSelectedTradeId}>
                                <SelectTrigger className="bg-slate-800 border-slate-700">
                                  <SelectValue placeholder="Selecciona trade" />
                                </SelectTrigger>
                                <SelectContent>
                                  <SelectItem value={null}>Ninguno</SelectItem>
                                  {trades.slice(0, 20).map(t => (
                                    <SelectItem key={t.id} value={t.id}>
                                      {t.symbol} - {new Date(t.exit_date).toLocaleDateString()}
                                    </SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                            </div>

                            <div>
                              <label className="text-sm text-slate-400 mb-2 block">Notas</label>
                              <Input
                                value={evidenceNotes}
                                onChange={(e) => setEvidenceNotes(e.target.value)}
                                placeholder="Observaciones sobre el análisis..."
                                className="bg-slate-800 border-slate-700"
                              />
                            </div>

                            <div className="flex justify-end gap-2 pt-4">
                              <Button type="button" variant="ghost" onClick={() => setEvidenceDialogOpen(false)}>
                                Cancelar
                              </Button>
                              <Button
                                onClick={handleUpload}
                                disabled={!selectedFile || uploadingFile}
                                className="bg-purple-600 hover:bg-purple-700"
                              >
                                {uploadingFile ? 'Subiendo...' : 'Subir'}
                              </Button>
                            </div>
                          </div>
                        </DialogContent>
                      </Dialog>
                    </div>
                  </div>

                  {evidences.length > 0 ? (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                      {evidences.map((evidence) => {
                        const account = accounts.find(a => a.id === evidence.account_id);
                        const trade = trades.find(t => t.id === evidence.trade_id);
                        
                        return (
                          <Card key={evidence.id} className="bg-slate-900 border-slate-800">
                            <CardHeader className="pb-3">
                              <div className="flex items-start justify-between">
                                <Badge className={validationColors[evidence.validation_status]}>
                                  {evidence.validation_status === 'needs_review' ? 'Pendiente' : 
                                   evidence.validation_status === 'valid' ? 'Válido' : 'Inválido'}
                                </Badge>
                                <Button
                                  size="icon"
                                  variant="ghost"
                                  onClick={() => deleteEvidenceMutation.mutate(evidence.id)}
                                  className="text-slate-400 hover:text-red-400 h-7 w-7"
                                >
                                  <Trash2 className="w-3 h-3" />
                                </Button>
                              </div>
                            </CardHeader>
                            <CardContent className="space-y-3">
                              <div className="aspect-video bg-slate-800 rounded-lg overflow-hidden">
                                <img
                                  src={evidence.image_file}
                                  alt="Trading analysis"
                                  className="w-full h-full object-cover"
                                />
                              </div>
                              
                              <div className="space-y-1">
                                {account && (
                                  <p className="text-xs text-slate-400">
                                    <span className="text-slate-500">Cuenta:</span> {account.name}
                                  </p>
                                )}
                                {trade && (
                                  <p className="text-xs text-slate-400">
                                    <span className="text-slate-500">Trade:</span> {trade.symbol}
                                  </p>
                                )}
                                {evidence.user_notes && (
                                  <p className="text-sm text-white mt-2">{evidence.user_notes}</p>
                                )}
                                <p className="text-xs text-slate-500">
                                  {new Date(evidence.captured_at).toLocaleDateString()} {new Date(evidence.captured_at).toLocaleTimeString()}
                                </p>
                              </div>
                            </CardContent>
                          </Card>
                        );
                      })}
                    </div>
                  ) : (
                    <Card className="bg-slate-900 border-slate-800">
                      <CardContent className="py-12">
                        <div className="text-center">
                          <Shield className="w-12 h-12 text-slate-600 mx-auto mb-3" />
                          <p className="text-slate-400">No hay evidencia almacenada</p>
                          <p className="text-slate-500 text-sm mt-1">Sube tus primeros screenshots de análisis</p>
                        </div>
                      </CardContent>
                    </Card>
                  )}
                </>
              );
            })()}
          </TabsContent>

          <TabsContent value="playbook" className="space-y-6">
            {(() => {
              const [selectedSetup, setSelectedSetup] = useState(null);

              const { data: setups = [] } = useQuery({
                queryKey: ['setups'],
                queryFn: () => base44.entities.SetupLibrary.filter({ is_deleted: false })
              });

              const calculateSetupStats = (setupId) => {
                const setupTrades = trades.filter(t => t.setup_id === setupId);
                const totalPnL = setupTrades.reduce((sum, t) => sum + (t.pnl || 0), 0);
                const winningTrades = setupTrades.filter(t => t.pnl > 0);
                const winRate = setupTrades.length > 0 ? (winningTrades.length / setupTrades.length) * 100 : 0;
                
                return {
                  totalTrades: setupTrades.length,
                  winRate,
                  totalPnL,
                  avgPnL: setupTrades.length > 0 ? totalPnL / setupTrades.length : 0
                };
              };

              return (
                <>
                  <div className="mb-6">
                    <div className="flex items-center justify-between mb-4">
                      <div>
                        <h2 className="text-2xl font-bold text-white">Playbook</h2>
                        <p className="text-slate-400 text-sm">Biblioteca de setups con estadísticas de rendimiento.</p>
                      </div>
                    </div>
                  </div>

                  {setups.length > 0 ? (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                      {setups.map((setup) => {
                        const stats = calculateSetupStats(setup.id);
                        
                        return (
                          <Card key={setup.id} className="bg-slate-900 border-slate-800 hover:border-slate-700 transition-colors">
                            <CardHeader>
                              <div className="flex items-start justify-between">
                                <div className="flex-1">
                                  <CardTitle className="text-white text-lg">{setup.name}</CardTitle>
                                  {setup.short_name && (
                                    <Badge variant="outline" className="mt-2">{setup.short_name}</Badge>
                                  )}
                                </div>
                                {setup.statistics_enabled && (
                                  <Badge className="bg-green-600">Stats ON</Badge>
                                )}
                              </div>
                            </CardHeader>
                            <CardContent className="space-y-4">
                              {setup.description && (
                                <p className="text-sm text-slate-400 line-clamp-2">{setup.description}</p>
                              )}

                              {setup.statistics_enabled && stats.totalTrades > 0 && (
                                <div className="grid grid-cols-3 gap-2 p-3 bg-slate-800 rounded-lg">
                                  <div className="text-center">
                                    <p className="text-xs text-slate-400">Trades</p>
                                    <p className="text-lg font-bold text-white">{stats.totalTrades}</p>
                                  </div>
                                  <div className="text-center">
                                    <p className="text-xs text-slate-400">Win Rate</p>
                                    <p className="text-lg font-bold text-green-400">{stats.winRate.toFixed(1)}%</p>
                                  </div>
                                  <div className="text-center">
                                    <p className="text-xs text-slate-400">P&L</p>
                                    <p className={`text-lg font-bold ${stats.totalPnL >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                                      ${stats.totalPnL.toFixed(0)}
                                    </p>
                                  </div>
                                </div>
                              )}

                              {setup.timeframes && setup.timeframes.length > 0 && (
                                <div className="flex flex-wrap gap-1">
                                  {setup.timeframes.map((tf, idx) => (
                                    <Badge key={idx} variant="outline" className="text-xs">
                                      {tf}
                                    </Badge>
                                  ))}
                                </div>
                              )}

                              <Button
                                variant="outline"
                                className="w-full text-sm"
                                onClick={() => setSelectedSetup(setup)}
                              >
                                <Info className="w-3 h-3 mr-2" />
                                Ver detalles
                              </Button>
                            </CardContent>
                          </Card>
                        );
                      })}
                    </div>
                  ) : (
                    <Card className="bg-slate-900 border-slate-800">
                      <CardContent className="py-12">
                        <div className="text-center">
                          <BookOpen className="w-12 h-12 text-slate-600 mx-auto mb-3" />
                          <p className="text-slate-400">No hay setups en el playbook</p>
                          <p className="text-slate-500 text-sm mt-1">Ve a Setup Library para crear tus primeros setups</p>
                        </div>
                      </CardContent>
                    </Card>
                  )}

                  {selectedSetup && (
                    <Dialog open={!!selectedSetup} onOpenChange={() => setSelectedSetup(null)}>
                      <DialogContent className="bg-slate-900 border-slate-800 text-white max-w-3xl max-h-[90vh] overflow-y-auto">
                        <DialogHeader>
                          <DialogTitle className="text-xl">{selectedSetup.name}</DialogTitle>
                        </DialogHeader>
                        
                        <div className="space-y-6">
                          {selectedSetup.short_name && (
                            <div>
                              <p className="text-sm text-slate-400 mb-1">Nombre corto</p>
                              <Badge variant="outline">{selectedSetup.short_name}</Badge>
                            </div>
                          )}

                          {selectedSetup.description && (
                            <div>
                              <p className="text-sm text-slate-400 mb-2">Descripción</p>
                              <p className="text-white">{selectedSetup.description}</p>
                            </div>
                          )}

                          {selectedSetup.market_conditions && (
                            <div>
                              <p className="text-sm text-slate-400 mb-2">Condiciones de Mercado</p>
                              <p className="text-white">{selectedSetup.market_conditions}</p>
                            </div>
                          )}

                          {selectedSetup.entry_model && (
                            <div>
                              <p className="text-sm text-slate-400 mb-2">Modelo de Entrada</p>
                              <p className="text-white">{selectedSetup.entry_model}</p>
                            </div>
                          )}

                          {selectedSetup.invalidations && (
                            <div>
                              <p className="text-sm text-slate-400 mb-2">Invalidaciones</p>
                              <p className="text-white">{selectedSetup.invalidations}</p>
                            </div>
                          )}

                          {selectedSetup.timeframes && selectedSetup.timeframes.length > 0 && (
                            <div>
                              <p className="text-sm text-slate-400 mb-2">Timeframes</p>
                              <div className="flex flex-wrap gap-2">
                                {selectedSetup.timeframes.map((tf, idx) => (
                                  <Badge key={idx} variant="outline">{tf}</Badge>
                                ))}
                              </div>
                            </div>
                          )}

                          {selectedSetup.tags && selectedSetup.tags.length > 0 && (
                            <div>
                              <p className="text-sm text-slate-400 mb-2">Tags</p>
                              <div className="flex flex-wrap gap-2">
                                {selectedSetup.tags.map((tag, idx) => (
                                  <Badge key={idx} className="bg-slate-700">{tag}</Badge>
                                ))}
                              </div>
                            </div>
                          )}

                          {selectedSetup.statistics_enabled && (() => {
                            const stats = calculateSetupStats(selectedSetup.id);
                            const setupTrades = trades.filter(t => t.setup_id === selectedSetup.id);
                            
                            return (
                              <div>
                                <p className="text-sm text-slate-400 mb-3">Estadísticas de Rendimiento</p>
                                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                                  <Card className="bg-slate-800 border-slate-700">
                                    <CardContent className="pt-6">
                                      <p className="text-xs text-slate-400">Total Trades</p>
                                      <p className="text-2xl font-bold text-white">{stats.totalTrades}</p>
                                    </CardContent>
                                  </Card>
                                  <Card className="bg-slate-800 border-slate-700">
                                    <CardContent className="pt-6">
                                      <p className="text-xs text-slate-400">Win Rate</p>
                                      <p className="text-2xl font-bold text-green-400">{stats.winRate.toFixed(1)}%</p>
                                    </CardContent>
                                  </Card>
                                  <Card className="bg-slate-800 border-slate-700">
                                    <CardContent className="pt-6">
                                      <p className="text-xs text-slate-400">Total P&L</p>
                                      <p className={`text-2xl font-bold ${stats.totalPnL >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                                        ${stats.totalPnL.toFixed(0)}
                                      </p>
                                    </CardContent>
                                  </Card>
                                  <Card className="bg-slate-800 border-slate-700">
                                    <CardContent className="pt-6">
                                      <p className="text-xs text-slate-400">Avg P&L</p>
                                      <p className={`text-2xl font-bold ${stats.avgPnL >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                                        ${stats.avgPnL.toFixed(0)}
                                      </p>
                                    </CardContent>
                                  </Card>
                                </div>

                                {setupTrades.length > 0 && (
                                  <div>
                                    <p className="text-sm text-slate-400 mb-2">Operaciones recientes</p>
                                    <div className="space-y-2">
                                      {setupTrades.slice(0, 5).map((trade) => (
                                        <div key={trade.id} className="flex items-center justify-between p-2 bg-slate-800 rounded">
                                          <div className="flex items-center gap-2">
                                            <div className={`w-2 h-2 rounded-full ${trade.pnl >= 0 ? 'bg-green-500' : 'bg-red-500'}`} />
                                            <p className="text-white text-sm">{trade.symbol}</p>
                                            <p className="text-xs text-slate-400">{new Date(trade.exit_date).toLocaleDateString()}</p>
                                          </div>
                                          <p className={`font-bold text-sm ${trade.pnl >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                                            ${trade.pnl.toLocaleString()}
                                          </p>
                                        </div>
                                      ))}
                                    </div>
                                  </div>
                                )}
                              </div>
                            );
                          })()}
                        </div>
                      </DialogContent>
                    </Dialog>
                  )}
                </>
              );
            })()}
          </TabsContent>

          <TabsContent value="reports" className="space-y-6">
            {(() => {
              const [generatingReport, setGeneratingReport] = useState(false);

              const { data: reports = [] } = useQuery({
                queryKey: ['weekly-reports'],
                queryFn: () => base44.entities.WeeklyReport.list('-created_at')
              });

              const generateReportMutation = useMutation({
                mutationFn: async () => {
                  setGeneratingReport(true);
                  
                  const now = new Date();
                  const weekStart = new Date(now);
                  weekStart.setDate(now.getDate() - 7);
                  
                  const weekTrades = trades.filter(t => {
                    const tradeDate = new Date(t.exit_date);
                    return tradeDate >= weekStart && tradeDate <= now;
                  });

                  const totalPnL = weekTrades.reduce((sum, t) => sum + (t.pnl || 0), 0);
                  const winningTrades = weekTrades.filter(t => t.pnl > 0).length;
                  const losingTrades = weekTrades.filter(t => t.pnl < 0).length;
                  const winRate = weekTrades.length > 0 ? (winningTrades / weekTrades.length) * 100 : 0;

                  const accountsSummary = accounts.map(acc => {
                    const accTrades = weekTrades.filter(t => t.account_id === acc.id);
                    const accPnL = accTrades.reduce((sum, t) => sum + (t.pnl || 0), 0);
                    return {
                      name: acc.name,
                      trades: accTrades.length,
                      pnl: accPnL,
                      balance: acc.current_balance
                    };
                  }).filter(a => a.trades > 0);

                  const prompt = `
Genera un AlphaBrief ejecutivo semanal para un trader profesional basado en los siguientes datos:

RESUMEN SEMANAL (${weekStart.toLocaleDateString()} - ${now.toLocaleDateString()}):
- Total operaciones: ${weekTrades.length}
- Win Rate: ${winRate.toFixed(1)}%
- P&L Total: $${totalPnL.toLocaleString()}
- Operaciones ganadoras: ${winningTrades}
- Operaciones perdedoras: ${losingTrades}

CUENTAS ACTIVAS:
${accountsSummary.map(a => `- ${a.name}: ${a.trades} trades, P&L: $${a.pnl.toLocaleString()}, Balance: $${a.balance.toLocaleString()}`).join('\n')}

OPERACIONES DESTACADAS:
${weekTrades.slice(0, 5).map(t => `- ${t.symbol} (${t.direction}): $${t.pnl.toLocaleString()}`).join('\n')}

Genera un reporte ejecutivo en español con las siguientes secciones:
1. **Executive Summary**: Resumen general del desempeño semanal
2. **Performance Overview**: Análisis de métricas clave
3. **Account Breakdown**: Desglose por cuenta
4. **Key Insights**: Insights y patrones identificados
5. **Action Items**: Recomendaciones para la próxima semana

Usa formato markdown. Sé conciso, profesional y enfocado en datos accionables.
`;

                  const response = await base44.integrations.Core.InvokeLLM({
                    prompt,
                    response_json_schema: null
                  });

                  await base44.entities.WeeklyReport.create({
                    week_start: weekStart.toISOString().split('T')[0],
                    week_end: now.toISOString().split('T')[0],
                    content_md: response,
                    total_trades: weekTrades.length,
                    total_pnl: totalPnL,
                    win_rate: winRate
                  });

                  setGeneratingReport(false);
                },
                onSuccess: () => {
                  queryClient.invalidateQueries(['weekly-reports']);
                }
              });

              const deleteReportMutation = useMutation({
                mutationFn: (id) => base44.entities.WeeklyReport.delete(id),
                onSuccess: () => queryClient.invalidateQueries(['weekly-reports'])
              });

              return (
                <>
                  <div className="mb-6">
                    <div className="flex items-center justify-between mb-4">
                      <div>
                        <h2 className="text-2xl font-bold text-white">AlphaBrief Generator</h2>
                        <p className="text-slate-400 text-sm">Genera resúmenes semanales con AI de todas tus operaciones.</p>
                      </div>
                      <Button
                        onClick={() => generateReportMutation.mutate()}
                        disabled={generatingReport}
                        className="bg-blue-600 hover:bg-blue-700"
                      >
                        {generatingReport ? (
                          <>
                            <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                            Generando...
                          </>
                        ) : (
                          <>
                            <FileText className="w-4 h-4 mr-2" />
                            Generar AlphaBrief
                          </>
                        )}
                      </Button>
                    </div>
                  </div>

                  {reports.length > 0 ? (
                    <div className="space-y-4">
                      {reports.map((report) => (
                        <Card key={report.id} className="bg-slate-900 border-slate-800">
                          <CardHeader>
                            <div className="flex items-start justify-between">
                              <div className="flex-1">
                                <CardTitle className="text-white text-lg">
                                  AlphaBrief Semanal
                                </CardTitle>
                                <p className="text-sm text-slate-400 mt-1">
                                  {new Date(report.week_start).toLocaleDateString()} - {new Date(report.week_end).toLocaleDateString()}
                                </p>
                                <div className="flex gap-3 mt-2">
                                  <Badge variant="outline">
                                    {report.total_trades} trades
                                  </Badge>
                                  <Badge className={report.total_pnl >= 0 ? 'bg-green-600' : 'bg-red-600'}>
                                    ${report.total_pnl?.toLocaleString() || 0}
                                  </Badge>
                                  <Badge variant="outline">
                                    WR: {report.win_rate?.toFixed(1) || 0}%
                                  </Badge>
                                </div>
                              </div>
                              <Button
                                size="icon"
                                variant="ghost"
                                onClick={() => deleteReportMutation.mutate(report.id)}
                                className="text-slate-400 hover:text-red-400"
                              >
                                <Trash2 className="w-4 h-4" />
                              </Button>
                            </div>
                          </CardHeader>
                          <CardContent>
                            <div className="prose prose-invert prose-sm max-w-none">
                              <div className="text-slate-300 whitespace-pre-wrap">
                                {report.content_md}
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  ) : (
                    <Card className="bg-slate-900 border-slate-800">
                      <CardContent className="py-12">
                        <div className="text-center">
                          <FileText className="w-12 h-12 text-slate-600 mx-auto mb-3" />
                          <p className="text-slate-400">No hay reportes generados</p>
                          <p className="text-slate-500 text-sm mt-1">Genera tu primer AlphaBrief semanal con AI</p>
                        </div>
                      </CardContent>
                    </Card>
                  )}
                </>
              );
            })()}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}