import Accounts from './pages/Accounts';
import Analytics from './pages/Analytics';
import Business from './pages/Business';
import Calendar from './pages/Calendar';
import Dashboard from './pages/Dashboard';
import Goals from './pages/Goals';
import Journal from './pages/Journal';
import Map from './pages/Map';
import Setups from './pages/Setups';
import Terminal from './pages/Terminal';
import TraderMapMenu from './pages/TraderMapMenu';
import TradesHub from './pages/TradesHub';
import TradesMenu from './pages/TradesMenu';
import Treasury from './pages/Treasury';
import TreasuryMenu from './pages/TreasuryMenu';


export const PAGES = {
    "Accounts": Accounts,
    "Analytics": Analytics,
    "Business": Business,
    "Calendar": Calendar,
    "Dashboard": Dashboard,
    "Goals": Goals,
    "Journal": Journal,
    "Map": Map,
    "Setups": Setups,
    "Terminal": Terminal,
    "TraderMapMenu": TraderMapMenu,
    "TradesHub": TradesHub,
    "TradesMenu": TradesMenu,
    "Treasury": Treasury,
    "TreasuryMenu": TreasuryMenu,
}

export const pagesConfig = {
    mainPage: "Dashboard",
    Pages: PAGES,
};