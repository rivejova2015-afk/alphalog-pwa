import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (user?.role !== 'admin') {
      return Response.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
    }

    const { scheduleId } = await req.json();

    // Get schedule details
    const schedule = await base44.asServiceRole.entities.ReportSchedule.filter({ id: scheduleId })[0];
    if (!schedule || !schedule.is_active) {
      return Response.json({ error: 'Schedule not found or inactive' }, { status: 404 });
    }

    const { instrument_id, report_type, tone } = schedule;
    const lang = 'en'; // Default to English for scheduled reports

    // Fetch all data sources
    const [news, events, claims, structures, pools, snapshots] = await Promise.all([
      base44.asServiceRole.entities.TerminalNews.filter({ instrument_id }, '-timestamp_utc', 15),
      base44.asServiceRole.entities.TerminalEvent.filter({ related_instruments: instrument_id }, '-timestamp_utc', 10),
      base44.asServiceRole.entities.TerminalClaim.filter({ instrument_id, status: 'VERIFIED' }, '-date_utc', 5),
      base44.asServiceRole.entities.StructureH1.filter({ instrument_id }, '-timestamp_utc', 3),
      base44.asServiceRole.entities.LiquidityPool.filter({ instrument_id }, '-date_utc', 5),
      base44.asServiceRole.entities.MarketSnapshot.filter({ instrument_id }, '-as_of_utc', 1)
    ]);

    const snapshot = snapshots[0] || {};
    const latestStructure = structures[0] || {};
    
    // Build context
    const newsContext = news.map(n => 
      `- ${n.title} (${n.source}, Impact: ${n.impact_label || 'N/A'})`
    ).join('\n');

    const eventsContext = events.map(e => 
      `- ${e.name} (${e.impact}, ${new Date(e.timestamp_utc).toLocaleString()})`
    ).join('\n');

    const claimsContext = claims.map(c => 
      `- ${c.statement} (Confidence: ${c.confidence}%)`
    ).join('\n');

    const structureContext = `
Trend: ${latestStructure.trend || 'N/A'}
State: ${latestStructure.state || 'N/A'}
BOS: ${latestStructure.bos_price || 'N/A'}
ChoCh: ${latestStructure.choch_price || 'N/A'}
    `.trim();

    const poolsContext = pools.map(p => 
      `- ${p.pool_type}: ${p.price_zone_low} - ${p.price_zone_high} (Priority: ${p.priority_rank})`
    ).join('\n');

    const toneInstructions = {
      professional: 'Use professional, formal language suitable for institutional investors.',
      technical: 'Use technical trading terminology, focus on price action and market structure.',
      casual: 'Use conversational, easy-to-understand language for retail traders.'
    };

    const reportTypeInstructions = {
      ALL_IN: 'Complete comprehensive analysis combining pre-market setup, intraday updates, session-specific analysis, technical liquidity deep dive, and close wrap. This is the ultimate all-in-one report covering everything from overnight developments to end-of-day summary and tomorrow\'s preparation.',
      PRE_MARKET: 'Focus on pre-market setup, key levels to watch, and overnight developments.',
      DAILY_OUTLOOK: 'Comprehensive daily analysis covering all aspects.',
      MIDDAY: 'Mid-session update focusing on current price action and intraday changes.',
      CLOSE_WRAP: 'End-of-day summary and tomorrow\'s preparation.',
      ASIA_SESSION: 'Analysis specific to Asian trading session.',
      LONDON_SESSION: 'Analysis specific to London trading session.',
      NY_SESSION: 'Analysis specific to New York trading session.',
      TECHNICAL_LIQUIDITY: 'Deep dive into liquidity pools and market structure.'
    };

    // Generate report
    const prompt = `You are a professional market analyst. Generate a ${report_type.replace(/_/g, ' ')} report for ${instrument_id} in English.

${toneInstructions[tone]}
${reportTypeInstructions[report_type]}

**DATA SOURCES:**

Recent News (last 15):
${newsContext || 'No recent news'}

Economic Events:
${eventsContext || 'No upcoming events'}

Verified Claims:
${claimsContext || 'No verified claims'}

Market Structure (1H):
${structureContext}

Liquidity Pools:
${poolsContext || 'No pools identified'}

Current Snapshot:
Price: ${snapshot.payload_json?.price?.current || 'N/A'}
Confidence: ${snapshot.confidence || 0}%

**REPORT STRUCTURE:**

## Market Overview
Brief 2-3 sentence summary of current state

## News Impact Table
Create a well-formatted markdown table showing HIGH and MEDIUM impact news ONLY:

| 📰 Title & Summary | 📊 Source | ⚠️ Impact |
|-------------------|-----------|-----------|
| Brief title + 1-line summary | Source name | 🔴 HIGH or 🟠 MED |

**IMPORTANT TABLE RULES:**
- Filter: Show ONLY news with HIGH or MED impact (ignore LOW impact)
- Order: Sort by impact level (🔴 HIGH first, then 🟠 MED)
- Format impact column as: "🔴 HIGH" or "🟠 MED" (emoji + text)
- First column: News title with a brief 1-line summary below it
- Use proper markdown table syntax with | dividers for each cell
- Include ALL high and medium impact news available

## Key Drivers
Top 3-5 factors in bullet points (concise)

## Technical Levels
Key support/resistance zones only

## Sentiment Barometer
- Direction: BUY / SELL / NEUTRAL (with % confidence)
- Emotion: FEAR / CONFIDENCE / EUPHORIA / NEUTRAL (with intensity 1-10)

## Outlook
Next steps and what to watch

## Final Summary
A comprehensive concluding paragraph that synthesizes all the above analysis, providing clear actionable insights and painting the complete market picture based on all data sources analyzed.

Keep it simple and actionable. Use markdown formatting with proper table syntax.`;

    const result = await base44.asServiceRole.integrations.Core.InvokeLLM({
      prompt,
      add_context_from_internet: true
    });

    // Save report
    const report = await base44.asServiceRole.entities.Reports.create({
      instrument_id,
      created_at_utc: new Date().toISOString(),
      report_type,
      tone,
      title: `${instrument_id} ${report_type.replace(/_/g, ' ')} - ${new Date().toLocaleDateString()}`,
      content_md: result,
      sources_used: [...new Set([
        ...news.map(n => n.source),
        'Economic Calendar',
        'Verified Claims',
        'Market Structure',
        'Liquidity Analysis'
      ])]
    });

    // Send email if enabled
    if (schedule.send_email) {
      await base44.asServiceRole.integrations.Core.SendEmail({
        to: user.email,
        subject: `${instrument_id} ${report_type.replace(/_/g, ' ')} Report`,
        body: `Your scheduled ${report_type} report has been generated.\n\nView it in AlphaLog Terminal: https://app.base44.com/`
      });
    }

    return Response.json({ 
      success: true,
      report_id: report.id,
      message: 'Report generated successfully'
    });
  } catch (error) {
    console.error('Error generating scheduled report:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});