import { createClientFromRequest } from 'npm:@base44/sdk@0.8.6';
Deno.serve(async (req) => {
  console.log('=== Received request from Render ===');
  console.log('Method:', req.method);
  console.log('Headers:', JSON.stringify(Object.fromEntries(req.headers.entries())));
  
  try {
    const base44 = createClientFromRequest(req);
    
    // Parse incoming data from Render webhook
    const payload = await req.json();
    console.log('📦 Payload received:', JSON.stringify(payload, null, 2));
    
    // Extract data - could be in payload.data or directly in payload
    const data = payload.data || payload;
    console.log('📊 Extracted data:', JSON.stringify(data, null, 2));
    
    // Validate required fields
    if (!data.symbol || data.bid === undefined || data.ask === undefined || data.last === undefined) {
      console.log('❌ Validation failed - missing fields');
      return Response.json({ 
        ok: false,
        error: 'Missing required fields: symbol, bid, ask, last',
        received: data
      }, { status: 400 });
    }

    console.log('✅ Validation passed');

    // Delete old data for this symbol (keep only latest)
   const existing = await base44.asServiceRole.entities.LiveMarketData.list();

for (const record of existing.items ?? existing) {
  if (record.symbol === data.symbol) {
    await base44.asServiceRole.entities.LiveMarketData.delete(record.id);
  }
}
    // Save new market data
    const marketData = await base44.asServiceRole.entities.LiveMarketData.create({
      symbol: data.symbol,
      bid: parseFloat(data.bid),
      ask: parseFloat(data.ask),
      last: parseFloat(data.last),
      token_ok: data.token_ok ?? data.tokenOk ?? false,
      received_at: new Date().toISOString()
    });

    console.log('✅ Saved market data:', JSON.stringify(marketData, null, 2));

    return Response.json({ 
      ok: true,
      data: marketData 
    });

  } catch (error) {
    console.error('❌ Error receiving MT5 data:', error);
    console.error('Stack:', error.stack);
    return Response.json({ 
      ok: false,
      error: error.message,
      stack: error.stack
    }, { status: 500 });
  }
});